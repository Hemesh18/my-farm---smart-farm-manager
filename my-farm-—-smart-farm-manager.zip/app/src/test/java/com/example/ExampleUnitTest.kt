package com.example

import com.example.data.remote.SatelliteService
import com.example.data.util.PdfExporter
import com.example.data.util.ReportType
import com.example.data.util.SecurityUtils
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun testPasswordHashingAndVerification() {
    val password = "secret_farmer_pass_2026"
    val hash = SecurityUtils.hashPassword(password)
    
    assertNotNull(hash)
    assertTrue(hash.length == 64) // SHA-256 hex length
    assertTrue(SecurityUtils.verifyPassword(password, hash))
    assertFalse(SecurityUtils.verifyPassword("wrong_password", hash))
  }

  @Test
  fun testSatelliteDataAvailability() {
    val passes = SatelliteService.getHistoricalPasses()
    assertTrue(passes.isNotEmpty())
    val latest = passes.first()
    assertTrue(latest.averageNdvi in 0.0..1.0)
    assertTrue(latest.fieldNdviMap.isNotEmpty())
    assertEquals(4, SatelliteService.ndviLegend.size)
  }

  @Test
  fun testReportTypesConfigured() {
    val reportTypes = ReportType.values()
    assertTrue(reportTypes.size >= 5)
    assertTrue(reportTypes.any { it.name == "COMPLETE" })
    assertTrue(reportTypes.any { it.name == "FINANCES" })
  }
}
