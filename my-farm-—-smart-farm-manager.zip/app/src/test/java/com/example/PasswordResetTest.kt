package com.example

import com.example.data.util.SecurityUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordResetTest {

    @Test
    fun testPasswordHashingAndVerification() {
        val rawPassword = "FarmerNewPass2026"
        val hash = SecurityUtils.hashPassword(rawPassword)

        assertTrue(SecurityUtils.verifyPassword(rawPassword, hash))
        assertFalse(SecurityUtils.verifyPassword("WrongPass", hash))
    }

    @Test
    fun testPasswordHashIsDeterministic() {
        val pass = "AgriTechPass123"
        val hash1 = SecurityUtils.hashPassword(pass)
        val hash2 = SecurityUtils.hashPassword(pass)

        assertEquals(hash1, hash2)
    }
}
