package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class OpenMeteoResponse(
    val latitude: Double? = null,
    val longitude: Double? = null,
    val current: CurrentWeatherDto? = null,
    val hourly: HourlyWeatherDto? = null,
    val daily: DailyWeatherDto? = null
)

@JsonClass(generateAdapter = true)
data class CurrentWeatherDto(
    val time: String? = null,
    @Json(name = "temperature_2m") val temperature: Double = 28.0,
    @Json(name = "relative_humidity_2m") val humidity: Int = 62,
    @Json(name = "apparent_temperature") val apparentTemperature: Double = 30.0,
    val precipitation: Double = 0.0,
    @Json(name = "weather_code") val weatherCode: Int = 1,
    @Json(name = "wind_speed_10m") val windSpeed: Double = 11.5
)

@JsonClass(generateAdapter = true)
data class HourlyWeatherDto(
    val time: List<String> = emptyList(),
    @Json(name = "temperature_2m") val temperature: List<Double> = emptyList(),
    @Json(name = "precipitation_probability") val precipitationProbability: List<Int> = emptyList(),
    @Json(name = "precipitation") val precipitation: List<Double> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int> = emptyList()
)

@JsonClass(generateAdapter = true)
data class DailyWeatherDto(
    val time: List<String> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int> = emptyList(),
    @Json(name = "temperature_2m_max") val temperatureMax: List<Double> = emptyList(),
    @Json(name = "temperature_2m_min") val temperatureMin: List<Double> = emptyList(),
    @Json(name = "precipitation_sum") val precipitationSum: List<Double> = emptyList(),
    @Json(name = "precipitation_probability_max") val precipitationProbabilityMax: List<Int> = emptyList(),
    @Json(name = "wind_speed_10m_max") val windSpeedMax: List<Double> = emptyList()
)

interface WeatherService {
    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,precipitation,weather_code",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max",
        @Query("timezone") timezone: String = "auto"
    ): OpenMeteoResponse
}

data class WeatherInfo(
    val temperature: Double,
    val feelsLike: Double,
    val condition: String,
    val conditionCode: Int,
    val humidity: Int,
    val windSpeedKmh: Double,
    val rainProbability: Int,
    val precipitationMm: Double,
    val hourlyForecast: List<HourlyForecastItem>,
    val dailyForecast: List<DailyForecastItem>,
    val agriculturalAlerts: List<AgriWeatherAlert>,
    val sprayingSuitability: SprayingAdvice,
    val lastUpdated: String,
    val isLiveApi: Boolean
)

data class HourlyForecastItem(
    val timeFormatted: String,
    val temperature: Double,
    val rainProb: Int,
    val condition: String
)

data class DailyForecastItem(
    val dayName: String,
    val maxTemp: Double,
    val minTemp: Double,
    val rainProb: Int,
    val condition: String
)

data class AgriWeatherAlert(
    val title: String,
    val severity: String, // Info, Warning, Alert
    val message: String,
    val actionAdvice: String
)

data class SprayingAdvice(
    val isSuitable: Boolean,
    val statusText: String,
    val reason: String
)

object WeatherApiClient {
    private const val BASE_URL = "https://api.open-meteo.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val service: WeatherService by lazy {
        retrofit.create(WeatherService::class.java)
    }

    fun mapWmoCode(code: Int): String {
        return when (code) {
            0 -> "Clear Sky"
            1, 2 -> "Partly Cloudy"
            3 -> "Overcast"
            45, 48 -> "Foggy"
            51, 53, 55 -> "Light Drizzle"
            61, 63 -> "Moderate Rain"
            65 -> "Heavy Rain"
            71, 73, 75 -> "Snow"
            80, 81, 82 -> "Rain Showers"
            95, 96, 99 -> "Thunderstorm"
            else -> "Partly Cloudy"
        }
    }

    suspend fun fetchWeather(lat: Double, lon: Double): WeatherInfo {
        return try {
            val response = service.getForecast(lat, lon)
            val current = response.current ?: CurrentWeatherDto()
            val timeFmt = SimpleDateFormat("HH:mm, dd MMM", Locale.getDefault()).format(Date())

            val hourly = mutableListOf<HourlyForecastItem>()
            val hourlyDto = response.hourly
            if (hourlyDto != null && hourlyDto.time.isNotEmpty()) {
                val count = minOf(12, hourlyDto.time.size)
                for (i in 0 until count) {
                    val rawTime = hourlyDto.time.getOrNull(i) ?: ""
                    val displayTime = if (rawTime.contains("T")) rawTime.substringAfter("T") else "$i:00"
                    hourly.add(
                        HourlyForecastItem(
                            timeFormatted = displayTime,
                            temperature = hourlyDto.temperature.getOrNull(i) ?: current.temperature,
                            rainProb = hourlyDto.precipitationProbability.getOrNull(i) ?: 0,
                            condition = mapWmoCode(hourlyDto.weatherCode.getOrNull(i) ?: 0)
                        )
                    )
                }
            }

            val daily = mutableListOf<DailyForecastItem>()
            val dailyDto = response.daily
            if (dailyDto != null && dailyDto.time.isNotEmpty()) {
                val count = minOf(7, dailyDto.time.size)
                val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
                val parseFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                for (i in 0 until count) {
                    val dateStr = dailyDto.time.getOrNull(i) ?: ""
                    val parsedDate = try { parseFormat.parse(dateStr) } catch (e: Exception) { null }
                    val dayName = if (i == 0) "Today" else parsedDate?.let { dayFormat.format(it) } ?: "Day $i"
                    daily.add(
                        DailyForecastItem(
                            dayName = dayName,
                            maxTemp = dailyDto.temperatureMax.getOrNull(i) ?: 32.0,
                            minTemp = dailyDto.temperatureMin.getOrNull(i) ?: 22.0,
                            rainProb = dailyDto.precipitationProbabilityMax.getOrNull(i) ?: 10,
                            condition = mapWmoCode(dailyDto.weatherCode.getOrNull(i) ?: 1)
                        )
                    )
                }
            }

            val alerts = generateAgriAlerts(current.temperature, current.humidity, current.windSpeed, current.precipitation)
            val spraying = evaluateSpraying(current.windSpeed, current.precipitation, current.temperature)

            WeatherInfo(
                temperature = current.temperature,
                feelsLike = current.apparentTemperature,
                condition = mapWmoCode(current.weatherCode),
                conditionCode = current.weatherCode,
                humidity = current.humidity,
                windSpeedKmh = current.windSpeed,
                rainProbability = daily.firstOrNull()?.rainProb ?: 15,
                precipitationMm = current.precipitation,
                hourlyForecast = hourly,
                dailyForecast = daily,
                agriculturalAlerts = alerts,
                sprayingSuitability = spraying,
                lastUpdated = timeFmt,
                isLiveApi = true
            )
        } catch (e: Exception) {
            getOfflineFallbackWeather()
        }
    }

    private fun generateAgriAlerts(temp: Double, humidity: Int, wind: Double, rain: Double): List<AgriWeatherAlert> {
        val list = mutableListOf<AgriWeatherAlert>()
        if (temp > 35.0) {
            list.add(
                AgriWeatherAlert(
                    title = "High Heat Stress Warning",
                    severity = "Warning",
                    message = "Temperatures reaching ${temp}°C may induce flower drop and moisture stress in flowering crops.",
                    actionAdvice = "Ensure active drip irrigation in early morning or late afternoon to maintain root zone turgidity."
                )
            )
        }
        if (wind > 20.0) {
            list.add(
                AgriWeatherAlert(
                    title = "Strong Gusts Alert",
                    severity = "Warning",
                    message = "Wind speed ${wind} km/h may cause pesticide drift and damage tall crops.",
                    actionAdvice = "Postpone any scheduled foliar spraying or drone application until wind subsides."
                )
            )
        }
        if (humidity > 80) {
            list.add(
                AgriWeatherAlert(
                    title = "High Humidity Fungal Threat",
                    severity = "Alert",
                    message = "Persistent humidity above ${humidity}% creates favorable conditions for foliar blight and mildew.",
                    actionAdvice = "Inspect field borders and dense canopy areas for leaf spot symptoms."
                )
            )
        }
        if (list.isEmpty()) {
            list.add(
                AgriWeatherAlert(
                    title = "Favorable Farming Weather",
                    severity = "Info",
                    message = "Mild conditions across the farm. Optimal window for intercultural work, weeding, and nutrient uptake.",
                    actionAdvice = "Proceed with scheduled agronomic field activities."
                )
            )
        }
        return list
    }

    private fun evaluateSpraying(wind: Double, rain: Double, temp: Double): SprayingAdvice {
        return when {
            rain > 0.5 -> SprayingAdvice(
                isSuitable = false,
                statusText = "Unsuitable (Rain Expected)",
                reason = "Active or impending precipitation will wash away chemical and biological sprays."
            )
            wind > 15.0 -> SprayingAdvice(
                isSuitable = false,
                statusText = "Unsuitable (High Wind Drift)",
                reason = "Wind speed above 15 km/h causes severe droplet drift away from target canopy."
            )
            temp > 34.0 -> SprayingAdvice(
                isSuitable = false,
                statusText = "Marginal (High Temperature)",
                reason = "Midday heat accelerates droplet evaporation and phytotoxicity risk. Spray only after 5:00 PM."
            )
            else -> SprayingAdvice(
                isSuitable = true,
                statusText = "Suitable for Spraying",
                reason = "Wind speed is calm and foliage is dry. Ideal conditions for contact and systemic sprays."
            )
        }
    }

    fun getOfflineFallbackWeather(): WeatherInfo {
        val timeFmt = SimpleDateFormat("HH:mm, dd MMM", Locale.getDefault()).format(Date())
        val dummyHourly = listOf(
            HourlyForecastItem("06:00", 22.0, 5, "Clear Sky"),
            HourlyForecastItem("09:00", 26.0, 10, "Sunny"),
            HourlyForecastItem("12:00", 31.0, 15, "Partly Cloudy"),
            HourlyForecastItem("15:00", 33.0, 20, "Partly Cloudy"),
            HourlyForecastItem("18:00", 28.0, 10, "Clear Sky"),
            HourlyForecastItem("21:00", 25.0, 5, "Clear Sky")
        )
        val dummyDaily = listOf(
            DailyForecastItem("Today", 32.0, 22.0, 15, "Partly Cloudy"),
            DailyForecastItem("Tomorrow", 33.0, 23.0, 25, "Partly Cloudy"),
            DailyForecastItem("Wed", 30.0, 21.0, 45, "Scattered Rain"),
            DailyForecastItem("Thu", 29.0, 20.0, 20, "Partly Cloudy"),
            DailyForecastItem("Fri", 31.0, 22.0, 10, "Sunny"),
            DailyForecastItem("Sat", 32.0, 23.0, 10, "Sunny"),
            DailyForecastItem("Sun", 33.0, 22.0, 5, "Clear Sky")
        )

        return WeatherInfo(
            temperature = 29.5,
            feelsLike = 31.0,
            condition = "Partly Cloudy",
            conditionCode = 2,
            humidity = 58,
            windSpeedKmh = 10.2,
            rainProbability = 15,
            precipitationMm = 0.0,
            hourlyForecast = dummyHourly,
            dailyForecast = dummyDaily,
            agriculturalAlerts = listOf(
                AgriWeatherAlert(
                    title = "Favorable Agronomic Window",
                    severity = "Info",
                    message = "Mild conditions across the farm. Clear sky allows active photosynthetic assimilation.",
                    actionAdvice = "Ideal for morning intercultural operations and drip fertigation."
                )
            ),
            sprayingSuitability = SprayingAdvice(
                isSuitable = true,
                statusText = "Suitable for Spraying",
                reason = "Wind speed is gentle (10 km/h) with zero rain forecast for the next 12 hours."
            ),
            lastUpdated = "$timeFmt (Cached)",
            isLiveApi = false
        )
    }
}
