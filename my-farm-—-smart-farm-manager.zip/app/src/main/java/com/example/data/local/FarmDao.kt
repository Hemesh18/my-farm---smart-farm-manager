package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {

    // User Accounts & Authentication
    @Query("SELECT * FROM user_accounts WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserAccount?

    @Query("SELECT * FROM user_accounts WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccount)

    @Update
    suspend fun updateUser(user: UserAccount)

    @Query("SELECT * FROM user_accounts ORDER BY createdAt DESC")
    fun getAllUsersFlow(): Flow<List<UserAccount>>

    // Password Reset Tokens
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResetToken(token: PasswordResetToken)

    @Query("SELECT * FROM password_reset_tokens WHERE token = :token LIMIT 1")
    suspend fun getResetToken(token: String): PasswordResetToken?

    @Query("SELECT * FROM password_reset_tokens WHERE userEmail = :email AND isUsed = 0 ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatestActiveTokenForEmail(email: String): PasswordResetToken?

    @Update
    suspend fun updateResetToken(token: PasswordResetToken)

    // Audit Logs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLog)

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllAuditLogs(): Flow<List<AuditLog>>

    // Farm Profiles (User Scoped)
    @Query("SELECT * FROM farm_profiles WHERE userId = :userId ORDER BY isDefault DESC, createdAt ASC")
    fun getFarmsForUser(userId: String): Flow<List<FarmProfile>>

    @Query("SELECT * FROM farm_profiles WHERE userId = :userId AND isDefault = 1 LIMIT 1")
    fun getDefaultFarmFlow(userId: String): Flow<FarmProfile?>

    @Query("SELECT * FROM farm_profiles WHERE userId = :userId AND isDefault = 1 LIMIT 1")
    suspend fun getDefaultFarm(userId: String): FarmProfile?

    @Query("SELECT * FROM farm_profiles WHERE id = :farmId LIMIT 1")
    suspend fun getFarmById(farmId: String): FarmProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateFarmProfile(profile: FarmProfile)

    @Delete
    suspend fun deleteFarmProfile(profile: FarmProfile)

    // Legacy fallback
    @Query("SELECT * FROM farm_profiles LIMIT 1")
    fun getFarmProfileFlow(): Flow<FarmProfile?>

    @Query("SELECT * FROM farm_profiles LIMIT 1")
    suspend fun getFarmProfile(): FarmProfile?

    // Fields / Plots (User & Farm Scoped)
    @Query("SELECT * FROM fields WHERE userId = :userId AND farmId = :farmId ORDER BY name ASC")
    fun getFieldsForFarm(userId: String, farmId: String): Flow<List<FieldPlot>>

    @Query("SELECT * FROM fields WHERE userId = :userId ORDER BY name ASC")
    fun getAllFieldsForUser(userId: String): Flow<List<FieldPlot>>

    @Query("SELECT * FROM fields ORDER BY name ASC")
    fun getAllFields(): Flow<List<FieldPlot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertField(field: FieldPlot)

    @Delete
    suspend fun deleteField(field: FieldPlot)

    // Crops (User & Farm Scoped)
    @Query("SELECT * FROM crops WHERE userId = :userId AND farmId = :farmId ORDER BY sowingDateMillis DESC")
    fun getCropsForFarm(userId: String, farmId: String): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops WHERE userId = :userId AND farmId = :farmId AND isArchived = 0 AND status != 'Harvested' ORDER BY sowingDateMillis DESC")
    fun getActiveCropsForFarm(userId: String, farmId: String): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops WHERE userId = :userId ORDER BY sowingDateMillis DESC")
    fun getAllCropsForUser(userId: String): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops WHERE userId = :userId AND isArchived = 0 AND status != 'Harvested' ORDER BY sowingDateMillis DESC")
    fun getActiveCropsForUser(userId: String): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops ORDER BY sowingDateMillis DESC")
    fun getAllCrops(): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops WHERE isArchived = 0 ORDER BY sowingDateMillis DESC")
    fun getActiveCrops(): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops WHERE userId = :userId AND year = :year ORDER BY sowingDateMillis DESC")
    fun getCropsByYear(userId: String, year: Int): Flow<List<CropRecord>>

    @Query("SELECT * FROM crops WHERE id = :cropId LIMIT 1")
    suspend fun getCropById(cropId: String): CropRecord?

    @Query("SELECT * FROM crops WHERE id = :cropId LIMIT 1")
    fun getCropByIdFlow(cropId: String): Flow<CropRecord?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrop(crop: CropRecord)

    @Update
    suspend fun updateCrop(crop: CropRecord)

    @Delete
    suspend fun deleteCrop(crop: CropRecord)

    // Tasks
    @Query("SELECT * FROM farm_tasks WHERE userId = :userId AND farmId = :farmId ORDER BY isCompleted ASC, dueDateMillis ASC")
    fun getTasksForFarm(userId: String, farmId: String): Flow<List<FarmTask>>

    @Query("SELECT * FROM farm_tasks WHERE userId = :userId ORDER BY isCompleted ASC, dueDateMillis ASC")
    fun getAllTasksForUser(userId: String): Flow<List<FarmTask>>

    @Query("SELECT * FROM farm_tasks ORDER BY isCompleted ASC, dueDateMillis ASC")
    fun getAllTasks(): Flow<List<FarmTask>>

    @Query("SELECT * FROM farm_tasks WHERE cropId = :cropId ORDER BY isCompleted ASC, dueDateMillis ASC")
    fun getTasksForCrop(cropId: String): Flow<List<FarmTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: FarmTask)

    @Update
    suspend fun updateTask(task: FarmTask)

    @Delete
    suspend fun deleteTask(task: FarmTask)

    // Irrigation Logs
    @Query("SELECT * FROM irrigation_logs WHERE userId = :userId AND farmId = :farmId ORDER BY dateMillis DESC")
    fun getIrrigationLogsForFarm(userId: String, farmId: String): Flow<List<IrrigationLog>>

    @Query("SELECT * FROM irrigation_logs WHERE userId = :userId ORDER BY dateMillis DESC")
    fun getAllIrrigationLogsForUser(userId: String): Flow<List<IrrigationLog>>

    @Query("SELECT * FROM irrigation_logs ORDER BY dateMillis DESC")
    fun getAllIrrigationLogs(): Flow<List<IrrigationLog>>

    @Query("SELECT * FROM irrigation_logs WHERE cropId = :cropId ORDER BY dateMillis DESC")
    fun getIrrigationLogsForCrop(cropId: String): Flow<List<IrrigationLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIrrigationLog(log: IrrigationLog)

    @Delete
    suspend fun deleteIrrigationLog(log: IrrigationLog)

    // Fertilizer Logs
    @Query("SELECT * FROM fertilizer_logs WHERE userId = :userId AND farmId = :farmId ORDER BY dateMillis DESC")
    fun getFertilizerLogsForFarm(userId: String, farmId: String): Flow<List<FertilizerLog>>

    @Query("SELECT * FROM fertilizer_logs WHERE userId = :userId ORDER BY dateMillis DESC")
    fun getAllFertilizerLogsForUser(userId: String): Flow<List<FertilizerLog>>

    @Query("SELECT * FROM fertilizer_logs ORDER BY dateMillis DESC")
    fun getAllFertilizerLogs(): Flow<List<FertilizerLog>>

    @Query("SELECT * FROM fertilizer_logs WHERE cropId = :cropId ORDER BY dateMillis DESC")
    fun getFertilizerLogsForCrop(cropId: String): Flow<List<FertilizerLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFertilizerLog(log: FertilizerLog)

    @Delete
    suspend fun deleteFertilizerLog(log: FertilizerLog)

    // Transactions / Finance
    @Query("SELECT * FROM transactions WHERE userId = :userId AND farmId = :farmId ORDER BY dateMillis DESC")
    fun getTransactionsForFarm(userId: String, farmId: String): Flow<List<FarmTransaction>>

    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY dateMillis DESC")
    fun getAllTransactionsForUser(userId: String): Flow<List<FarmTransaction>>

    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC")
    fun getAllTransactions(): Flow<List<FarmTransaction>>

    @Query("SELECT * FROM transactions WHERE cropId = :cropId ORDER BY dateMillis DESC")
    fun getTransactionsForCrop(cropId: String): Flow<List<FarmTransaction>>

    @Query("SELECT * FROM transactions WHERE userId = :userId AND year = :year ORDER BY dateMillis DESC")
    fun getTransactionsByYear(userId: String, year: Int): Flow<List<FarmTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FarmTransaction)

    @Delete
    suspend fun deleteTransaction(transaction: FarmTransaction)

    // Disease Scans
    @Query("SELECT * FROM disease_scans WHERE userId = :userId ORDER BY dateMillis DESC")
    fun getDiseaseScansForUser(userId: String): Flow<List<DiseaseScanRecord>>

    @Query("SELECT * FROM disease_scans ORDER BY dateMillis DESC")
    fun getAllDiseaseScans(): Flow<List<DiseaseScanRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiseaseScan(scan: DiseaseScanRecord)

    // Journal
    @Query("SELECT * FROM journal_entries WHERE userId = :userId AND farmId = :farmId ORDER BY dateMillis DESC")
    fun getJournalEntriesForFarm(userId: String, farmId: String): Flow<List<JournalEntry>>

    @Query("SELECT * FROM journal_entries WHERE userId = :userId ORDER BY dateMillis DESC")
    fun getAllJournalEntriesForUser(userId: String): Flow<List<JournalEntry>>

    @Query("SELECT * FROM journal_entries ORDER BY dateMillis DESC")
    fun getAllJournalEntries(): Flow<List<JournalEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournalEntry(entry: JournalEntry)

    // Soil Tests
    @Query("SELECT * FROM soil_tests WHERE userId = :userId AND farmId = :farmId ORDER BY testDateMillis DESC")
    fun getSoilTestsForFarm(userId: String, farmId: String): Flow<List<SoilTestRecord>>

    @Query("SELECT * FROM soil_tests WHERE userId = :userId ORDER BY testDateMillis DESC")
    fun getAllSoilTestsForUser(userId: String): Flow<List<SoilTestRecord>>

    @Query("SELECT * FROM soil_tests ORDER BY testDateMillis DESC")
    fun getAllSoilTests(): Flow<List<SoilTestRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSoilTest(test: SoilTestRecord)

    // AI Chat History
    @Query("SELECT * FROM ai_chat_messages WHERE userId = :userId ORDER BY timestamp ASC")
    fun getAiMessagesForUser(userId: String): Flow<List<AiChatMessage>>

    @Query("SELECT * FROM ai_chat_messages ORDER BY timestamp ASC")
    fun getAllAiMessages(): Flow<List<AiChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAiMessage(message: AiChatMessage)

    @Query("DELETE FROM ai_chat_messages WHERE userId = :userId")
    suspend fun clearAiChatForUser(userId: String)

    @Query("DELETE FROM ai_chat_messages")
    suspend fun clearAiChat()

    // Global Search Across History (User Scoped)
    @Query("""
        SELECT * FROM crops 
        WHERE userId = :userId AND (
           cropName LIKE '%' || :query || '%' 
           OR variety LIKE '%' || :query || '%' 
           OR fieldName LIKE '%' || :query || '%' 
           OR notes LIKE '%' || :query || '%'
        )
        ORDER BY sowingDateMillis DESC
    """)
    suspend fun searchCrops(userId: String, query: String): List<CropRecord>

    @Query("""
        SELECT * FROM transactions 
        WHERE userId = :userId AND (
           category LIKE '%' || :query || '%' 
           OR partyName LIKE '%' || :query || '%' 
           OR receiptNote LIKE '%' || :query || '%' 
           OR cropName LIKE '%' || :query || '%'
        )
        ORDER BY dateMillis DESC
    """)
    suspend fun searchTransactions(userId: String, query: String): List<FarmTransaction>

    @Query("""
        SELECT * FROM journal_entries 
        WHERE userId = :userId AND (
           title LIKE '%' || :query || '%' 
           OR notes LIKE '%' || :query || '%'
        )
        ORDER BY dateMillis DESC
    """)
    suspend fun searchJournal(userId: String, query: String): List<JournalEntry>

    // Farm Boundaries
    @Query("SELECT * FROM farm_boundaries WHERE userId = :userId AND farmId = :farmId ORDER BY updatedAt DESC LIMIT 1")
    fun getBoundaryForFarmFlow(userId: String, farmId: String): Flow<FarmBoundaryRecord?>

    @Query("SELECT * FROM farm_boundaries WHERE userId = :userId ORDER BY updatedAt DESC")
    fun getAllBoundariesForUserFlow(userId: String): Flow<List<FarmBoundaryRecord>>

    @Query("SELECT * FROM farm_boundaries WHERE userId = :userId AND farmId = :farmId ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getBoundaryForFarm(userId: String, farmId: String): FarmBoundaryRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateBoundary(boundary: FarmBoundaryRecord)

    @Delete
    suspend fun deleteBoundary(boundary: FarmBoundaryRecord)
}
