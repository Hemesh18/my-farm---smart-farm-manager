package com.example.data.remote

data class SatellitePass(
    val acquisitionDate: String,
    val satelliteSource: String = "Copernicus Sentinel-2B (MSI)",
    val spatialResolution: String = "10 meters/pixel",
    val cloudCoverPct: Double = 1.2,
    val processingLevel: String = "Level-2A (Bottom-of-Atmosphere Reflectance)",
    val averageNdvi: Double,
    val fieldNdviMap: Map<String, Double>, // fieldId -> NDVI
    val vegetationSummary: String
)

data class NdviLegendItem(
    val rangeText: String,
    val label: String,
    val colorHex: String,
    val interpretation: String
)

object SatelliteService {

    val ndviLegend = listOf(
        NdviLegendItem("> 0.65", "Vigorous Biomass", "#2E7D32", "Dense, active photosynthesis. Optimal leaf area index."),
        NdviLegendItem("0.45 - 0.65", "Moderate Canopy", "#66BB6A", "Normal vegetative growth. Adequate chlorophyll activity."),
        NdviLegendItem("0.25 - 0.45", "Sparse / Early Stage", "#FBC02D", "Emerging seedling canopy or moderate moisture limitation."),
        NdviLegendItem("< 0.25", "Bare Soil / Stressed", "#D32F2F", "Exposed soil, non-vegetated pathways, or severe stress.")
    )

    fun getHistoricalPasses(): List<SatellitePass> {
        return listOf(
            SatellitePass(
                acquisitionDate = "10 Oct 2026",
                satelliteSource = "Copernicus Sentinel-2B",
                spatialResolution = "10m Multispectral (B4 Red, B8 NIR)",
                cloudCoverPct = 0.8,
                averageNdvi = 0.68,
                fieldNdviMap = mapOf(
                    "field_1" to 0.72, // Plot A Cotton
                    "field_2" to 0.54, // Plot B
                    "field_3" to 0.76, // Plot C Chilli
                    "field_4" to 0.48  // Plot D
                ),
                vegetationSummary = "Healthy vegetative expansion across Plot A & C. Plot C (Chilli) displays peak canopy reflectance."
            ),
            SatellitePass(
                acquisitionDate = "25 Sep 2026",
                satelliteSource = "Copernicus Sentinel-2A",
                spatialResolution = "10m Multispectral (B4 Red, B8 NIR)",
                cloudCoverPct = 3.4,
                averageNdvi = 0.59,
                fieldNdviMap = mapOf(
                    "field_1" to 0.61,
                    "field_2" to 0.48,
                    "field_3" to 0.65,
                    "field_4" to 0.42
                ),
                vegetationSummary = "Rapid squaring stage detected in Cotton. Uniform greening across north-facing furrows."
            ),
            SatellitePass(
                acquisitionDate = "10 Sep 2026",
                satelliteSource = "Copernicus Sentinel-2B",
                spatialResolution = "10m Multispectral (B4 Red, B8 NIR)",
                cloudCoverPct = 5.1,
                averageNdvi = 0.42,
                fieldNdviMap = mapOf(
                    "field_1" to 0.45,
                    "field_2" to 0.38,
                    "field_3" to 0.44,
                    "field_4" to 0.35
                ),
                vegetationSummary = "Early vegetative stand establishment following post-monsoon transplanting."
            )
        )
    }

    /**
     * Compute NDVI from Near-Infrared (NIR) and Red surface reflectance.
     * Formula: NDVI = (NIR - Red) / (NIR + Red)
     */
    fun calculateNdvi(nirReflectance: Double, redReflectance: Double): Double {
        val sum = nirReflectance + redReflectance
        if (sum == 0.0) return 0.0
        return ((nirReflectance - redReflectance) / sum).coerceIn(-1.0, 1.0)
    }
}
