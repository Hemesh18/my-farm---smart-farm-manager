package com.example.data.repository

import android.graphics.Bitmap
import com.example.data.local.FarmDao
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.util.SecurityUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class FarmRepository(
    private val dao: FarmDao
) {
    // User Accounts & Authentication
    suspend fun registerUser(
        email: String,
        passwordRaw: String,
        fullName: String,
        phone: String = "",
        preferredLanguage: String = "English",
        state: String = "",
        district: String = "",
        village: String = "",
        pinCode: String = ""
    ): Result<UserAccount> {
        val existing = dao.getUserByEmail(email.trim().lowercase())
        if (existing != null) {
            return Result.failure(Exception("An account with email '$email' already exists."))
        }

        val newUser = UserAccount(
            email = email.trim().lowercase(),
            passwordHash = SecurityUtils.hashPassword(passwordRaw),
            fullName = fullName.trim(),
            phone = phone.trim(),
            preferredLanguage = preferredLanguage,
            state = state,
            district = district,
            village = village,
            pinCode = pinCode,
            role = if (email.contains("admin")) "ADMIN" else "FARMER",
            subscriptionPlan = "FREE",
            subscriptionStatus = "ACTIVE",
            isOnboardingCompleted = false
        )
        dao.insertUser(newUser)

        dao.insertAuditLog(
            AuditLog(
                userId = newUser.id,
                userEmail = newUser.email,
                action = "USER_REGISTER",
                details = "New farmer account registered: ${newUser.fullName}"
            )
        )

        return Result.success(newUser)
    }

    suspend fun loginUser(email: String, passwordRaw: String): Result<UserAccount> {
        val user = dao.getUserByEmail(email.trim().lowercase())
            ?: return Result.failure(Exception("No account found with this email. Please sign up."))

        if (!SecurityUtils.verifyPassword(passwordRaw, user.passwordHash)) {
            return Result.failure(Exception("Incorrect password. Please try again."))
        }

        dao.insertAuditLog(
            AuditLog(
                userId = user.id,
                userEmail = user.email,
                action = "USER_LOGIN",
                details = "Successful login for ${user.email}"
            )
        )

        return Result.success(user)
    }

    suspend fun requestPasswordReset(email: String): Result<String> {
        val cleanEmail = email.trim().lowercase()
        val now = System.currentTimeMillis()

        // Rate limiting check: max 1 reset request every 60 seconds
        val latest = dao.getLatestActiveTokenForEmail(cleanEmail)
        if (latest != null && (now - latest.createdAt) < 60_000) {
            return Result.failure(Exception("Please wait at least 60 seconds before requesting another reset code."))
        }

        val resetCode = java.util.UUID.randomUUID().toString().take(8).uppercase()
        val token = PasswordResetToken(
            token = resetCode,
            userEmail = cleanEmail,
            expiresAt = now + (15L * 60 * 1000), // 15 mins
            isUsed = false,
            createdAt = now
        )
        dao.insertResetToken(token)

        try {
            com.google.firebase.auth.FirebaseAuth.getInstance().sendPasswordResetEmail(cleanEmail)
        } catch (_: Throwable) {
            // Firebase Auth might not be active, fallback smoothly to token flow
        }

        dao.insertAuditLog(
            AuditLog(
                userId = "ANONYMOUS",
                userEmail = cleanEmail,
                action = "PASSWORD_RESET_REQUEST",
                details = "Password reset token generated for $cleanEmail"
            )
        )

        return Result.success(resetCode)
    }

    suspend fun resetPasswordWithToken(
        email: String,
        tokenCode: String,
        newPasswordRaw: String
    ): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        val cleanToken = tokenCode.trim().uppercase()

        if (newPasswordRaw.length < 6) {
            return Result.failure(Exception("New password must be at least 6 characters long."))
        }

        val storedToken = dao.getResetToken(cleanToken)
            ?: return Result.failure(Exception("Invalid reset token. Please check code or request a new reset link."))

        if (!storedToken.userEmail.equals(cleanEmail, ignoreCase = true)) {
            return Result.failure(Exception("Reset token does not match the provided email address."))
        }

        if (storedToken.isUsed) {
            return Result.failure(Exception("This reset token has already been used. Please request a new one."))
        }

        if (System.currentTimeMillis() > storedToken.expiresAt) {
            return Result.failure(Exception("This reset token has expired. Reset links expire after 15 minutes."))
        }

        val user = dao.getUserByEmail(cleanEmail)
            ?: return Result.failure(Exception("No account found matching $cleanEmail."))

        val newHash = SecurityUtils.hashPassword(newPasswordRaw)
        val updatedUser = user.copy(passwordHash = newHash)
        dao.updateUser(updatedUser)

        dao.updateResetToken(storedToken.copy(isUsed = true))

        dao.insertAuditLog(
            AuditLog(
                userId = user.id,
                userEmail = user.email,
                action = "PASSWORD_RESET_SUCCESS",
                details = "Password reset successfully completed for $cleanEmail"
            )
        )

        return Result.success(Unit)
    }

    suspend fun getUserById(userId: String): UserAccount? = dao.getUserById(userId)
    suspend fun insertUser(user: UserAccount) = dao.insertUser(user)
    suspend fun updateUser(user: UserAccount) = dao.updateUser(user)
    fun getAllUsersFlow(): Flow<List<UserAccount>> = dao.getAllUsersFlow()
    fun getAllAuditLogs(): Flow<List<AuditLog>> = dao.getAllAuditLogs()

    suspend fun logAudit(userId: String, email: String, action: String, details: String) {
        dao.insertAuditLog(
            AuditLog(userId = userId, userEmail = email, action = action, details = details)
        )
    }

    // Farm Profiles (User Scoped)
    fun getFarmsForUser(userId: String): Flow<List<FarmProfile>> = dao.getFarmsForUser(userId)
    fun getDefaultFarmFlow(userId: String): Flow<FarmProfile?> = dao.getDefaultFarmFlow(userId)
    suspend fun getDefaultFarm(userId: String): FarmProfile? = dao.getDefaultFarm(userId)
    suspend fun getFarmById(farmId: String): FarmProfile? = dao.getFarmById(farmId)
    suspend fun saveFarmProfile(profile: FarmProfile) = dao.insertOrUpdateFarmProfile(profile)
    suspend fun deleteFarmProfile(profile: FarmProfile) = dao.deleteFarmProfile(profile)

    // Legacy fallback
    fun getFarmProfileFlow(): Flow<FarmProfile?> = dao.getFarmProfileFlow()
    suspend fun getFarmProfile(): FarmProfile? = dao.getFarmProfile()

    // Fields / Plots
    fun getFieldsForFarm(userId: String, farmId: String): Flow<List<FieldPlot>> = dao.getFieldsForFarm(userId, farmId)
    fun getAllFieldsForUser(userId: String): Flow<List<FieldPlot>> = dao.getAllFieldsForUser(userId)
    fun getAllFields(): Flow<List<FieldPlot>> = dao.getAllFields()
    suspend fun insertField(field: FieldPlot) = dao.insertField(field)
    suspend fun deleteField(field: FieldPlot) = dao.deleteField(field)

    // Crops
    fun getCropsForFarm(userId: String, farmId: String): Flow<List<CropRecord>> = dao.getCropsForFarm(userId, farmId)
    fun getActiveCropsForFarm(userId: String, farmId: String): Flow<List<CropRecord>> = dao.getActiveCropsForFarm(userId, farmId)
    fun getAllCropsForUser(userId: String): Flow<List<CropRecord>> = dao.getAllCropsForUser(userId)
    fun getActiveCropsForUser(userId: String): Flow<List<CropRecord>> = dao.getActiveCropsForUser(userId)
    fun getAllCrops(): Flow<List<CropRecord>> = dao.getAllCrops()
    fun getActiveCrops(): Flow<List<CropRecord>> = dao.getActiveCrops()
    fun getCropsByYear(userId: String, year: Int): Flow<List<CropRecord>> = dao.getCropsByYear(userId, year)
    fun getCropByIdFlow(cropId: String): Flow<CropRecord?> = dao.getCropByIdFlow(cropId)
    suspend fun getCropById(cropId: String): CropRecord? = dao.getCropById(cropId)
    suspend fun insertCrop(crop: CropRecord) = dao.insertCrop(crop)
    suspend fun updateCrop(crop: CropRecord) = dao.updateCrop(crop)
    suspend fun deleteCrop(crop: CropRecord) = dao.deleteCrop(crop)

    // Tasks
    fun getTasksForFarm(userId: String, farmId: String): Flow<List<FarmTask>> = dao.getTasksForFarm(userId, farmId)
    fun getAllTasksForUser(userId: String): Flow<List<FarmTask>> = dao.getAllTasksForUser(userId)
    fun getAllTasks(): Flow<List<FarmTask>> = dao.getAllTasks()
    fun getTasksForCrop(cropId: String): Flow<List<FarmTask>> = dao.getTasksForCrop(cropId)
    suspend fun insertTask(task: FarmTask) = dao.insertTask(task)
    suspend fun updateTask(task: FarmTask) = dao.updateTask(task)
    suspend fun deleteTask(task: FarmTask) = dao.deleteTask(task)

    // Irrigation
    fun getIrrigationLogsForFarm(userId: String, farmId: String): Flow<List<IrrigationLog>> = dao.getIrrigationLogsForFarm(userId, farmId)
    fun getAllIrrigationLogsForUser(userId: String): Flow<List<IrrigationLog>> = dao.getAllIrrigationLogsForUser(userId)
    fun getAllIrrigationLogs(): Flow<List<IrrigationLog>> = dao.getAllIrrigationLogs()
    fun getIrrigationLogsForCrop(cropId: String): Flow<List<IrrigationLog>> = dao.getIrrigationLogsForCrop(cropId)
    suspend fun insertIrrigationLog(log: IrrigationLog) = dao.insertIrrigationLog(log)
    suspend fun deleteIrrigationLog(log: IrrigationLog) = dao.deleteIrrigationLog(log)

    // Fertilizer
    fun getFertilizerLogsForFarm(userId: String, farmId: String): Flow<List<FertilizerLog>> = dao.getFertilizerLogsForFarm(userId, farmId)
    fun getAllFertilizerLogsForUser(userId: String): Flow<List<FertilizerLog>> = dao.getAllFertilizerLogsForUser(userId)
    fun getAllFertilizerLogs(): Flow<List<FertilizerLog>> = dao.getAllFertilizerLogs()
    fun getFertilizerLogsForCrop(cropId: String): Flow<List<FertilizerLog>> = dao.getFertilizerLogsForCrop(cropId)
    suspend fun insertFertilizerLog(log: FertilizerLog) = dao.insertFertilizerLog(log)
    suspend fun deleteFertilizerLog(log: FertilizerLog) = dao.deleteFertilizerLog(log)

    // Transactions
    fun getTransactionsForFarm(userId: String, farmId: String): Flow<List<FarmTransaction>> = dao.getTransactionsForFarm(userId, farmId)
    fun getAllTransactionsForUser(userId: String): Flow<List<FarmTransaction>> = dao.getAllTransactionsForUser(userId)
    fun getAllTransactions(): Flow<List<FarmTransaction>> = dao.getAllTransactions()
    fun getTransactionsForCrop(cropId: String): Flow<List<FarmTransaction>> = dao.getTransactionsForCrop(cropId)
    fun getTransactionsByYear(userId: String, year: Int): Flow<List<FarmTransaction>> = dao.getTransactionsByYear(userId, year)
    suspend fun insertTransaction(transaction: FarmTransaction) = dao.insertTransaction(transaction)
    suspend fun deleteTransaction(transaction: FarmTransaction) = dao.deleteTransaction(transaction)

    // Disease Scans
    fun getDiseaseScansForUser(userId: String): Flow<List<DiseaseScanRecord>> = dao.getDiseaseScansForUser(userId)
    fun getAllDiseaseScans(): Flow<List<DiseaseScanRecord>> = dao.getAllDiseaseScans()
    suspend fun insertDiseaseScan(scan: DiseaseScanRecord) = dao.insertDiseaseScan(scan)

    // Journal
    fun getJournalEntriesForFarm(userId: String, farmId: String): Flow<List<JournalEntry>> = dao.getJournalEntriesForFarm(userId, farmId)
    fun getAllJournalEntriesForUser(userId: String): Flow<List<JournalEntry>> = dao.getAllJournalEntriesForUser(userId)
    fun getAllJournalEntries(): Flow<List<JournalEntry>> = dao.getAllJournalEntries()
    suspend fun insertJournalEntry(entry: JournalEntry) = dao.insertJournalEntry(entry)

    // Soil Tests
    fun getSoilTestsForFarm(userId: String, farmId: String): Flow<List<SoilTestRecord>> = dao.getSoilTestsForFarm(userId, farmId)
    fun getAllSoilTestsForUser(userId: String): Flow<List<SoilTestRecord>> = dao.getAllSoilTestsForUser(userId)
    fun getAllSoilTests(): Flow<List<SoilTestRecord>> = dao.getAllSoilTests()
    suspend fun insertSoilTest(test: SoilTestRecord) = dao.insertSoilTest(test)

    // AI Chat History
    fun getAiMessagesForUser(userId: String): Flow<List<AiChatMessage>> = dao.getAiMessagesForUser(userId)
    fun getAllAiMessages(): Flow<List<AiChatMessage>> = dao.getAllAiMessages()
    suspend fun insertAiMessage(message: AiChatMessage) = dao.insertAiMessage(message)
    suspend fun clearAiChatForUser(userId: String) = dao.clearAiChatForUser(userId)
    suspend fun clearAiChat() = dao.clearAiChat()

    // Global Search Across History (User Scoped)
    suspend fun searchFarmHistory(userId: String, query: String): SearchResults {
        val q = query.trim()
        if (q.isEmpty()) return SearchResults(emptyList(), emptyList(), emptyList())
        val crops = dao.searchCrops(userId, q)
        val transactions = dao.searchTransactions(userId, q)
        val journals = dao.searchJournal(userId, q)
        return SearchResults(crops, transactions, journals)
    }

    // Weather
    suspend fun fetchWeather(lat: Double, lon: Double): WeatherInfo {
        return WeatherApiClient.fetchWeather(lat, lon)
    }

    // AI Assistant (Grounded in current user's farm records)
    suspend fun queryAiAssistant(
        userId: String,
        farmId: String?,
        userPrompt: String,
        currentWeather: WeatherInfo?,
        language: String
    ): FarmAssistantResult {
        val profile = farmId?.let { dao.getFarmById(it) } ?: dao.getDefaultFarm(userId)
        val activeCrops = dao.getActiveCropsForUser(userId).firstOrNull() ?: emptyList()
        val allCrops = dao.getAllCropsForUser(userId).firstOrNull() ?: emptyList()
        val historyCrops = allCrops.filter { it.isArchived || it.year < 2026 }
        val recentTasks = dao.getAllTasksForUser(userId).firstOrNull() ?: emptyList()
        val recentTransactions = dao.getAllTransactionsForUser(userId).firstOrNull() ?: emptyList()
        val recentIrrigation = dao.getAllIrrigationLogsForUser(userId).firstOrNull() ?: emptyList()

        return GeminiService.askFarmAssistant(
            userPrompt = userPrompt,
            farmProfile = profile,
            activeCrops = activeCrops,
            historicalCrops = historyCrops,
            recentTasks = recentTasks,
            recentTransactions = recentTransactions,
            recentIrrigation = recentIrrigation,
            weatherInfo = currentWeather,
            language = language
        )
    }

    // Disease Scanner AI
    suspend fun diagnoseCropDisease(
        cropName: String,
        fieldName: String,
        symptoms: String,
        bitmap: Bitmap?,
        language: String
    ): DiseaseScanResult {
        return GeminiService.diagnoseCropDisease(cropName, fieldName, symptoms, bitmap, language)
    }

    // Farm Boundaries
    fun getBoundaryForFarm(userId: String, farmId: String): Flow<FarmBoundaryRecord?> =
        dao.getBoundaryForFarmFlow(userId, farmId)

    suspend fun saveFarmBoundary(
        context: android.content.Context,
        boundary: FarmBoundaryRecord
    ) {
        dao.insertOrUpdateBoundary(boundary)

        if (boundary.centerLatitude != 0.0 && boundary.centerLongitude != 0.0) {
            val farm = dao.getFarmById(boundary.farmId)
            if (farm != null) {
                val updatedFarm = farm.copy(
                    latitude = boundary.centerLatitude,
                    longitude = boundary.centerLongitude,
                    totalArea = if (boundary.areaAcres > 0) boundary.areaAcres else farm.totalArea,
                    locationSource = "MAP_BOUNDARY"
                )
                dao.insertOrUpdateFarmProfile(updatedFarm)
            }
        }

        try {
            val dbId = context.getString(com.example.R.string.firestore_database_id)
            val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance(dbId)
            val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
            val uid = auth.currentUser?.uid ?: boundary.userId

            val firestoreMap = hashMapOf(
                "id" to boundary.id,
                "userId" to uid,
                "farmId" to boundary.farmId,
                "farmName" to boundary.farmName,
                "boundaryPointsJson" to boundary.boundaryPointsJson,
                "areaAcres" to boundary.areaAcres,
                "areaHectares" to boundary.areaHectares,
                "centerLatitude" to boundary.centerLatitude,
                "centerLongitude" to boundary.centerLongitude,
                "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
                "createdAt" to boundary.createdAt
            )

            firestore.collection("users").document(uid)
                .collection("boundaries").document(boundary.id)
                .set(firestoreMap)

            firestore.collection("farm_boundaries").document(boundary.id)
                .set(firestoreMap)
        } catch (e: Throwable) {
            android.util.Log.w("FarmRepository", "Firestore boundary sync skipped: ${e.message}")
        }
    }
}

data class SearchResults(
    val matchedCrops: List<CropRecord>,
    val matchedTransactions: List<FarmTransaction>,
    val matchedJournals: List<JournalEntry>
)
