package com.example.data.util

import java.security.MessageDigest

object SecurityUtils {
    /**
     * Compute SHA-256 hash with an application-level salt for user passwords.
     */
    fun hashPassword(password: String): String {
        val salt = "my_farm_saas_salt_2026_secure"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest("$salt:$password".toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(raw: String, hash: String): Boolean {
        return hashPassword(raw) == hash
    }
}
