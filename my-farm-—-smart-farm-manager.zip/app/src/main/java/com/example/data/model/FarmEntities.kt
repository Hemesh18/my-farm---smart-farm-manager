package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "user_accounts")
data class UserAccount(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val email: String,
    val passwordHash: String,
    val fullName: String,
    val phone: String = "",
    val state: String = "Maharashtra",
    val district: String = "Akola",
    val taluka: String = "Barshitakli",
    val village: String = "Barshitakli Rural",
    val pinCode: String = "444401",
    val preferredLanguage: String = "English",
    val measurementUnit: String = "Acre",
    val role: String = "FARMER", // FARMER, ADMIN
    val subscriptionPlan: String = "FREE", // FREE, PRO_MONTHLY, ENTERPRISE
    val subscriptionStatus: String = "ACTIVE", // ACTIVE, TRIAL, EXPIRED
    val trialEndsAt: Long = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000),
    val isOnboardingCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "password_reset_tokens")
data class PasswordResetToken(
    @PrimaryKey val token: String = UUID.randomUUID().toString().take(8).uppercase(),
    val userEmail: String,
    val expiresAt: Long = System.currentTimeMillis() + (15L * 60 * 1000), // 15 mins
    val isUsed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val userEmail: String,
    val action: String, // LOGIN, REGISTER, EXPORT_PDF, UPDATE_FARM, ADD_CROP, DELETE_RECORD
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "farm_profiles")
data class FarmProfile(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmName: String = "My Farm",
    val farmerName: String = "Farmer",
    val email: String = "farmer@myfarm.com",
    val village: String = "Akola Rural",
    val district: String = "Akola",
    val state: String = "Maharashtra",
    val country: String = "India",
    val pinCode: String = "444001",
    val latitude: Double? = 20.7002,
    val longitude: Double? = 77.0082,
    val locationAccuracyMeters: Float? = null,
    val locationSource: String = "MANUAL", // GPS, MANUAL, MAP_PIN
    val totalArea: Double = 12.5,
    val areaUnit: String = "Acre", // Acre, Hectare, Guntha, Sq Meter
    val primarySoilType: String = "Black Cotton Soil",
    val soilPh: Double? = 7.4,
    val irrigationSource: String = "Borewell & Drip Irrigation",
    val waterAvailability: String = "Adequate Year-round",
    val farmingType: String = "Mixed (Organic + Conventional)",
    val preferredLanguage: String = "English", // English, Marathi, Hindi
    val currency: String = "INR",
    val isDefault: Boolean = true,
    val isOnboardingComplete: Boolean = true,
    val isDemoMode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "fields")
data class FieldPlot(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val name: String,
    val area: Double,
    val areaUnit: String = "Acre",
    val soilType: String = "Black Cotton Soil",
    val irrigationMethod: String = "Drip",
    val notes: String = "",
    val colorHex: String = "#2E7D32"
)

@Entity(tableName = "crops")
data class CropRecord(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val fieldId: String,
    val fieldName: String,
    val cropName: String, // Cotton, Soybean, Wheat, Maize, etc.
    val variety: String = "Hybrid",
    val season: String = "Kharif", // Kharif, Rabi, Zaid
    val year: Int = 2026,
    val sowingDateMillis: Long = System.currentTimeMillis() - (45L * 24 * 60 * 60 * 1000),
    val seedQuantity: Double = 5.0,
    val seedUnit: String = "Kg",
    val plantedArea: Double = 4.0,
    val areaUnit: String = "Acre",
    val plantingMethod: String = "Direct Seeding",
    val seedSupplier: String = "Mahyco Seeds",
    val seedCost: Double = 2400.0,
    val expectedDurationDays: Int = 150,
    val expectedHarvestDateMillis: Long = System.currentTimeMillis() + (105L * 24 * 60 * 60 * 1000),
    val actualHarvestDateMillis: Long? = null,
    val expectedYield: Double = 12.0,
    val actualYield: Double? = null,
    val yieldUnit: String = "Quintal",
    val status: String = "Growing", // Planned, Planted, Growing, Flowering, Fruiting, Ready for Harvest, Harvested, Archived
    val healthCondition: String = "Good", // Excellent, Good, Moderate, Stressed
    val currentGrowthStage: String = "Vegetative Growth",
    val photoUrl: String? = null,
    val notes: String = "",
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "farm_tasks")
data class FarmTask(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val title: String,
    val description: String = "",
    val cropId: String? = null,
    val cropName: String? = null,
    val fieldId: String? = null,
    val fieldName: String? = null,
    val category: String = "Inspection", // Sowing, Irrigation, Fertilizer, Spraying, Weeding, Harvesting, Maintenance, Inspection
    val dueDateMillis: Long = System.currentTimeMillis(),
    val priority: String = "Medium", // High, Medium, Low
    val isCompleted: Boolean = false,
    val completedAtMillis: Long? = null,
    val isAiSuggested: Boolean = false,
    val aiReason: String? = null,
    val reminderEnabled: Boolean = true
)

@Entity(tableName = "irrigation_logs")
data class IrrigationLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val fieldId: String,
    val fieldName: String,
    val cropId: String? = null,
    val cropName: String? = null,
    val dateMillis: Long = System.currentTimeMillis(),
    val method: String = "Drip", // Drip, Sprinkler, Flood, Furrow
    val durationHours: Double = 2.5,
    val waterQuantityLiters: Double = 15000.0,
    val pumpRunHours: Double = 2.5,
    val electricityFuelCost: Double = 150.0,
    val soilMoistureBeforePct: Double? = 28.0,
    val soilMoistureAfterPct: Double? = 65.0,
    val notes: String = ""
)

@Entity(tableName = "fertilizer_logs")
data class FertilizerLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val fieldId: String,
    val fieldName: String,
    val cropId: String? = null,
    val cropName: String? = null,
    val dateMillis: Long = System.currentTimeMillis(),
    val fertilizerName: String = "Urea & DAP",
    val quantity: Double = 50.0,
    val unit: String = "Kg",
    val applicationMethod: String = "Soil Application", // Soil Application, Fertigation, Foliar Spray
    val cost: Double = 1850.0,
    val notes: String = ""
)

@Entity(tableName = "transactions")
data class FarmTransaction(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val type: String = "EXPENSE", // EXPENSE or INCOME
    val category: String, // Seeds, Fertilizers, Pesticides, Labor, Fuel, Equipment, Irrigation, Transport, Harvest Sales, By-products
    val amount: Double,
    val dateMillis: Long = System.currentTimeMillis(),
    val year: Int = 2026,
    val season: String = "Kharif",
    val cropId: String? = null,
    val cropName: String? = null,
    val fieldId: String? = null,
    val fieldName: String? = null,
    val partyName: String = "", // Vendor or Buyer
    val paymentMode: String = "Cash", // Cash, UPI, Bank Transfer
    val receiptNote: String = "",
    val receiptPhotoUrl: String? = null
)

@Entity(tableName = "disease_scans")
data class DiseaseScanRecord(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val cropName: String,
    val fieldName: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val photoUri: String? = null,
    val symptomsInput: String = "",
    val diagnosisTitle: String,
    val diagnosisConfidence: String = "85%",
    val identifiedIssueType: String = "Fungal Infection", // Fungal, Bacterial, Pest, Nutrient Deficiency, Environmental Stress
    val visualSigns: String = "",
    val safeImmediateActions: String = "",
    val preventionGuidance: String = "",
    val expertConsultationRecommendation: String = "Consult local Krishi Vigyan Kendra (KVK) if symptoms spread beyond 10% of field.",
    val followUpDateMillis: Long = System.currentTimeMillis() + (3L * 24 * 60 * 60 * 1000),
    val status: String = "Monitoring" // Monitoring, Treated, Resolved
)

@Entity(tableName = "journal_entries")
data class JournalEntry(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val title: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val fieldName: String = "All Fields",
    val cropName: String = "",
    val observationType: String = "General Growth", // Pest Sighting, Weather Event, Work Done, Growth Milestone
    val notes: String,
    val photoUri: String? = null,
    val weatherSummary: String = "Sunny, 29°C"
)

@Entity(tableName = "soil_tests")
data class SoilTestRecord(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val fieldId: String,
    val fieldName: String,
    val testDateMillis: Long = System.currentTimeMillis() - (60L * 24 * 60 * 60 * 1000),
    val ph: Double = 7.4,
    val organicCarbonPct: Double = 0.55,
    val nitrogenKgHa: Double = 180.0,
    val phosphorusKgHa: Double = 18.5,
    val potassiumKgHa: Double = 320.0,
    val laboratoryName: String = "District Agriculture Soil Testing Lab",
    val recommendations: String = "Apply organic compost to improve organic carbon. Supplement balanced nitrogen."
)

@Entity(tableName = "ai_chat_messages")
data class AiChatMessage(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val citedRecords: String? = null
)

@Entity(tableName = "farm_boundaries")
data class FarmBoundaryRecord(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "demo_user",
    val farmId: String = "default_farm",
    val farmName: String = "My Farm",
    val boundaryPointsJson: String = "[]",
    val areaAcres: Double = 0.0,
    val areaHectares: Double = 0.0,
    val centerLatitude: Double = 20.5841,
    val centerLongitude: Double = 77.0620,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

