package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import com.example.data.util.SecurityUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserAccount::class,
        AuditLog::class,
        FarmProfile::class,
        FieldPlot::class,
        CropRecord::class,
        FarmTask::class,
        IrrigationLog::class,
        FertilizerLog::class,
        FarmTransaction::class,
        DiseaseScanRecord::class,
        JournalEntry::class,
        SoilTestRecord::class,
        AiChatMessage::class,
        PasswordResetToken::class,
        FarmBoundaryRecord::class
    ],
    version = 4,
    exportSchema = false
)
abstract class FarmDatabase : RoomDatabase() {
    abstract fun farmDao(): FarmDao

    companion object {
        @Volatile
        private var INSTANCE: FarmDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): FarmDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FarmDatabase::class.java,
                    "my_farm_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(FarmDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class FarmDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.farmDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: FarmDao) {
            val now = System.currentTimeMillis()
            val dayMillis = 24L * 60 * 60 * 1000
            val demoUserId = "demo_user"

            // 0. Seed Default Farmer User Account
            val defaultUser = UserAccount(
                id = demoUserId,
                email = "hemeshpatel1812@gmail.com",
                passwordHash = SecurityUtils.hashPassword("farmer123"),
                fullName = "Hemesh Patel",
                phone = "+91 98220 12345",
                state = "Maharashtra",
                district = "Akola",
                taluka = "Barshitakli",
                village = "Barshitakli Rural",
                pinCode = "444401",
                role = "ADMIN", // Platform administrator role
                subscriptionPlan = "PRO_MONTHLY",
                subscriptionStatus = "ACTIVE",
                isOnboardingCompleted = true
            )
            dao.insertUser(defaultUser)

            dao.insertAuditLog(
                AuditLog(
                    userId = demoUserId,
                    userEmail = defaultUser.email,
                    action = "SYSTEM_INIT",
                    details = "My Farm SaaS database initialized with tenant isolation."
                )
            )

            // 1. Initial Farm Profile for Demo Account
            val profile = FarmProfile(
                id = "farm_vasant_akola",
                userId = demoUserId,
                farmName = "Vasant Krishi Farm",
                farmerName = "Hemesh Patel",
                email = "hemeshpatel1812@gmail.com",
                village = "Barshitakli",
                district = "Akola",
                state = "Maharashtra",
                country = "India",
                pinCode = "444401",
                latitude = 20.5841,
                longitude = 77.0620,
                locationAccuracyMeters = 8.5f,
                locationSource = "GPS",
                totalArea = 15.0,
                areaUnit = "Acre",
                primarySoilType = "Black Cotton Soil (Regur)",
                soilPh = 7.6,
                irrigationSource = "Borewell & Solar Drip",
                waterAvailability = "Adequate Year-round",
                farmingType = "Mixed Sustainable",
                preferredLanguage = "English",
                currency = "INR",
                isDefault = true,
                isOnboardingComplete = true,
                isDemoMode = false
            )
            dao.insertOrUpdateFarmProfile(profile)

            // 2. Field Plots for Demo Account
            val field1 = FieldPlot(id = "field_1", userId = demoUserId, farmId = profile.id, name = "Plot A (North Valley)", area = 5.0, soilType = "Deep Black Soil", irrigationMethod = "Drip System", colorHex = "#2E7D32")
            val field2 = FieldPlot(id = "field_2", userId = demoUserId, farmId = profile.id, name = "Plot B (Borewell East)", area = 4.5, soilType = "Medium Black Soil", irrigationMethod = "Sprinkler", colorHex = "#388E3C")
            val field3 = FieldPlot(id = "field_3", userId = demoUserId, farmId = profile.id, name = "Plot C (Canal Side)", area = 3.5, soilType = "Alluvial Loam", irrigationMethod = "Flood / Furrow", colorHex = "#43A047")
            val field4 = FieldPlot(id = "field_4", userId = demoUserId, farmId = profile.id, name = "Plot D (Orchard Zone)", area = 2.0, soilType = "Red Loamy Soil", irrigationMethod = "Drip Irrigation", colorHex = "#1B5E20")
            dao.insertField(field1)
            dao.insertField(field2)
            dao.insertField(field3)
            dao.insertField(field4)

            // 3. Multi-year Crop History for Demo Account
            dao.insertCrop(CropRecord(
                id = "crop_2024_cotton",
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field1.id,
                fieldName = field1.name,
                cropName = "Cotton (Kapas)",
                variety = "RCH-659 BG II",
                season = "Kharif",
                year = 2024,
                sowingDateMillis = now - (480L * dayMillis),
                expectedDurationDays = 160,
                expectedHarvestDateMillis = now - (320L * dayMillis),
                actualHarvestDateMillis = now - (315L * dayMillis),
                plantedArea = 5.0,
                seedQuantity = 6.0,
                seedCost = 3600.0,
                expectedYield = 16.0,
                actualYield = 15.2,
                yieldUnit = "Quintal",
                status = "Harvested",
                healthCondition = "Good",
                currentGrowthStage = "Harvested",
                isArchived = true,
                notes = "Successful season. Good fiber quality. Total revenue Rs 1,06,400."
            ))

            dao.insertCrop(CropRecord(
                id = "crop_2025_soybean",
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field2.id,
                fieldName = field2.name,
                cropName = "Soybean",
                variety = "JS-335 Certified",
                season = "Kharif",
                year = 2025,
                sowingDateMillis = now - (220L * dayMillis),
                expectedDurationDays = 100,
                expectedHarvestDateMillis = now - (120L * dayMillis),
                actualHarvestDateMillis = now - (118L * dayMillis),
                plantedArea = 4.5,
                seedQuantity = 110.0,
                seedCost = 7700.0,
                expectedYield = 38.0,
                actualYield = 36.5,
                yieldUnit = "Quintal",
                status = "Harvested",
                healthCondition = "Good",
                currentGrowthStage = "Harvested",
                isArchived = true,
                notes = "High pod density. Market rate received: Rs 4,800/quintal."
            ))

            val cropActiveCotton = CropRecord(
                id = "crop_2026_cotton",
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field1.id,
                fieldName = field1.name,
                cropName = "Cotton (Kapas)",
                variety = "Ajit-155 BG II",
                season = "Kharif",
                year = 2026,
                sowingDateMillis = now - (52L * dayMillis),
                expectedDurationDays = 155,
                expectedHarvestDateMillis = now + (103L * dayMillis),
                plantedArea = 5.0,
                seedQuantity = 6.0,
                seedCost = 3900.0,
                expectedYield = 18.0,
                actualYield = null,
                yieldUnit = "Quintal",
                status = "Growing",
                healthCondition = "Good",
                currentGrowthStage = "Squaring & Early Flowering",
                isArchived = false,
                notes = "Good canopy formation. Pest monitoring active. Bollworm traps installed."
            )
            dao.insertCrop(cropActiveCotton)

            val cropActiveChilli = CropRecord(
                id = "crop_2026_chilli",
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field3.id,
                fieldName = field3.name,
                cropName = "Green Chilli (Mirchi)",
                variety = "Armour F1 Hybrid",
                season = "Kharif",
                year = 2026,
                sowingDateMillis = now - (38L * dayMillis),
                expectedDurationDays = 120,
                expectedHarvestDateMillis = now + (82L * dayMillis),
                plantedArea = 3.5,
                seedQuantity = 0.5,
                seedCost = 4200.0,
                expectedYield = 45.0,
                actualYield = null,
                yieldUnit = "Quintal",
                status = "Flowering",
                healthCondition = "Excellent",
                currentGrowthStage = "Flowering & Fruit Setting",
                isArchived = false,
                notes = "Transplanted healthy seedlings. Foliar micronutrients applied."
            )
            dao.insertCrop(cropActiveChilli)

            // 4. Farm Tasks for Demo Account
            dao.insertTask(FarmTask(
                userId = demoUserId,
                farmId = profile.id,
                title = "Inspect Cotton for Whitefly & Sucking Pests",
                description = "Walk through Plot A rows 4 to 12. Check underside of leaves for nymph colonies.",
                cropId = cropActiveCotton.id,
                cropName = cropActiveCotton.cropName,
                fieldId = field1.id,
                fieldName = field1.name,
                category = "Inspection",
                dueDateMillis = now + (1L * dayMillis),
                priority = "High",
                isCompleted = false,
                isAiSuggested = true,
                aiReason = "Humid weather over next 48h increases sucking pest risk at flowering stage."
            ))

            dao.insertTask(FarmTask(
                userId = demoUserId,
                farmId = profile.id,
                title = "Operate Drip Fertigation for Chilli (19:19:19)",
                description = "Run 4 kg water-soluble NPK through Venturi injector for 2 hours.",
                cropId = cropActiveChilli.id,
                cropName = cropActiveChilli.cropName,
                fieldId = field3.id,
                fieldName = field3.name,
                category = "Fertilizer",
                dueDateMillis = now + (2L * dayMillis),
                priority = "Medium",
                isCompleted = false,
                isAiSuggested = true,
                aiReason = "Chilli crop entered fruit set stage; phosphorus and potassium needed."
            ))

            // 5. Irrigation Logs
            dao.insertIrrigationLog(IrrigationLog(
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field1.id,
                fieldName = field1.name,
                cropId = cropActiveCotton.id,
                cropName = cropActiveCotton.cropName,
                dateMillis = now - (2L * dayMillis),
                method = "Drip",
                durationHours = 3.0,
                waterQuantityLiters = 18000.0,
                pumpRunHours = 3.0,
                electricityFuelCost = 120.0,
                soilMoistureBeforePct = 26.0,
                soilMoistureAfterPct = 68.0,
                notes = "Scheduled morning watering. Soil absorbed moisture well."
            ))

            // 6. Fertilizer Logs
            dao.insertFertilizerLog(FertilizerLog(
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field1.id,
                fieldName = field1.name,
                cropId = cropActiveCotton.id,
                cropName = cropActiveCotton.cropName,
                dateMillis = now - (12L * dayMillis),
                fertilizerName = "Urea & DAP (18:46:0)",
                quantity = 50.0,
                unit = "Kg",
                applicationMethod = "Soil Band Placement",
                cost = 2100.0,
                notes = "Applied as top-dressing around root zone prior to light irrigation."
            ))

            // 7. Transactions
            dao.insertTransaction(FarmTransaction(
                userId = demoUserId,
                farmId = profile.id,
                type = "INCOME",
                category = "Harvest Sales",
                amount = 106400.0,
                dateMillis = now - (310L * dayMillis),
                year = 2024,
                season = "Kharif",
                cropId = "crop_2024_cotton",
                cropName = "Cotton (Kapas)",
                fieldName = "Plot A (North Valley)",
                partyName = "Kisan Cotton Ginning Mill",
                paymentMode = "Bank Transfer",
                receiptNote = "Sold 15.2 Quintal at Rs 7,000/Qtl"
            ))

            dao.insertTransaction(FarmTransaction(
                userId = demoUserId,
                farmId = profile.id,
                type = "EXPENSE",
                category = "Seeds",
                amount = 3600.0,
                dateMillis = now - (480L * dayMillis),
                year = 2024,
                season = "Kharif",
                cropId = "crop_2024_cotton",
                cropName = "Cotton (Kapas)",
                partyName = "Krishi Seva Kendra",
                receiptNote = "RCH-659 seed packets"
            ))

            dao.insertTransaction(FarmTransaction(
                userId = demoUserId,
                farmId = profile.id,
                type = "INCOME",
                category = "Harvest Sales",
                amount = 175200.0,
                dateMillis = now - (115L * dayMillis),
                year = 2025,
                season = "Kharif",
                cropId = "crop_2025_soybean",
                cropName = "Soybean",
                fieldName = "Plot B (Borewell East)",
                partyName = "APMC Mandi Akola",
                paymentMode = "Bank Transfer",
                receiptNote = "Sold 36.5 Quintal at Rs 4,800/Qtl"
            ))

            dao.insertTransaction(FarmTransaction(
                userId = demoUserId,
                farmId = profile.id,
                type = "EXPENSE",
                category = "Seeds",
                amount = 8100.0,
                dateMillis = now - (50L * dayMillis),
                year = 2026,
                season = "Kharif",
                cropName = "Cotton & Chilli",
                partyName = "Krishi Seva Kendra",
                receiptNote = "Cotton BT II + Armour Chilli seeds"
            ))

            // 8. Soil Test
            dao.insertSoilTest(SoilTestRecord(
                userId = demoUserId,
                farmId = profile.id,
                fieldId = field1.id,
                fieldName = field1.name,
                testDateMillis = now - (40L * dayMillis),
                ph = 7.6,
                organicCarbonPct = 0.58,
                nitrogenKgHa = 185.0,
                phosphorusKgHa = 19.2,
                potassiumKgHa = 340.0,
                laboratoryName = "Dr. PDKV Agriculture University Soil Lab",
                recommendations = "Slightly alkaline black soil. Medium available nitrogen, high potassium. Recommended farm yard manure (FYM) 5 tonnes/acre."
            ))

            // 9. Journal Entry
            dao.insertJournalEntry(JournalEntry(
                userId = demoUserId,
                farmId = profile.id,
                title = "Excellent Seed Germination in Plot A & C",
                dateMillis = now - (35L * dayMillis),
                fieldName = "Plot A (North Valley)",
                cropName = "Cotton",
                observationType = "Growth Milestone",
                notes = "Uniform crop stand observed. More than 92% germination rate. Weather remained warm and supportive.",
                weatherSummary = "Sunny, 31°C"
            ))
        }
    }
}
