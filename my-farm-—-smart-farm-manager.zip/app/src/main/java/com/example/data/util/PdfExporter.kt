package com.example.data.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import com.example.data.model.*
import com.example.data.remote.WeatherInfo
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

enum class ReportType(val title: String, val filenamePrefix: String) {
    COMPLETE("Complete Farm Master Report", "MyFarm_Complete_Farm_Report"),
    FARM_PROFILE("Farm Profile & Plots Report", "MyFarm_Profile_Report"),
    CROPS("Crop Lifecycle & Agronomic Report", "MyFarm_Crop_Report"),
    FINANCES("Farm Financial & P&L Statement", "MyFarm_Expense_Report"),
    WEATHER("Agricultural Weather & Spraying Report", "MyFarm_Weather_Report"),
    ACTIVITIES("Farm Tasks & Operations History", "MyFarm_Activities_Report"),
    DISEASE("Plant Pathology & Disease Scans", "MyFarm_Disease_Report")
}

object PdfExporter {

    private const val PAGE_WIDTH = 595 // Standard A4 width in points (72 dpi)
    private const val PAGE_HEIGHT = 842 // Standard A4 height in points (72 dpi)
    private const val MARGIN = 40f

    fun generateAndSavePdf(
        context: Context,
        reportType: ReportType,
        user: UserAccount?,
        farm: FarmProfile?,
        fields: List<FieldPlot>,
        crops: List<CropRecord>,
        transactions: List<FarmTransaction>,
        tasks: List<FarmTask>,
        irrigations: List<IrrigationLog>,
        fertilizers: List<FertilizerLog>,
        scans: List<DiseaseScanRecord>,
        weather: WeatherInfo?
    ): Result<File> {
        return try {
            val pdfDocument = PdfDocument()
            val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val timestampFmt = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())

            val filename = "${reportType.filenamePrefix}_$dateFmt.pdf"
            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            if (!outputDir.exists()) outputDir.mkdirs()
            val outputFile = File(outputDir, filename)

            // Canvas & Paint setup
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNumber = 1

            // Helper to start a new page
            fun startNewPage(): Pair<PdfDocument.Page, android.graphics.Canvas> {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                return Pair(page, canvas)
            }

            var (currentPage, canvas) = startNewPage()
            var currentY = MARGIN

            // Draw Header
            fun drawHeader(title: String) {
                // Top Banner Background
                paint.color = Color.rgb(27, 77, 62) // Forest Green
                canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 70f, paint)

                // App Title
                paint.color = Color.WHITE
                paint.textSize = 20f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("MY FARM — SMART FARM MANAGER", MARGIN, 42f, paint)

                paint.textSize = 10f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                canvas.drawText("Enterprise Digital Agricultural Archive & SaaS Reports", MARGIN, 58f, paint)

                currentY = 95f

                // Report Title & Meta
                paint.color = Color.rgb(30, 40, 35)
                paint.textSize = 16f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText(title, MARGIN, currentY, paint)
                currentY += 18f

                // Farmer & Farm Details
                paint.color = Color.DKGRAY
                paint.textSize = 9.5f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                val farmerInfo = "Farmer: ${user?.fullName ?: farm?.farmerName ?: "Registered Farmer"} • Farm: ${farm?.farmName ?: "Main Farm"} (${farm?.village ?: ""}, ${farm?.district ?: "Akola"})"
                canvas.drawText(farmerInfo, MARGIN, currentY, paint)
                currentY += 14f

                val dateInfo = "Generated on: $timestampFmt • Area: ${farm?.totalArea ?: 0.0} ${farm?.areaUnit ?: "Acre"} • Coordinates: ${farm?.latitude ?: 0.0}°N, ${farm?.longitude ?: 0.0}°E"
                canvas.drawText(dateInfo, MARGIN, currentY, paint)
                currentY += 12f

                // Divider Line
                paint.color = Color.LTGRAY
                paint.strokeWidth = 1f
                canvas.drawLine(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY, paint)
                currentY += 16f
            }

            // Draw Footer
            fun drawFooter(pageNum: Int) {
                paint.color = Color.GRAY
                paint.textSize = 8.5f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                val footerText = "My Farm SaaS Digital Report • Page $pageNum • Confidential Farm Record"
                canvas.drawText(footerText, MARGIN, PAGE_HEIGHT - 20f, paint)

                val rightText = "Verified Data"
                val textWidth = paint.measureText(rightText)
                canvas.drawText(rightText, PAGE_WIDTH - MARGIN - textWidth, PAGE_HEIGHT - 20f, paint)
            }

            // Check if page needs break
            fun ensureSpace(requiredHeight: Float) {
                if (currentY + requiredHeight > PAGE_HEIGHT - 45f) {
                    drawFooter(pageNumber)
                    pdfDocument.finishPage(currentPage)
                    pageNumber++
                    val newPagePair = startNewPage()
                    currentPage = newPagePair.first
                    canvas = newPagePair.second
                    drawHeader(reportType.title)
                }
            }

            // Helper to draw a section banner
            fun drawSectionTitle(text: String) {
                ensureSpace(30f)
                paint.color = Color.rgb(27, 77, 62)
                paint.textSize = 12f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText(text, MARGIN, currentY, paint)
                currentY += 6f
                paint.color = Color.rgb(46, 125, 50)
                paint.strokeWidth = 1.5f
                canvas.drawLine(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY, paint)
                currentY += 14f
            }

            // Helper to draw a row with columns
            fun drawTableRow(cols: List<Pair<String, Float>>, isHeader: Boolean = false) {
                ensureSpace(18f)
                if (isHeader) {
                    paint.color = Color.rgb(240, 245, 240)
                    canvas.drawRect(MARGIN, currentY - 11f, PAGE_WIDTH - MARGIN, currentY + 5f, paint)
                    paint.color = Color.rgb(20, 50, 35)
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    paint.textSize = 9f
                } else {
                    paint.color = Color.rgb(40, 45, 42)
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    paint.textSize = 8.5f
                }

                cols.forEach { (text, xPos) ->
                    canvas.drawText(text, xPos, currentY, paint)
                }
                currentY += 16f
            }

            // Initialize Page 1
            drawHeader(reportType.title)

            // Content Generation based on ReportType
            when (reportType) {
                ReportType.COMPLETE, ReportType.CROPS -> {
                    drawSectionTitle("1. CROPS & PLANTING LIFECYCLE (${crops.size} Recorded)")
                    if (crops.isEmpty()) {
                        ensureSpace(20f)
                        paint.color = Color.GRAY
                        canvas.drawText("No crop records registered for this farm.", MARGIN, currentY, paint)
                        currentY += 20f
                    } else {
                        drawTableRow(listOf(
                            "Crop & Variety" to MARGIN,
                            "Plot" to MARGIN + 140f,
                            "Season / Year" to MARGIN + 230f,
                            "Area" to MARGIN + 310f,
                            "Stage / Status" to MARGIN + 360f,
                            "Yield" to MARGIN + 450f
                        ), isHeader = true)

                        crops.forEach { c ->
                            drawTableRow(listOf(
                                "${c.cropName} (${c.variety})" to MARGIN,
                                c.fieldName to MARGIN + 140f,
                                "${c.season} ${c.year}" to MARGIN + 230f,
                                "${c.plantedArea} ${c.areaUnit}" to MARGIN + 310f,
                                c.currentGrowthStage to MARGIN + 360f,
                                "${c.actualYield ?: c.expectedYield} ${c.yieldUnit}" to MARGIN + 450f
                            ))
                        }
                    }
                    currentY += 10f
                }
                else -> {}
            }

            when (reportType) {
                ReportType.COMPLETE, ReportType.FINANCES -> {
                    drawSectionTitle("2. FARM FINANCIAL STATEMENT & EXPENSE BREAKDOWN")
                    val totalIncome = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
                    val totalExpenses = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
                    val netProfit = totalIncome - totalExpenses

                    ensureSpace(25f)
                    paint.color = Color.DKGRAY
                    paint.textSize = 9.5f
                    canvas.drawText("Total Revenue: Rs ${String.format("%,.0f", totalIncome)}   |   Total Costs: Rs ${String.format("%,.0f", totalExpenses)}   |   Net Return: Rs ${String.format("%,.0f", netProfit)}", MARGIN, currentY, paint)
                    currentY += 16f

                    if (transactions.isEmpty()) {
                        ensureSpace(20f)
                        paint.color = Color.GRAY
                        canvas.drawText("No financial transactions recorded for this period.", MARGIN, currentY, paint)
                        currentY += 20f
                    } else {
                        drawTableRow(listOf(
                            "Category" to MARGIN,
                            "Crop / Activity" to MARGIN + 120f,
                            "Date" to MARGIN + 230f,
                            "Party / Payment" to MARGIN + 310f,
                            "Type" to MARGIN + 400f,
                            "Amount (INR)" to MARGIN + 450f
                        ), isHeader = true)

                        transactions.take(25).forEach { tx ->
                            drawTableRow(listOf(
                                tx.category to MARGIN,
                                (tx.cropName ?: "General") to MARGIN + 120f,
                                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(tx.dateMillis)) to MARGIN + 230f,
                                tx.partyName.ifBlank { tx.paymentMode } to MARGIN + 310f,
                                tx.type to MARGIN + 400f,
                                "Rs ${String.format("%,.0f", tx.amount)}" to MARGIN + 450f
                            ))
                        }
                    }
                    currentY += 10f
                }
                else -> {}
            }

            when (reportType) {
                ReportType.COMPLETE, ReportType.ACTIVITIES -> {
                    drawSectionTitle("3. OPERATIONAL ACTIVITIES & FARM TASKS")
                    if (tasks.isEmpty()) {
                        ensureSpace(20f)
                        paint.color = Color.GRAY
                        canvas.drawText("No tasks or farm activities logged.", MARGIN, currentY, paint)
                        currentY += 20f
                    } else {
                        drawTableRow(listOf(
                            "Task Title" to MARGIN,
                            "Crop / Plot" to MARGIN + 180f,
                            "Priority" to MARGIN + 300f,
                            "Status" to MARGIN + 380f,
                            "Due Date" to MARGIN + 450f
                        ), isHeader = true)

                        tasks.forEach { t ->
                            drawTableRow(listOf(
                                t.title.take(30) to MARGIN,
                                (t.cropName ?: t.fieldName ?: "Farm Wide") to MARGIN + 180f,
                                t.priority to MARGIN + 300f,
                                (if (t.isCompleted) "Completed" else "Pending") to MARGIN + 380f,
                                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(t.dueDateMillis)) to MARGIN + 450f
                            ))
                        }
                    }
                    currentY += 10f
                }
                else -> {}
            }

            when (reportType) {
                ReportType.COMPLETE, ReportType.WEATHER -> {
                    drawSectionTitle("4. AGRICULTURAL WEATHER SNAPSHOT & SPRAYING SUITABILITY")
                    if (weather != null) {
                        ensureSpace(50f)
                        paint.color = Color.DKGRAY
                        paint.textSize = 9f
                        canvas.drawText("Current Temperature: ${weather.temperature}°C (Feels like ${weather.feelsLike}°C) • Condition: ${weather.condition}", MARGIN, currentY, paint)
                        currentY += 14f
                        canvas.drawText("Precipitation Probability: ${weather.rainProbability}% (${weather.precipitationMm} mm) • Humidity: ${weather.humidity}% • Wind: ${weather.windSpeedKmh} km/h", MARGIN, currentY, paint)
                        currentY += 14f
                        canvas.drawText("Foliar Spraying Assessment: ${weather.sprayingSuitability.statusText}", MARGIN, currentY, paint)
                        currentY += 14f
                        canvas.drawText("Reason: ${weather.sprayingSuitability.reason}", MARGIN, currentY, paint)
                        currentY += 18f
                    } else {
                        ensureSpace(20f)
                        paint.color = Color.GRAY
                        canvas.drawText("Live weather data not currently loaded.", MARGIN, currentY, paint)
                        currentY += 20f
                    }
                }
                else -> {}
            }

            when (reportType) {
                ReportType.COMPLETE, ReportType.FARM_PROFILE -> {
                    drawSectionTitle("5. LAND PLOTS & IRRIGATION INFRASTRUCTURE")
                    if (fields.isEmpty()) {
                        ensureSpace(20f)
                        paint.color = Color.GRAY
                        canvas.drawText("No individual plots registered.", MARGIN, currentY, paint)
                        currentY += 20f
                    } else {
                        drawTableRow(listOf(
                            "Plot Name" to MARGIN,
                            "Area" to MARGIN + 150f,
                            "Soil Type" to MARGIN + 230f,
                            "Irrigation System" to MARGIN + 350f
                        ), isHeader = true)

                        fields.forEach { f ->
                            drawTableRow(listOf(
                                f.name to MARGIN,
                                "${f.area} ${f.areaUnit}" to MARGIN + 150f,
                                f.soilType to MARGIN + 230f,
                                f.irrigationMethod to MARGIN + 350f
                            ))
                        }
                    }
                    currentY += 10f
                }
                else -> {}
            }

            when (reportType) {
                ReportType.COMPLETE, ReportType.DISEASE -> {
                    drawSectionTitle("6. PLANT PATHOLOGY & HEALTH SCANS (${scans.size} Logs)")
                    if (scans.isEmpty()) {
                        ensureSpace(20f)
                        paint.color = Color.GRAY
                        canvas.drawText("No plant pathology scans registered for this period.", MARGIN, currentY, paint)
                        currentY += 20f
                    } else {
                        drawTableRow(listOf(
                            "Diagnosis Issue" to MARGIN,
                            "Crop & Plot" to MARGIN + 150f,
                            "Confidence" to MARGIN + 270f,
                            "Status" to MARGIN + 350f,
                            "Follow-up Date" to MARGIN + 430f
                        ), isHeader = true)

                        scans.forEach { s ->
                            drawTableRow(listOf(
                                s.diagnosisTitle.take(25) to MARGIN,
                                "${s.cropName} (${s.fieldName})" to MARGIN + 150f,
                                s.diagnosisConfidence to MARGIN + 270f,
                                s.status to MARGIN + 350f,
                                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(s.followUpDateMillis)) to MARGIN + 430f
                            ))
                        }
                    }
                    currentY += 10f
                }
                else -> {}
            }

            // Legal & Agronomic Disclaimer at bottom
            ensureSpace(40f)
            paint.color = Color.LTGRAY
            paint.strokeWidth = 1f
            canvas.drawLine(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY, paint)
            currentY += 12f

            paint.color = Color.GRAY
            paint.textSize = 7.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            canvas.drawText("Disclaimer: This official farm report is compiled from verified user-entered farm records and Open-Meteo satellite observations.", MARGIN, currentY, paint)
            currentY += 10f
            canvas.drawText("Agricultural and pathology guidelines are preliminary advisory suggestions; consult local Krishi Vigyan Kendra (KVK) for chemical certification.", MARGIN, currentY, paint)

            // Finish Final Page
            drawFooter(pageNumber)
            pdfDocument.finishPage(currentPage)

            // Write to disk
            val fileOutputStream = FileOutputStream(outputFile)
            pdfDocument.writeTo(fileOutputStream)
            fileOutputStream.flush()
            fileOutputStream.close()
            pdfDocument.close()

            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Share or open the generated PDF file via standard Android Intent.
     */
    fun getSharePdfIntent(context: Context, file: File): Intent {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "My Farm Report: ${file.name}")
            putExtra(Intent.EXTRA_TEXT, "Here is the official farm report from My Farm — Smart Farm Manager.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
