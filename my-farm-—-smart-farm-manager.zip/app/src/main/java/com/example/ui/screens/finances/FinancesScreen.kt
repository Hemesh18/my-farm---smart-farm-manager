package com.example.ui.screens.finances

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.FarmTransaction
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.theme.HealthWarningRed
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancesScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val transactions by viewModel.allTransactions.collectAsState()
    val activeCrops by viewModel.activeCrops.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    val totalExpenses = remember(transactions) {
        transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    }
    val totalIncome = remember(transactions) {
        transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    }
    val netBalance = totalIncome - totalExpenses

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Farm Finances & P&L", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("finances_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = ForestGreenPrimary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_transaction_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Transaction")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Net Balance Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Overall Farm Net Profit / Loss", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                        Text(
                            text = "₹${String.format("%,.0f", netBalance)}",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Revenue", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", totalIncome)}", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("Total Expenses", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                                Text("₹${String.format("%,.0f", totalExpenses)}", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("Records", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                                Text("${transactions.size} Entries", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            item {
                Text("Transaction Ledger (${transactions.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }

            if (transactions.isEmpty()) {
                item {
                    Text("No transactions logged yet. Tap + to record an expense or crop sale.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(transactions) { tx ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(14.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${tx.category} • ${tx.cropName ?: "General Farm"}", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${tx.partyName.ifBlank { tx.paymentMode }} • ${tx.year} ${tx.season}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (tx.receiptNote.isNotBlank()) {
                                    Text(tx.receiptNote, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${if (tx.type == "EXPENSE") "-" else "+"}₹${String.format("%,.0f", tx.amount)}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (tx.type == "EXPENSE") HealthWarningRed else HealthGoodGreen
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(onClick = { viewModel.deleteTransaction(tx) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }

    // Add Transaction Dialog
    if (showAddDialog) {
        var isExpense by remember { mutableStateOf(true) }
        var category by remember { mutableStateOf("Fertilizers") }
        var amount by remember { mutableStateOf("") }
        var partyName by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var cropName by remember { mutableStateOf(activeCrops.firstOrNull()?.cropName ?: "Cotton (Kapas)") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(if (isExpense) "Log Farm Expense" else "Log Crop Sale Income", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row {
                        FilterChip(selected = isExpense, onClick = { isExpense = true }, label = { Text("Expense") })
                        Spacer(modifier = Modifier.width(8.dp))
                        FilterChip(selected = !isExpense, onClick = { isExpense = false }, label = { Text("Income") })
                    }

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category (Seeds, Labor, Fuel, Sales)") },
                        modifier = Modifier.fillMaxWidth().testTag("transaction_category_input")
                    )

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("Amount in INR (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("transaction_amount_input")
                    )

                    OutlinedTextField(
                        value = partyName,
                        onValueChange = { partyName = it },
                        label = { Text("Vendor / Buyer / Labor Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Receipt Note / Quantity") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedAmount = amount.toDoubleOrNull() ?: 0.0
                        if (parsedAmount > 0) {
                            viewModel.addTransaction(
                                FarmTransaction(
                                    type = if (isExpense) "EXPENSE" else "INCOME",
                                    category = category,
                                    amount = parsedAmount,
                                    partyName = partyName,
                                    receiptNote = note,
                                    cropName = cropName,
                                    year = 2026,
                                    season = "Kharif"
                                )
                            )
                            showAddDialog = false
                        }
                    },
                    modifier = Modifier.testTag("confirm_save_transaction")
                ) {
                    Text("Save Record")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
