package com.example.ui.screens.analytics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.theme.LeafGreenSecondary
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsReportsScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val allCrops by viewModel.allCrops.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    var exportFeedback by remember { mutableStateOf<String?>(null) }
    var showPdfDialog by remember { mutableStateOf(false) }

    val completedTasks = allTasks.filter { it.isCompleted }.size
    val taskCompletionPct = if (allTasks.isNotEmpty()) (completedTasks * 100) / allTasks.size else 0

    if (showPdfDialog) {
        com.example.ui.screens.reports.ExportPdfDialog(
            viewModel = viewModel,
            onDismiss = { showPdfDialog = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Farm Reports & Analytics", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("analytics_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { showPdfDialog = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("open_pdf_dialog_button")
                    ) {
                        Text("PDF Report")
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            exportFeedback = "Farm records exported to /Download/MyFarm_Archive_2026.csv successfully."
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("export_csv_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("CSV")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            exportFeedback?.let { msg ->
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = HealthGoodGreen.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = msg,
                            color = HealthGoodGreen,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Task Efficiency Card
            item {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Operational Task Completion", fontWeight = FontWeight.Bold)
                            Text("$taskCompletionPct%", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { taskCompletionPct / 100f },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                            color = ForestGreenPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("$completedTasks of ${allTasks.size} scheduled operations finished on time.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Crop Acreage Distribution
            item {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Crop Acreage Allocation (Current Season)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(10.dp))
                        allCrops.filter { !it.isArchived }.forEach { crop ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${crop.cropName} (${crop.fieldName})", style = MaterialTheme.typography.bodyMedium)
                                Text("${crop.plantedArea} Acres", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Crop-wise Profit Breakdown
            item {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Multi-Year Crop Profitability", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(10.dp))

                        AnalyticsCropProfitRow("2024 Cotton (Plot A)", "₹1,06,400", "₹22,100", "+₹84,300")
                        AnalyticsCropProfitRow("2025 Soybean (Plot B)", "₹1,75,200", "₹16,600", "+₹1,58,600")
                        AnalyticsCropProfitRow("2026 Cotton (Plot A)", "Harvest Pending", "₹12,450", "In Growth")
                        AnalyticsCropProfitRow("2026 Chilli (Plot C)", "Harvest Pending", "₹6,500", "In Growth")
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun AnalyticsCropProfitRow(crop: String, revenue: String, expenses: String, profit: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(crop, fontWeight = FontWeight.SemiBold)
                Text("Rev: $revenue | Exp: $expenses", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(profit, fontWeight = FontWeight.Bold, color = if (profit.startsWith("+")) HealthGoodGreen else MaterialTheme.colorScheme.onSurface)
        }
    }
}
