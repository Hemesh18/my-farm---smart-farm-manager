package com.example.ui.screens.crops

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.CropHealthChip
import com.example.ui.components.PriorityBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.FarmViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CropDetailScreen(
    cropId: String,
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val allCrops by viewModel.allCrops.collectAsState()
    val crop = allCrops.find { it.id == cropId } ?: allCrops.firstOrNull()

    val tasks by viewModel.allTasks.collectAsState()
    val cropTasks = remember(tasks, cropId) { tasks.filter { it.cropId == cropId || it.cropName == crop?.cropName } }

    val irrigations by viewModel.irrigationLogs.collectAsState()
    val cropIrrigations = remember(irrigations, cropId) { irrigations.filter { it.cropId == cropId || it.cropName == crop?.cropName } }

    val fertilizers by viewModel.fertilizerLogs.collectAsState()
    val cropFertilizers = remember(fertilizers, cropId) { fertilizers.filter { it.cropId == cropId || it.cropName == crop?.cropName } }

    val transactions by viewModel.allTransactions.collectAsState()
    val cropTransactions = remember(transactions, cropId) { transactions.filter { it.cropId == cropId || it.cropName == crop?.cropName } }

    val weatherInfo by viewModel.weatherInfo.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf(
        "Overview",
        "Growth Timeline",
        "Weather",
        "Irrigation",
        "Fertilizers",
        "Pest & Disease",
        "Tasks",
        "Expenses",
        "Photos & Notes",
        "Harvest & Yield"
    )

    if (crop == null) {
        Scaffold { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Crop record not found.")
            }
        }
        return
    }

    val ageDays = remember(crop.sowingDateMillis) {
        ((System.currentTimeMillis() - crop.sowingDateMillis) / (24L * 60 * 60 * 1000)).coerceAtLeast(0)
    }
    val daysRemaining = (crop.expectedDurationDays - ageDays).coerceAtLeast(0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(crop.cropName, fontWeight = FontWeight.Bold)
                        Text(
                            "${crop.variety} • ${crop.fieldName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("crop_detail_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    CropHealthChip(status = crop.healthCondition)
                    Spacer(modifier = Modifier.width(8.dp))
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 10 Tabs Scrollable Bar
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                edgePadding = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title, fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("crop_tab_$index")
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTabIndex) {
                    0 -> { // Overview Tab
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("General Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    DetailRow("Planted Area", "${crop.plantedArea} ${crop.areaUnit}")
                                    DetailRow("Field", crop.fieldName)
                                    DetailRow("Crop Age", "$ageDays Days since sowing")
                                    DetailRow("Current Stage", crop.currentGrowthStage)
                                    DetailRow("Season & Year", "${crop.season} ${crop.year}")
                                    DetailRow("Status", crop.status)
                                    DetailRow("Seed Supplier", crop.seedSupplier)
                                    DetailRow("Seed Investment", "₹${String.format("%,.0f", crop.seedCost)}")
                                }
                            }
                        }
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Agronomic Notes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = crop.notes.ifBlank { "No special notes recorded." },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    1 -> { // Growth Timeline Tab
                        item {
                            Text("Visual Growth Timeline", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Stage-wise reference duration for ${crop.cropName} ($ageDays of ${crop.expectedDurationDays} days passed).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        val stages = listOf(
                            Triple("Land Preparation & Sowing", "Day 0 - 10", true),
                            Triple("Germination & Seedling Stand", "Day 10 - 25", true),
                            Triple("Vegetative Canopy Expansion", "Day 25 - 45", true),
                            Triple("Squaring & Early Flowering", "Day 45 - 75", ageDays >= 45),
                            Triple("Peak Flowering & Boll/Pod Setting", "Day 75 - 110", ageDays >= 75),
                            Triple("Maturity & Boll Bursting", "Day 110 - 140", ageDays >= 110),
                            Triple("Harvest Window", "Day 140 - ${crop.expectedDurationDays}", ageDays >= 140)
                        )

                        items(stages) { (stageName, duration, isReached) ->
                            TimelineItem(
                                title = stageName,
                                subtitle = duration,
                                isCompleted = isReached,
                                isCurrent = stageName == crop.currentGrowthStage
                            )
                        }
                    }

                    2 -> { // Weather Tab
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Microclimate at ${crop.fieldName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    weatherInfo?.let { w ->
                                        DetailRow("Current Temp", "${w.temperature}°C (Feels like ${w.feelsLike}°C)")
                                        DetailRow("Humidity", "${w.humidity}%")
                                        DetailRow("Precipitation Risk", "${w.rainProbability}% probability")
                                        DetailRow("Wind Velocity", "${w.windSpeedKmh} km/h")
                                        DetailRow("Spraying Status", w.sprayingSuitability.statusText)
                                    } ?: Text("Weather updating...")
                                }
                            }
                        }
                    }

                    3 -> { // Irrigation Tab
                        item {
                            Text("Irrigation History (${cropIrrigations.size} logs)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        if (cropIrrigations.isEmpty()) {
                            item { Text("No irrigation logged for this crop yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(cropIrrigations) { log ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("${log.method} • ${log.durationHours} hrs (${log.waterQuantityLiters} L)", fontWeight = FontWeight.Bold)
                                        Text("Pump operating cost: ₹${log.electricityFuelCost} | Soil moisture: ${log.soilMoistureBeforePct}% → ${log.soilMoistureAfterPct}%", style = MaterialTheme.typography.bodySmall)
                                        if (log.notes.isNotBlank()) Text(log.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }

                    4 -> { // Fertilizer Tab
                        item {
                            Text("Nutrient & Fertilizer Applications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        if (cropFertilizers.isEmpty()) {
                            item { Text("No fertilizer logged for this crop yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(cropFertilizers) { fert ->
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("${fert.fertilizerName} (${fert.quantity} ${fert.unit})", fontWeight = FontWeight.Bold)
                                        Text("Method: ${fert.applicationMethod} | Cost: ₹${fert.cost}", style = MaterialTheme.typography.bodySmall)
                                        if (fert.notes.isNotBlank()) Text(fert.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }

                    5 -> { // Pest & Disease Tab
                        item {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Integrated Pest Management (IPM)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("• Current Health: ${crop.healthCondition}")
                                    Text("• Target Pests: Whitefly, Aphids, Pink Bollworm (traps placed)")
                                    Text("• Safe cultural steps: Regular scouting, neem oil spray (5ml/L) as first defense.")
                                }
                            }
                        }
                    }

                    6 -> { // Tasks Tab
                        item {
                            Text("Associated Crop Tasks (${cropTasks.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        if (cropTasks.isEmpty()) {
                            item { Text("No tasks specifically linked to this crop.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(cropTasks) { task ->
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = task.isCompleted, onCheckedChange = { viewModel.toggleTaskCompleted(task) })
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(task.title, fontWeight = FontWeight.SemiBold)
                                            Text(task.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        PriorityBadge(priority = task.priority)
                                    }
                                }
                            }
                        }
                    }

                    7 -> { // Expenses Tab
                        item {
                            val totalExp = cropTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary.copy(alpha = 0.1f))) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Total Crop Investment", style = MaterialTheme.typography.bodySmall)
                                    Text("₹${String.format("%,.0f", totalExp)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                    Text("Cost per Acre: ₹${String.format("%,.0f", totalExp / crop.plantedArea.coerceAtLeast(1.0))}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        items(cropTransactions) { tx ->
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("${tx.category} • ${tx.partyName.ifBlank { "Expenditure" }}", fontWeight = FontWeight.SemiBold)
                                        Text(tx.receiptNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text("₹${String.format("%,.0f", tx.amount)}", fontWeight = FontWeight.Bold, color = if (tx.type == "EXPENSE") HealthWarningRed else HealthGoodGreen)
                                }
                            }
                        }
                    }

                    8 -> { // Photos & Notes Tab
                        item {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Crop Visual Diary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Field observations captured during weekly inspections.")
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().height(140.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text("Observation: Square formation healthy on Plot A", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    9 -> { // Harvest & Yield Tab
                        item {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Harvest Outlook", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    DetailRow("Target Harvest Window", "In ~${daysRemaining} Days")
                                    DetailRow("Target Yield", "${crop.expectedYield} ${crop.yieldUnit}")
                                    DetailRow("Actual Yield Recorded", if (crop.actualYield != null) "${crop.actualYield} ${crop.yieldUnit}" else "Pending Harvest")
                                    DetailRow("Est. Yield / Acre", "${crop.expectedYield / crop.plantedArea.coerceAtLeast(1.0)} ${crop.yieldUnit}/Acre")
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
    }
}

@Composable
private fun TimelineItem(
    title: String,
    subtitle: String,
    isCompleted: Boolean,
    isCurrent: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    if (isCurrent) LeafGreenSecondary
                    else if (isCompleted) HealthGoodGreen.copy(alpha = 0.2f)
                    else MaterialTheme.colorScheme.surfaceVariant
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isCompleted || isCurrent) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = if (isCurrent) Color.White else HealthGoodGreen,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
