package com.example.ui.screens.soil

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.FertilizerLog
import com.example.data.model.SoilTestRecord
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.SoilBrown
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoilFertilizerScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val soilTests by viewModel.soilTests.collectAsState()
    val fertilizers by viewModel.fertilizerLogs.collectAsState()
    val fields by viewModel.allFields.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Soil Health, 1: Fertilizer Applications
    var showAddFertilizerDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Soil Health & Fertilizers", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("soil_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            if (selectedTab == 1) {
                FloatingActionButton(
                    onClick = { showAddFertilizerDialog = true },
                    containerColor = SoilBrown,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Record Application")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Soil Test Reports") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Fertilizer Logs") })
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (selectedTab == 0) {
                    if (soilTests.isEmpty()) {
                        item { Text("No soil test reports recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    } else {
                        items(soilTests) { test ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(test.fieldName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("pH: ${test.ph}", fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                    }
                                    Text("Tested by: ${test.laboratoryName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                                    Spacer(modifier = Modifier.height(10.dp))
                                    HorizontalDivider()
                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Organic Carbon: ${test.organicCarbonPct}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                        Text("Nitrogen: ${test.nitrogenKgHa} kg/ha", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Phosphorus: ${test.phosphorusKgHa} kg/ha", style = MaterialTheme.typography.bodySmall)
                                        Text("Potassium: ${test.potassiumKgHa} kg/ha", style = MaterialTheme.typography.bodySmall)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Text(
                                            text = "Laboratory Guidance: ${test.recommendations}",
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (fertilizers.isEmpty()) {
                        item { Text("No fertilizer applications logged.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    } else {
                        items(fertilizers) { fert ->
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("${fert.fertilizerName} • ${fert.quantity} ${fert.unit}", fontWeight = FontWeight.Bold)
                                        Text("₹${String.format("%,.0f", fert.cost)}", fontWeight = FontWeight.Bold, color = SoilBrown)
                                    }
                                    Text("${fert.fieldName} • Method: ${fert.applicationMethod}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    if (fert.notes.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(fert.notes, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(70.dp))
                }
            }
        }
    }

    if (showAddFertilizerDialog) {
        var fertilizerName by remember { mutableStateOf("19:19:19 Water Soluble NPK") }
        var quantity by remember { mutableStateOf("10.0") }
        var unit by remember { mutableStateOf("Kg") }
        var method by remember { mutableStateOf("Drip Fertigation") }
        var cost by remember { mutableStateOf("1200") }
        var fieldName by remember { mutableStateOf(fields.firstOrNull()?.name ?: "Plot A (North Valley)") }
        var fieldId by remember { mutableStateOf(fields.firstOrNull()?.id ?: "field_1") }
        var notes by remember { mutableStateOf("Injected via venturi to nourish flower setting.") }

        AlertDialog(
            onDismissRequest = { showAddFertilizerDialog = false },
            title = { Text("Log Fertilizer Application", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = fertilizerName, onValueChange = { fertilizerName = it }, label = { Text("Fertilizer Name") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = quantity, onValueChange = { quantity = it }, label = { Text("Quantity") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit (Kg/L)") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = method, onValueChange = { method = it }, label = { Text("Method (Soil, Drip, Foliar)") })
                    OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Cost (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Agronomic Notes") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addFertilizerLog(
                            FertilizerLog(
                                fieldId = fieldId,
                                fieldName = fieldName,
                                fertilizerName = fertilizerName,
                                quantity = quantity.toDoubleOrNull() ?: 10.0,
                                unit = unit,
                                applicationMethod = method,
                                cost = cost.toDoubleOrNull() ?: 1000.0,
                                notes = notes
                            )
                        )
                        showAddFertilizerDialog = false
                    }
                ) {
                    Text("Save Record")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddFertilizerDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
