package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ForestGreenDarkPrimary,
    onPrimary = ForestGreenDarkOnPrimary,
    primaryContainer = ForestGreenDarkPrimaryContainer,
    onPrimaryContainer = ForestGreenDarkOnPrimaryContainer,
    secondary = LeafGreenDarkSecondary,
    onSecondary = LeafGreenDarkOnSecondary,
    secondaryContainer = LeafGreenDarkSecondaryContainer,
    onSecondaryContainer = LeafGreenDarkOnSecondaryContainer,
    tertiary = HarvestAmberDarkTertiary,
    onTertiary = HarvestAmberDarkOnTertiary,
    tertiaryContainer = HarvestAmberDarkTertiaryContainer,
    onTertiaryContainer = HarvestAmberDarkOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline
)

private val LightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,
    onPrimary = ForestGreenOnPrimary,
    primaryContainer = ForestGreenPrimaryContainer,
    onPrimaryContainer = ForestGreenOnPrimaryContainer,
    secondary = LeafGreenSecondary,
    onSecondary = LeafGreenOnSecondary,
    secondaryContainer = LeafGreenSecondaryContainer,
    onSecondaryContainer = LeafGreenOnSecondaryContainer,
    tertiary = HarvestAmberTertiary,
    onTertiary = HarvestAmberOnTertiary,
    tertiaryContainer = HarvestAmberTertiaryContainer,
    onTertiaryContainer = HarvestAmberOnTertiaryContainer,
    background = NeutralBackgroundLight,
    onBackground = NeutralOnBackgroundLight,
    surface = SurfaceLight,
    onSurface = OnSurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    outline = OutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep agricultural nature brand palette consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
