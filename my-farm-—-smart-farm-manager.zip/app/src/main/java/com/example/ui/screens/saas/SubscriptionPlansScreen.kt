package com.example.ui.screens.saas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HarvestAmberTertiary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionPlansScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    var successNotice by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SaaS Subscription Plans", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("subscription_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = ForestGreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Current Subscription Status", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Active Plan: ${currentUser?.subscriptionPlan ?: "PRO_MONTHLY"} (${currentUser?.subscriptionStatus ?: "ACTIVE"})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreenPrimary
                        )
                        Text(
                            text = "Tenant Account: ${currentUser?.email ?: "Registered Farmer"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            successNotice?.let { msg ->
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = HealthGoodGreen.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = msg,
                            color = HealthGoodGreen,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Plan 1: Free Kisan Plan
            item {
                PlanTierCard(
                    planName = "Kisan Starter",
                    price = "₹0 / Free Forever",
                    features = listOf(
                        "1 Farm & up to 3 Field Plots",
                        "Live Weather & Rainfall forecasts",
                        "Manual Task & Activity logging",
                        "Standard Offline Mode"
                    ),
                    isCurrent = currentUser?.subscriptionPlan == "FREE",
                    buttonLabel = if (currentUser?.subscriptionPlan == "FREE") "Active Plan" else "Downgrade to Starter",
                    onSelect = {
                        viewModel.updateSubscription("FREE")
                        successNotice = "Plan updated to Kisan Starter (Free)."
                    }
                )
            }

            // Plan 2: Pro Farm Manager
            item {
                PlanTierCard(
                    planName = "Pro Farm Manager",
                    price = "₹499 / Month (or ₹4,999/yr)",
                    badge = "MOST POPULAR",
                    features = listOf(
                        "Unlimited Farms & Plots",
                        "Gemini 3.5 AI Farm Advisor with Citations",
                        "Crop Disease & Pest Health Scanner",
                        "Sentinel-2 Satellite & NDVI Biomass Layer",
                        "Permanent Multi-Year History (2024–2026)",
                        "Professional PDF Reports Export & Download",
                        "Priority SMS & Push Weather Reminders"
                    ),
                    isCurrent = currentUser?.subscriptionPlan == "PRO_MONTHLY",
                    isFeatured = true,
                    buttonLabel = if (currentUser?.subscriptionPlan == "PRO_MONTHLY") "Active Plan" else "Upgrade to Pro Manager (₹499)",
                    onSelect = {
                        viewModel.updateSubscription("PRO_MONTHLY")
                        successNotice = "Upgraded to Pro Farm Manager. All premium features unlocked!"
                    }
                )
            }

            // Plan 3: Agri Enterprise
            item {
                PlanTierCard(
                    planName = "Agri Enterprise SaaS",
                    price = "₹1,499 / Month",
                    features = listOf(
                        "Everything in Pro Farm Manager",
                        "Multi-tenant cooperative farm management",
                        "IoT Soil Moisture & Sensor integration",
                        "Bulk CSV & Custom PDF Export for Bank Loans",
                        "Dedicated Agricultural Scientist Consultation"
                    ),
                    isCurrent = currentUser?.subscriptionPlan == "ENTERPRISE",
                    buttonLabel = if (currentUser?.subscriptionPlan == "ENTERPRISE") "Active Plan" else "Upgrade to Enterprise (₹1,499)",
                    onSelect = {
                        viewModel.updateSubscription("ENTERPRISE")
                        successNotice = "Upgraded to Agri Enterprise SaaS."
                    }
                )
            }

            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Billing Transparency: My Farm SaaS operates in secure simulated billing test-mode. Upgrading instantly provisions entitlements in your local account without charging credit cards.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun PlanTierCard(
    planName: String,
    price: String,
    badge: String? = null,
    features: List<String>,
    isCurrent: Boolean,
    isFeatured: Boolean = false,
    buttonLabel: String,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("plan_card_${planName.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isFeatured) ForestGreenPrimary.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isFeatured) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(planName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                if (badge != null) {
                    Surface(shape = RoundedCornerShape(8.dp), color = HarvestAmberTertiary) {
                        Text(
                            text = badge,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Text(price, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold), color = ForestGreenPrimary)

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))

            features.forEach { feat ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = HealthGoodGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(feat, style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onSelect,
                enabled = !isCurrent,
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("select_plan_${planName.take(5).lowercase()}"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isFeatured) ForestGreenPrimary else MaterialTheme.colorScheme.secondary
                )
            ) {
                Text(buttonLabel, fontWeight = FontWeight.Bold)
            }
        }
    }
}
