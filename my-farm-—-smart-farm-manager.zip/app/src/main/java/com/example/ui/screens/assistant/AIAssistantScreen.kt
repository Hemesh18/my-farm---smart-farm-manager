package com.example.ui.screens.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AiChatMessage
import com.example.data.model.FarmTask
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.LeafGreenSecondary
import com.example.ui.viewmodel.FarmViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIAssistantScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isThinking by viewModel.isAiThinking.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    var selectedLanguage by remember(currentLang) { mutableStateOf(currentLang) }
    var showVoiceModal by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }

    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val suggestedPrompts = remember(selectedLanguage) {
        when (selectedLanguage) {
            "Marathi" -> listOf(
                "माझ्या शेतावर आज काय करावे?",
                "२०२४ मधील कापसाचे उत्पादन किती होते?",
                "या आठवड्यात पाऊस पडणार आहे का?",
                "ठिबक सिंचन कधी चालू करावे?"
            )
            "Hindi" -> listOf(
                "आज मेरे खेत पर क्या प्राथमिकता है?",
                "२०२४ में कपास की पैदावार कितनी थी?",
                "क्या इस हफ्ते बारिश की संभावना है?",
                "कपास में सफेद मक्खी से बचाव कैसे करें?"
            )
            else -> listOf(
                "What should I do on my farm today?",
                "What was my cotton harvest in 2024?",
                "Compare 2024 vs 2025 farm profit",
                "Is rain forecast this week?",
                "Recommend fertilizer for flowering stage"
            )
        }
    }

    LaunchedEffect(aiMessages.size) {
        if (aiMessages.isNotEmpty()) {
            listState.animateScrollToItem(aiMessages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(ForestGreenPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("My Farm AI Advisor", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Grounded in your real multi-year farm records", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("ai_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.clearAiChat() }, modifier = Modifier.testTag("clear_chat_button")) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Chat")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Language selector chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Language:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                listOf("English", "Marathi", "Hindi").forEach { lang ->
                    FilterChip(
                        selected = selectedLanguage.equals(lang, ignoreCase = true),
                        onClick = {
                            selectedLanguage = lang
                            viewModel.setLanguage(lang)
                        },
                        label = {
                            Text(
                                when (lang) {
                                    "Marathi" -> "मराठी"
                                    "Hindi" -> "हिंदी"
                                    else -> "English"
                                }
                            )
                        },
                        modifier = Modifier.testTag("lang_chip_$lang")
                    )
                }
            }

            // Chat Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (aiMessages.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Psychology, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Ask anything about your farm",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "I query your saved farm profile, 2024-2026 crops, soil tests, irrigation logs, and live weather to provide precise agronomic guidance.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }

                items(aiMessages) { msg ->
                    ChatBubble(
                        message = msg,
                        onAddAsTask = { text ->
                            viewModel.addTask(
                                FarmTask(
                                    title = "AI Action: ${text.take(35)}...",
                                    description = text,
                                    priority = "Medium",
                                    isAiSuggested = true,
                                    aiReason = "Derived from My Farm AI advisory recommendation."
                                )
                            )
                        }
                    )
                }

                if (isThinking) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Querying farm database & synthesizing advice...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Suggested prompt chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(suggestedPrompts) { prompt ->
                    SuggestionChip(
                        onClick = {
                            viewModel.sendAiPrompt(prompt, selectedLanguage)
                        },
                        label = { Text(prompt, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("prompt_chip_${prompt.hashCode()}")
                    )
                }
            }

            // Input Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            val voiceSample = when (selectedLanguage) {
                                "Marathi" -> "माझ्या शेतावरील कापूस पिकावर बोंडअळीचा प्रादुर्भाव कसा रोखावा?"
                                "Hindi" -> "गेहूं में पहली सिंचाई और उर्वरक प्रबंधन कैसे करें?"
                                else -> "What is the recommended fertilizer schedule for my crops?"
                            }
                            inputText = voiceSample
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("ai_mic_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input / आवाज",
                            tint = ForestGreenPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                when (selectedLanguage) {
                                    "Marathi" -> "मराठीत बोला किंवा प्रश्न लिहा..."
                                    "Hindi" -> "हिंदी में बोलें या प्रश्न पूछें..."
                                    else -> "Ask in English, मराठी, or हिंदी..."
                                }
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_input_text"),
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 3
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                val text = inputText
                                inputText = ""
                                viewModel.sendAiPrompt(text, selectedLanguage)
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(ForestGreenPrimary)
                            .testTag("ai_send_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: AiChatMessage,
    onAddAsTask: (String) -> Unit
) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ForestGreenPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Card(
            modifier = Modifier.widthIn(max = 300.dp),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) ForestGreenPrimary else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (!isUser) {
                    if (!message.citedRecords.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "Cited In-App Records: ${message.citedRecords}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = { onAddAsTask(message.content) },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.AddAlarm, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add to Farm Tasks", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
