package com.example.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.FarmProfile
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val currentProfile by viewModel.farmProfile.collectAsState()

    var farmName by remember { mutableStateOf(currentProfile?.farmName ?: "My Farm") }
    var farmerName by remember { mutableStateOf(currentProfile?.farmerName ?: viewModel.currentUser.value?.fullName ?: "") }
    var village by remember { mutableStateOf(currentProfile?.village ?: "") }
    var district by remember { mutableStateOf(currentProfile?.district ?: "") }
    var state by remember { mutableStateOf(currentProfile?.state ?: "") }
    var pinCode by remember { mutableStateOf(currentProfile?.pinCode ?: "") }
    var latitude by remember { mutableStateOf(currentProfile?.latitude?.takeIf { it != 0.0 }?.toString() ?: "") }
    var longitude by remember { mutableStateOf(currentProfile?.longitude?.takeIf { it != 0.0 }?.toString() ?: "") }
    var totalArea by remember { mutableStateOf(currentProfile?.totalArea?.takeIf { it != 0.0 }?.toString() ?: "") }
    var areaUnit by remember { mutableStateOf(currentProfile?.areaUnit ?: "Acre") }
    var soilType by remember { mutableStateOf(currentProfile?.primarySoilType ?: "Black Cotton Soil") }
    var irrigationSource by remember { mutableStateOf(currentProfile?.irrigationSource ?: "Borewell & Solar Drip") }
    var language by remember { mutableStateOf(currentProfile?.preferredLanguage ?: "English") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Farm Profile & Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            val updated = (currentProfile ?: FarmProfile()).copy(
                                farmName = farmName,
                                farmerName = farmerName,
                                village = village,
                                district = district,
                                state = state,
                                pinCode = pinCode,
                                latitude = latitude.toDoubleOrNull() ?: 0.0,
                                longitude = longitude.toDoubleOrNull() ?: 0.0,
                                totalArea = totalArea.toDoubleOrNull() ?: 1.0,
                                areaUnit = areaUnit,
                                primarySoilType = soilType,
                                irrigationSource = irrigationSource,
                                preferredLanguage = language
                            )
                            viewModel.saveFarmProfile(updated)
                            onNavigateBack()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        modifier = Modifier.testTag("save_profile_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "भाषा निवडा / Preferred Language",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Change app language instantly to English, मराठी, or हिंदी.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("English" to "English", "मराठी" to "Marathi", "हिंदी" to "Hindi").forEach { (display, code) ->
                            val selected = language.equals(code, ignoreCase = true)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    language = code
                                    viewModel.setLanguage(code)
                                },
                                label = { Text(display, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                                modifier = Modifier.testTag("settings_lang_$code")
                            )
                        }
                    }
                }
            }

            Text("Farm Identity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = farmName,
                onValueChange = { farmName = it },
                label = { Text("Farm Name") },
                modifier = Modifier.fillMaxWidth().testTag("settings_farm_name_input"),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = farmerName,
                onValueChange = { farmerName = it },
                label = { Text("Farmer Display Name") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            HorizontalDivider()
            Text("Geographic Location & GPS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = village, onValueChange = { village = it }, label = { Text("Village / Town") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = district, onValueChange = { district = it }, label = { Text("District") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = state, onValueChange = { state = it }, label = { Text("State") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = pinCode, onValueChange = { pinCode = it }, label = { Text("PIN Code") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), shape = RoundedCornerShape(12.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = latitude, onValueChange = { latitude = it }, label = { Text("Latitude") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = longitude, onValueChange = { longitude = it }, label = { Text("Longitude") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), shape = RoundedCornerShape(12.dp))
            }

            HorizontalDivider()
            Text("Farm Attributes & Soils", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = totalArea, onValueChange = { totalArea = it }, label = { Text("Total Area") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = areaUnit, onValueChange = { areaUnit = it }, label = { Text("Unit (Acre/Ha)") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
            }

            OutlinedTextField(
                value = soilType,
                onValueChange = { soilType = it },
                label = { Text("Primary Soil Type") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = irrigationSource,
                onValueChange = { irrigationSource = it },
                label = { Text("Irrigation Water Source") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
