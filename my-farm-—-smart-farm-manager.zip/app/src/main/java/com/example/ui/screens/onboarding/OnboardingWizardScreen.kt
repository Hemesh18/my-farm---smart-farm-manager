package com.example.ui.screens.onboarding

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CropRecord
import com.example.data.model.FarmProfile
import com.example.data.model.FieldPlot
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.LeafGreenSecondary
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingWizardScreen(
    viewModel: FarmViewModel,
    onOnboardingFinished: () -> Unit
) {
    val context = LocalContext.current
    var currentStep by remember { mutableIntStateOf(1) } // 1: Farmer, 2: Location, 3: Soil/Water, 4: Crops

    // Step 1: Farmer Profile
    var fullName by remember { mutableStateOf(viewModel.currentUser.value?.fullName ?: "") }
    var phone by remember { mutableStateOf(viewModel.currentUser.value?.phone ?: "") }
    var preferredLanguage by remember { mutableStateOf("English") }
    var state by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var taluka by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var pinCode by remember { mutableStateOf("") }
    var measurementUnit by remember { mutableStateOf("Acre") }

    // Step 2: Farm Location
    var farmName by remember { mutableStateOf("") }
    var latitude by remember { mutableStateOf<Double?>(null) }
    var longitude by remember { mutableStateOf<Double?>(null) }
    var locationSource by remember { mutableStateOf("MANUAL") }
    var locationAccuracy by remember { mutableStateOf<Float?>(null) }
    var locationStatusMessage by remember { mutableStateOf("Tap 'Detect Location via GPS' or enter coordinates manually below.") }
    var manualLatInput by remember { mutableStateOf("") }
    var manualLonInput by remember { mutableStateOf("") }

    // Step 3: Farm Details
    var totalArea by remember { mutableStateOf("") }
    var primarySoilType by remember { mutableStateOf("Black Cotton Soil") }
    var soilPh by remember { mutableStateOf("7.4") }
    var irrigationMethod by remember { mutableStateOf("Drip Irrigation") }
    var waterSource by remember { mutableStateOf("Borewell & Well") }

    // Step 4: Crop Setup (Optional)
    var cropName by remember { mutableStateOf("") }
    var cropVariety by remember { mutableStateOf("") }
    var cropArea by remember { mutableStateOf("") }

    // GPS Permission Launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                @SuppressLint("MissingPermission")
                val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

                if (loc != null) {
                    latitude = loc.latitude
                    longitude = loc.longitude
                    locationAccuracy = loc.accuracy
                    locationSource = "GPS"
                    manualLatInput = String.format("%.4f", loc.latitude)
                    manualLonInput = String.format("%.4f", loc.longitude)
                    locationStatusMessage = "Location detected: ${String.format("%.4f", loc.latitude)}°N, ${String.format("%.4f", loc.longitude)}°E (Accuracy: ${loc.accuracy}m)"
                } else {
                    locationStatusMessage = "GPS active, but waiting for satellite lock. You can enter coordinates or confirm village."
                }
            } catch (e: Exception) {
                locationStatusMessage = "Could not fetch GPS: ${e.message}. Manual entry available below."
            }
        } else {
            locationStatusMessage = "Permission denied. You can enter village and coordinates manually below."
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Farmer Onboarding Wizard", fontWeight = FontWeight.Bold)
                        Text(
                            "Step $currentStep of 4: " + when (currentStep) {
                                1 -> "Farmer Profile"
                                2 -> "Farm Location"
                                3 -> "Soil & Water Details"
                                else -> "First Crop Setup"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Step Progress Indicator
            LinearProgressIndicator(
                progress = { currentStep / 4f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = ForestGreenPrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            when (currentStep) {
                1 -> {
                    // STEP 1: Farmer Profile
                    Text("Farmer Personal & Regional Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("This information customizes local agronomic advisories and language.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name *") },
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_name"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Mobile Phone Number *") },
                        placeholder = { Text("+91 98765 43210") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_phone"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Text("Preferred Language", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("English", "Marathi", "Hindi").forEach { lang ->
                            FilterChip(
                                selected = preferredLanguage == lang,
                                onClick = { preferredLanguage = lang },
                                label = {
                                    Text(
                                        when (lang) {
                                            "Marathi" -> "मराठी (Marathi)"
                                            "Hindi" -> "हिंदी (Hindi)"
                                            else -> "English"
                                        }
                                    )
                                }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = state, onValueChange = { state = it }, label = { Text("State") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                        OutlinedTextField(value = district, onValueChange = { district = it }, label = { Text("District") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = taluka, onValueChange = { taluka = it }, label = { Text("Taluka / Tehsil") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                        OutlinedTextField(value = village, onValueChange = { village = it }, label = { Text("Village *") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = pinCode, onValueChange = { pinCode = it }, label = { Text("PIN Code") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                        OutlinedTextField(value = measurementUnit, onValueChange = { measurementUnit = it }, label = { Text("Unit (Acre/Ha)") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                    }

                    Button(
                        onClick = {
                            if (fullName.isNotBlank()) currentStep = 2
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("onboarding_step1_next"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                    ) {
                        Text("Next: Farm Location →", fontWeight = FontWeight.Bold)
                    }
                }

                2 -> {
                    // STEP 2: Farm Location
                    Text("Farm Identity & Geo-Coordinates", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Weather intelligence and satellite imagery require verified farm coordinates.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = farmName,
                        onValueChange = { farmName = it },
                        label = { Text("Farm Name *") },
                        placeholder = { Text("e.g. Kisan Samruddhi Farm") },
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_farm_name"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // GPS Button Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, tint = ForestGreenPrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Device Geolocation (GPS)", fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(locationStatusMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                modifier = Modifier.fillMaxWidth().testTag("onboarding_gps_btn")
                            ) {
                                Text("Detect Location via GPS")
                            }
                        }
                    }

                    Text("Or Enter Coordinates Manually:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = manualLatInput,
                            onValueChange = {
                                manualLatInput = it
                                latitude = it.toDoubleOrNull()
                            },
                            label = { Text("Latitude (°N)") },
                            placeholder = { Text("20.5841") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = manualLonInput,
                            onValueChange = {
                                manualLonInput = it
                                longitude = it.toDoubleOrNull()
                            },
                            label = { Text("Longitude (°E)") },
                            placeholder = { Text("77.0620") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { currentStep = 1 }, modifier = Modifier.weight(1f).height(50.dp)) {
                            Text("← Back")
                        }
                        Button(
                            onClick = {
                                if (farmName.isBlank()) farmName = if (fullName.isNotBlank()) "${fullName.take(15)} Farm" else "My Farm"
                                if (latitude == null) latitude = manualLatInput.toDoubleOrNull() ?: 0.0
                                if (longitude == null) longitude = manualLonInput.toDoubleOrNull() ?: 0.0
                                currentStep = 3
                            },
                            modifier = Modifier.weight(1f).height(50.dp).testTag("onboarding_step2_next"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                        ) {
                            Text("Next: Soil & Water →", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                3 -> {
                    // STEP 3: Farm Details & Soil
                    Text("Farm Land, Soil & Irrigation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = totalArea,
                        onValueChange = { totalArea = it },
                        label = { Text("Total Farm Area ($measurementUnit) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_area"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = primarySoilType,
                        onValueChange = { primarySoilType = it },
                        label = { Text("Primary Soil Type") },
                        placeholder = { Text("Black Cotton, Alluvial, Red Loam") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = soilPh, onValueChange = { soilPh = it }, label = { Text("Soil pH (Optional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                        OutlinedTextField(value = irrigationMethod, onValueChange = { irrigationMethod = it }, label = { Text("Irrigation Method") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                    }

                    OutlinedTextField(
                        value = waterSource,
                        onValueChange = { waterSource = it },
                        label = { Text("Water Source") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { currentStep = 2 }, modifier = Modifier.weight(1f).height(50.dp)) {
                            Text("← Back")
                        }
                        Button(
                            onClick = { currentStep = 4 },
                            modifier = Modifier.weight(1f).height(50.dp).testTag("onboarding_step3_next"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                        ) {
                            Text("Next: First Crop →", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                4 -> {
                    // STEP 4: First Crop Setup (Skippable)
                    Text("Initial Crop Setup (Optional)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Register your first active crop or skip to complete setup immediately.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = cropName,
                        onValueChange = { cropName = it },
                        label = { Text("Crop Name") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = cropVariety, onValueChange = { cropVariety = it }, label = { Text("Variety / Hybrid") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                        OutlinedTextField(value = cropArea, onValueChange = { cropArea = it }, label = { Text("Planted Area ($measurementUnit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp))
                    }

                    Button(
                        onClick = {
                            viewModel.completeOnboarding(
                                farmerFullName = fullName,
                                phone = phone,
                                language = preferredLanguage,
                                state = state,
                                district = district,
                                taluka = taluka,
                                village = village.ifBlank { "Akola Rural" },
                                pinCode = pinCode,
                                farmName = farmName.ifBlank { "My Farm" },
                                totalArea = totalArea.toDoubleOrNull() ?: 10.0,
                                areaUnit = measurementUnit,
                                lat = latitude ?: 20.5841,
                                lon = longitude ?: 77.0620,
                                soilType = primarySoilType,
                                irrigation = irrigationMethod,
                                firstCropName = cropName.takeIf { it.isNotBlank() },
                                firstCropVariety = cropVariety,
                                firstCropArea = cropArea.toDoubleOrNull() ?: 4.0
                            )
                            onOnboardingFinished()
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("onboarding_finish_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Complete Setup & Open My Farm", fontWeight = FontWeight.Bold)
                    }

                    TextButton(
                        onClick = {
                            viewModel.completeOnboarding(
                                farmerFullName = fullName,
                                phone = phone,
                                language = preferredLanguage,
                                state = state,
                                district = district,
                                taluka = taluka,
                                village = village.ifBlank { "Farm Location" },
                                pinCode = pinCode,
                                farmName = farmName.ifBlank { "My Farm" },
                                totalArea = totalArea.toDoubleOrNull() ?: 1.0,
                                areaUnit = measurementUnit,
                                lat = latitude ?: 0.0,
                                lon = longitude ?: 0.0,
                                soilType = primarySoilType,
                                irrigation = irrigationMethod,
                                firstCropName = null,
                                firstCropVariety = "",
                                firstCropArea = 0.0
                            )
                            onOnboardingFinished()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Skip Crop Setup for Now", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
