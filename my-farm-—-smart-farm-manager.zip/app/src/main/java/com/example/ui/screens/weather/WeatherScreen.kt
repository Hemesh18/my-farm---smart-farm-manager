package com.example.ui.screens.weather

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.AgriWeatherAlert
import com.example.data.remote.DailyForecastItem
import com.example.data.remote.HourlyForecastItem
import com.example.ui.components.MetricStatCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val weatherInfo by viewModel.weatherInfo.collectAsState()
    val isLoading by viewModel.isLoadingWeather.collectAsState()
    val farmProfile by viewModel.farmProfile.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (currentLanguage) {
                                "Marathi" -> "शेती हवामान अंदाज"
                                "Hindi" -> "कृषि मौसम पूर्वानुमान"
                                else -> "Weather Intelligence"
                            },
                            fontWeight = FontWeight.Bold
                        )
                        val villageName = farmProfile?.village?.takeIf { it.isNotBlank() } ?: "Farm Location"
                        val districtName = farmProfile?.district?.takeIf { it.isNotBlank() } ?: ""
                        val locationSub = if (districtName.isNotBlank()) "$villageName, $districtName" else villageName
                        Text(
                            locationSub,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("weather_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.loadWeather() },
                        modifier = Modifier.testTag("refresh_weather_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        val w = weatherInfo
        val hasCoords = farmProfile?.latitude != null && farmProfile?.latitude != 0.0
        if (w == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isLoading) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = ForestGreenPrimary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Fetching live weather for your farm...")
                    }
                } else if (!hasCoords) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.LocationOff, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Farm GPS Location Missing", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Live weather forecasts and spraying advisories require your farm's confirmed GPS coordinates. Please update your farm location in Settings.",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onNavigateBack,
                                colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                            ) {
                                Text("Go Back & Set Location")
                            }
                        }
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Weather unavailable. Tap Refresh above to try again.")
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.loadWeather() }) {
                            Text("Retry Weather")
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Main Current Weather Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${w.temperature.toInt()}°C",
                                        style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        text = w.condition,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                    Text(
                                        text = "Feels like ${w.feelsLike.toInt()}°C",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WbSunny,
                                        contentDescription = null,
                                        tint = HarvestAmberTertiaryContainer,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val humLabel = when (currentLanguage) { "Marathi" -> "आर्द्रता"; "Hindi" -> "नमी"; else -> "Humidity" }
                                val rainLabel = when (currentLanguage) { "Marathi" -> "पाऊस धोका"; "Hindi" -> "बारिश जोखिम"; else -> "Rain Risk" }
                                val precipLabel = when (currentLanguage) { "Marathi" -> "पर्जन्य"; "Hindi" -> "वर्षा"; else -> "Precipitation" }
                                val windLabel = when (currentLanguage) { "Marathi" -> "वारा"; "Hindi" -> "हवा"; else -> "Wind" }

                                WeatherMiniChip(label = humLabel, value = "${w.humidity}%")
                                WeatherMiniChip(label = rainLabel, value = "${w.rainProbability}%")
                                WeatherMiniChip(label = precipLabel, value = "${w.precipitationMm} mm")
                                WeatherMiniChip(label = windLabel, value = "${w.windSpeedKmh} km/h")
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Source: ${if (w.isLiveApi) "Open-Meteo Global Satellite Forecast" else "Local Station Cache"} • Updated ${w.lastUpdated}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }

                // Agricultural Spraying Window Advisory
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (w.sprayingSuitability.isSuitable) HealthGoodGreen.copy(alpha = 0.12f) else HealthWarningRed.copy(alpha = 0.12f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (w.sprayingSuitability.isSuitable) HealthGoodGreen else HealthWarningRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (w.sprayingSuitability.isSuitable) Icons.Default.Check else Icons.Default.Close,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Foliar Spraying: ${w.sprayingSuitability.statusText}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (w.sprayingSuitability.isSuitable) HealthGoodGreen else HealthWarningRed
                                )
                                Text(
                                    text = w.sprayingSuitability.reason,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Agricultural Alerts
                item {
                    Text("Agricultural Alerts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                items(w.agriculturalAlerts) { alert ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.WarningAmber, contentDescription = null, tint = HarvestAmberTertiary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(alert.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(alert.message, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "Recommended: ${alert.actionAdvice}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    modifier = Modifier.padding(8.dp),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                // Hourly Forecast
                item {
                    Text("Hourly Forecast (Next 12 Hours)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(w.hourlyForecast) { item ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(item.timeFormatted, style = MaterialTheme.typography.labelSmall)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Icon(Icons.Default.Cloud, contentDescription = null, tint = WaterBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("${item.temperature.toInt()}°C", fontWeight = FontWeight.Bold)
                                    Text("${item.rainProb}% rain", style = MaterialTheme.typography.labelSmall, color = WaterBlue)
                                }
                            }
                        }
                    }
                }

                // 7-Day Forecast
                item {
                    Text("7-Day Agricultural Outlook", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                items(w.dailyForecast) { day ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(day.dayName, fontWeight = FontWeight.Bold, modifier = Modifier.width(70.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.WaterDrop, contentDescription = null, tint = WaterBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${day.rainProb}%", style = MaterialTheme.typography.bodySmall)
                            }
                            Text(day.condition, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${day.maxTemp.toInt()}° / ${day.minTemp.toInt()}°C", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}

@Composable
private fun WeatherMiniChip(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
    }
}
