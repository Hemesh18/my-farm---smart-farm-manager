package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CropRecord
import com.example.data.model.FarmTask
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FarmViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FarmViewModel,
    onOpenDrawer: (() -> Unit)? = null,
    onNavigateToCropDetail: (String) -> Unit,
    onNavigateToAddCrop: () -> Unit,
    onNavigateToWeather: () -> Unit,
    onNavigateToAiAssistant: () -> Unit,
    onNavigateToScanner: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    onNavigateToFinances: () -> Unit,
    onNavigateToIrrigation: () -> Unit,
    onNavigateToFertilizer: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val farmProfile by viewModel.farmProfile.collectAsState()
    val activeCrops by viewModel.activeCrops.collectAsState()
    val fields by viewModel.allFields.collectAsState()
    val tasks by viewModel.allTasks.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val weatherInfo by viewModel.weatherInfo.collectAsState()
    val isLoadingWeather by viewModel.isLoadingWeather.collectAsState()

    val pendingTasks = tasks.filter { !it.isCompleted }
    val seasonalExpenses = transactions
        .filter { it.type == "EXPENSE" && it.year == 2026 }
        .sumOf { it.amount }

    val currentDateStr = remember {
        SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault()).format(Date())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (onOpenDrawer != null) {
                        IconButton(
                            onClick = { onOpenDrawer() },
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Navigation Drawer"
                            )
                        }
                    }
                },
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = farmProfile?.farmName ?: "My Farm",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = ForestGreenPrimary.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = farmProfile?.district?.ifBlank { "Location Unset" } ?: "Location Unset",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = ForestGreenPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Namaste, ${farmProfile?.farmerName ?: "Farmer"} • $currentDateStr",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    // Weather summary pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .testTag("weather_pill_header")
                            .clickable { onNavigateToWeather() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.WbSunny,
                                contentDescription = "Weather",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = weatherInfo?.let { "${it.temperature.toInt()}°C" } ?: "--°C",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    IconButton(
                        onClick = onNavigateToCalendar,
                        modifier = Modifier.testTag("notification_bell_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (pendingTasks.isNotEmpty()) {
                                    Badge { Text("${pendingTasks.size}") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Farm Overview Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("farm_overview_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Farm Overview (2026 Kharif)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "${farmProfile?.totalArea ?: 15.0} ${farmProfile?.areaUnit ?: "Acre"} Total Area",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "${fields.size} Plots Active",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OverviewMiniStat(label = "Active Crops", value = "${activeCrops.size}", icon = Icons.Default.Eco)
                            OverviewMiniStat(label = "Pending Tasks", value = "${pendingTasks.size}", icon = Icons.Default.Assignment)
                            OverviewMiniStat(
                                label = "Season Expenses",
                                value = "₹${String.format("%,.0f", seasonalExpenses)}",
                                icon = Icons.Default.CurrencyRupee
                            )
                        }
                    }
                }
            }

            // 2. Today's Farm Briefing (Prominent Advisory)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("todays_farm_briefing_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(LeafGreenSecondary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lightbulb,
                                        contentDescription = null,
                                        tint = LeafGreenSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Today's Farm Briefing",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Actionable intelligence tailored to your fields",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        if (activeCrops.isEmpty()) {
                            Text(
                                text = "Welcome to My Farm! Add your first plot and crop below to receive personalized agronomic advisories and weather alerts.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            activeCrops.take(2).forEachIndexed { idx, crop ->
                                BriefingItem(
                                    icon = if (idx == 0) Icons.Default.Warning else Icons.Default.WaterDrop,
                                    iconTint = if (idx == 0) HarvestAmberTertiary else WaterBlue,
                                    cropField = "${crop.fieldName} • ${crop.cropName} (${crop.variety})",
                                    action = "Growth Stage: ${crop.currentGrowthStage}",
                                    reason = "Health condition: ${crop.healthCondition}. Status: ${crop.status}."
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                            }
                            if (weatherInfo != null) {
                                BriefingItem(
                                    icon = Icons.Default.CheckCircle,
                                    iconTint = HealthGoodGreen,
                                    cropField = "Farm Wide • Spraying Window",
                                    action = weatherInfo?.sprayingSuitability?.statusText ?: "Check Weather",
                                    reason = weatherInfo?.sprayingSuitability?.reason ?: "Based on live satellite forecast for your farm."
                                )
                            }
                        }
                    }
                }
            }

            // 3. Quick Action Buttons Grid
            item {
                Text(
                    text = "Quick Farm Actions",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        title = "Add Crop",
                        icon = Icons.Default.AddCircleOutline,
                        color = ForestGreenPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToAddCrop
                    )
                    QuickActionButton(
                        title = "Log Drip",
                        icon = Icons.Default.Opacity,
                        color = WaterBlue,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToIrrigation
                    )
                    QuickActionButton(
                        title = "Add Expense",
                        icon = Icons.Default.ReceiptLong,
                        color = HarvestAmberTertiary,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToFinances
                    )
                    QuickActionButton(
                        title = "Scan Disease",
                        icon = Icons.Default.CenterFocusStrong,
                        color = HealthWarningRed,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToScanner
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        title = "Add Task",
                        icon = Icons.Default.AddTask,
                        color = ForestGreenPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToCalendar
                    )
                    QuickActionButton(
                        title = "Fertilizer",
                        icon = Icons.Default.Science,
                        color = LeafGreenSecondary,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToFertilizer
                    )
                    QuickActionButton(
                        title = "History",
                        icon = Icons.Default.HistoryEdu,
                        color = SoilBrown,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToHistory
                    )
                    QuickActionButton(
                        title = "Ask AI",
                        icon = Icons.Default.AutoAwesome,
                        color = Color(0xFF6A1B9A),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToAiAssistant
                    )
                }
            }

            // 4. Live Weather Preview Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToWeather() }
                        .testTag("weather_preview_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CloudQueue,
                                    contentDescription = null,
                                    tint = WaterBlue
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Agricultural Weather",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = "View 7-Day Forecast →",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        val weather = weatherInfo
                        if (weather != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${weather.temperature}°C",
                                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${weather.condition} • Feels like ${weather.feelsLike}°C",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Rain: ${weather.rainProbability}%",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = "Wind: ${weather.windSpeedKmh} km/h • Hum: ${weather.humidity}%",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else if (farmProfile?.latitude == null || farmProfile?.latitude == 0.0) {
                            Text(
                                text = "Farm coordinates missing. Tap to set GPS location in Settings →",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else {
                            Text(
                                text = "Loading live weather for your coordinates...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 5. Active Crops Section
            item {
                SectionHeader(
                    title = "Active Crops (${activeCrops.size})",
                    subtitle = "Growing on your fields right now",
                    actionText = "+ Add Crop",
                    onActionClick = onNavigateToAddCrop
                )
            }

            if (activeCrops.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Eco, contentDescription = null, tint = LeafGreenSecondary, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No active crops planted yet", fontWeight = FontWeight.Bold)
                            Text("Add your first crop to track growth, irrigation, and harvest window.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = onNavigateToAddCrop) {
                                Text("Register Crop")
                            }
                        }
                    }
                }
            } else {
                items(activeCrops) { crop ->
                    ActiveCropCard(
                        crop = crop,
                        onClick = { onNavigateToCropDetail(crop.id) }
                    )
                }
            }

            // 6. Upcoming Tasks List
            item {
                SectionHeader(
                    title = "Pending Tasks (${pendingTasks.size})",
                    subtitle = "Farm tasks due for action",
                    actionText = "All Tasks",
                    onActionClick = onNavigateToCalendar
                )
            }

            if (pendingTasks.isEmpty()) {
                item {
                    Text(
                        text = "All scheduled farm activities are completed. Great work!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(pendingTasks.take(4)) { task ->
                    TaskRowItem(
                        task = task,
                        onToggle = { viewModel.toggleTaskCompleted(task) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun OverviewMiniStat(label: String, value: String, icon: ImageVector) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
    }
}

@Composable
private fun BriefingItem(
    icon: ImageVector,
    iconTint: Color,
    cropField: String,
    action: String,
    reason: String
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = action, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Text(text = cropField, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    title: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("quick_action_${title.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
fun ActiveCropCard(
    crop: CropRecord,
    onClick: () -> Unit
) {
    val ageDays = remember(crop.sowingDateMillis) {
        ((System.currentTimeMillis() - crop.sowingDateMillis) / (24L * 60 * 60 * 1000)).coerceAtLeast(0)
    }
    val progress = (ageDays.toFloat() / crop.expectedDurationDays.toFloat()).coerceIn(0f, 1f)
    val daysRemaining = (crop.expectedDurationDays - ageDays).coerceAtLeast(0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("crop_card_${crop.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = crop.cropName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${crop.variety} • ${crop.fieldName} (${crop.plantedArea} ${crop.areaUnit})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                CropHealthChip(status = crop.healthCondition)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Growth Stage Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Stage: ${crop.currentGrowthStage}",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Day $ageDays of ${crop.expectedDurationDays} (${daysRemaining}d to harvest)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = LeafGreenSecondary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Est. Yield: ${crop.expectedYield} ${crop.yieldUnit}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Tap for 10-Tab Records →",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun TaskRowItem(
    task: FarmTask,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .testTag("task_item_${task.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onToggle() },
                modifier = Modifier.testTag("task_checkbox_${task.id}")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (task.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                    )
                )
                if (task.description.isNotBlank()) {
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            PriorityBadge(priority = task.priority)
        }
    }
}
