package com.example.ui.screens.journal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.JournalEntry
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.viewmodel.FarmViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmJournalScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val entries by viewModel.journalEntries.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Farm Activity Journal", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("journal_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = ForestGreenPrimary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_journal_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Observation")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Permanent Farm Diary & Observations (${entries.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (entries.isEmpty()) {
                item {
                    Text("No journal entries yet. Tap + to record field notes, growth milestones, or weather incidents.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(entries) { entry ->
                    val dateFormatted = remember(entry.dateMillis) {
                        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(entry.dateMillis))
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(entry.title, fontWeight = FontWeight.Bold)
                                Text(entry.observationType, style = MaterialTheme.typography.labelSmall, color = ForestGreenPrimary)
                            }
                            Text(
                                text = "$dateFormatted • ${entry.fieldName} ${if (entry.cropName.isNotBlank()) "• " + entry.cropName else ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(entry.notes, style = MaterialTheme.typography.bodyMedium)
                            if (entry.weatherSummary.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Weather: ${entry.weatherSummary}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        var observationType by remember { mutableStateOf("Growth Milestone") }
        var fieldName by remember { mutableStateOf("Plot A (North Valley)") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Farm Diary Entry", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Observation Title") })
                    OutlinedTextField(value = observationType, onValueChange = { observationType = it }, label = { Text("Category (Pest, Weather, Milestone)") })
                    OutlinedTextField(value = fieldName, onValueChange = { fieldName = it }, label = { Text("Field / Location") })
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Detailed Observation Notes") }, minLines = 3)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            viewModel.addJournalEntry(
                                JournalEntry(
                                    title = title,
                                    observationType = observationType,
                                    fieldName = fieldName,
                                    notes = notes
                                )
                            )
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Save to Diary")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
