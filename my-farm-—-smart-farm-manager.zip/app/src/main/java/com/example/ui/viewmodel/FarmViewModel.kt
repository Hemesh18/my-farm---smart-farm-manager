package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FarmDatabase
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.FarmRepository
import com.example.data.repository.SearchResults
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class FarmViewModel(application: Application) : AndroidViewModel(application) {

    private val database = FarmDatabase.getDatabase(application, viewModelScope)
    private val repository = FarmRepository(database.farmDao())
    private val sessionManager = SessionManager(application)

    // 1. Authenticated User State & Session Initialization
    private val _isAuthInitializing = MutableStateFlow(true)
    val isAuthInitializing: StateFlow<Boolean> = _isAuthInitializing.asStateFlow()

    private val _currentUser = MutableStateFlow<UserAccount?>(null)
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    val isLoggedIn: StateFlow<Boolean> = _currentUser.map { it != null }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val userEmail: StateFlow<String> = _currentUser.map { it?.email ?: "" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    private val _currentLanguage = MutableStateFlow<String>("English")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
        val user = _currentUser.value
        if (user != null) {
            viewModelScope.launch {
                val updatedUser = user.copy(preferredLanguage = lang)
                repository.updateUser(updatedUser)
                _currentUser.value = updatedUser
            }
        }
        val farm = currentFarmProfile.value
        if (farm != null) {
            viewModelScope.launch {
                val updatedFarm = farm.copy(preferredLanguage = lang)
                repository.saveFarmProfile(updatedFarm)
            }
        }
    }

    // 2. Multi-Farm State
    val userFarms: StateFlow<List<FarmProfile>> = _currentUser.flatMapLatest { user ->
        if (user != null) repository.getFarmsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedFarmId = MutableStateFlow<String?>(null)

    val currentFarmProfile: StateFlow<FarmProfile?> = combine(userFarms, _selectedFarmId) { farms, selectedId ->
        if (selectedId != null) farms.find { it.id == selectedId } ?: farms.firstOrNull()
        else farms.find { it.isDefault } ?: farms.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Legacy alias
    val farmProfile: StateFlow<FarmProfile?> = currentFarmProfile

    // 3. User & Farm Scoped Data Streams
    val allFields: StateFlow<List<FieldPlot>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getFieldsForFarm(user.id, farm.id)
        else if (user != null) repository.getAllFieldsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCrops: StateFlow<List<CropRecord>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getActiveCropsForFarm(user.id, farm.id)
        else if (user != null) repository.getActiveCropsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCrops: StateFlow<List<CropRecord>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getCropsForFarm(user.id, farm.id)
        else if (user != null) repository.getAllCropsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTasks: StateFlow<List<FarmTask>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getTasksForFarm(user.id, farm.id)
        else if (user != null) repository.getAllTasksForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<FarmTransaction>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getTransactionsForFarm(user.id, farm.id)
        else if (user != null) repository.getAllTransactionsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val irrigationLogs: StateFlow<List<IrrigationLog>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getIrrigationLogsForFarm(user.id, farm.id)
        else if (user != null) repository.getAllIrrigationLogsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fertilizerLogs: StateFlow<List<FertilizerLog>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getFertilizerLogsForFarm(user.id, farm.id)
        else if (user != null) repository.getAllFertilizerLogsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val diseaseScans: StateFlow<List<DiseaseScanRecord>> = _currentUser.flatMapLatest { user ->
        if (user != null) repository.getDiseaseScansForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val journalEntries: StateFlow<List<JournalEntry>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getJournalEntriesForFarm(user.id, farm.id)
        else if (user != null) repository.getAllJournalEntriesForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val soilTests: StateFlow<List<SoilTestRecord>> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getSoilTestsForFarm(user.id, farm.id)
        else if (user != null) repository.getAllSoilTestsForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiMessages: StateFlow<List<AiChatMessage>> = _currentUser.flatMapLatest { user ->
        if (user != null) repository.getAiMessagesForUser(user.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentFarmBoundary: StateFlow<FarmBoundaryRecord?> = combine(_currentUser, currentFarmProfile) { user, farm ->
        Pair(user, farm)
    }.flatMapLatest { (user, farm) ->
        if (user != null && farm != null) repository.getBoundaryForFarm(user.id, farm.id)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // 4. Platform Admin Data
    val allRegisteredUsers: StateFlow<List<UserAccount>> = repository.getAllUsersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLog>> = repository.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 5. Weather State
    private val _weatherInfo = MutableStateFlow<WeatherInfo?>(null)
    val weatherInfo: StateFlow<WeatherInfo?> = _weatherInfo.asStateFlow()

    private val _isLoadingWeather = MutableStateFlow(false)
    val isLoadingWeather: StateFlow<Boolean> = _isLoadingWeather.asStateFlow()

    // 6. UI & Filtering State
    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    private val _selectedYear = MutableStateFlow(2026)
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedSeason = MutableStateFlow("All")
    val selectedSeason: StateFlow<String> = _selectedSeason.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<SearchResults?>(null)
    val searchResults: StateFlow<SearchResults?> = _searchResults.asStateFlow()

    private val _satellitePasses = MutableStateFlow(SatelliteService.getHistoricalPasses())
    val satellitePasses: StateFlow<List<SatellitePass>> = _satellitePasses.asStateFlow()

    private val _selectedSatellitePass = MutableStateFlow<SatellitePass?>(SatelliteService.getHistoricalPasses().firstOrNull())
    val selectedSatellitePass: StateFlow<SatellitePass?> = _selectedSatellitePass.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        // Restore persistent authentication session from SessionManager
        viewModelScope.launch {
            _isAuthInitializing.value = true
            val savedUserId = sessionManager.getActiveUserId()
            if (!savedUserId.isNullOrBlank()) {
                val user = repository.getUserById(savedUserId)
                if (user != null) {
                    _currentUser.value = user
                    _currentLanguage.value = user.preferredLanguage.ifBlank { "English" }
                    loadWeather()
                } else {
                    sessionManager.clearSession()
                }
            }
            _isAuthInitializing.value = false
        }
    }

    fun selectFarm(farm: FarmProfile) {
        _selectedFarmId.value = farm.id
        loadWeather()
        _userMessage.value = "Active farm switched to ${farm.farmName}"
    }

    fun registerFarmer(
        email: String,
        passwordRaw: String,
        fullName: String,
        phone: String,
        language: String = "English",
        onSuccess: (UserAccount) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.registerUser(
                email = email,
                passwordRaw = passwordRaw,
                fullName = fullName,
                phone = phone,
                preferredLanguage = language
            )
            res.onSuccess { user ->
                sessionManager.saveActiveUserId(user.id)
                _currentUser.value = user
                _currentLanguage.value = language
                _selectedFarmId.value = null
                _userMessage.value = "Welcome, ${user.fullName}! Let's set up your farm."
                onSuccess(user)
            }.onFailure { err ->
                onError(err.message ?: "Registration failed.")
            }
        }
    }

    fun loginFarmer(
        email: String,
        passwordRaw: String,
        onSuccess: (UserAccount) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.loginUser(email, passwordRaw)
            res.onSuccess { user ->
                sessionManager.saveActiveUserId(user.id)
                _currentUser.value = user
                _currentLanguage.value = user.preferredLanguage.ifBlank { "English" }
                loadWeather()
                _userMessage.value = "Welcome back, ${user.fullName}!"
                onSuccess(user)
            }.onFailure { err ->
                onError(err.message ?: "Login failed.")
            }
        }
    }

    fun requestPasswordReset(
        email: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.requestPasswordReset(email)
            result.onSuccess { token ->
                onSuccess(token)
            }.onFailure { ex ->
                onError(ex.message ?: "Failed to issue password reset.")
            }
        }
    }

    fun resetPasswordWithToken(
        email: String,
        tokenCode: String,
        newPasswordRaw: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.resetPasswordWithToken(email, tokenCode, newPasswordRaw)
            result.onSuccess {
                _userMessage.value = "Password updated successfully! Please sign in with your new password."
                onSuccess()
            }.onFailure { ex ->
                onError(ex.message ?: "Failed to reset password.")
            }
        }
    }

    fun loginGuestMode() {
        viewModelScope.launch {
            val guest = UserAccount(
                id = "guest_" + System.currentTimeMillis(),
                email = "offline_kisan@myfarm.local",
                passwordHash = "",
                fullName = "Offline Farmer",
                role = "FARMER",
                subscriptionPlan = "FREE",
                isOnboardingCompleted = true
            )
            repository.insertUser(guest)
            sessionManager.saveActiveUserId(guest.id)
            _currentUser.value = guest
            loadWeather()
        }
    }

    fun logout() {
        viewModelScope.launch {
            _currentUser.value?.let { u ->
                repository.logAudit(u.id, u.email, "USER_LOGOUT", "User logged out")
            }
            sessionManager.clearSession()
            _currentUser.value = null
            _selectedFarmId.value = null
            _weatherInfo.value = null
        }
    }

    fun completeOnboarding(
        farmerFullName: String,
        phone: String,
        language: String,
        state: String,
        district: String,
        taluka: String,
        village: String,
        pinCode: String,
        farmName: String,
        totalArea: Double,
        areaUnit: String,
        lat: Double,
        lon: Double,
        soilType: String,
        irrigation: String,
        firstCropName: String?,
        firstCropVariety: String,
        firstCropArea: Double
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            // 1. Update user
            val updatedUser = user.copy(
                fullName = farmerFullName,
                phone = phone,
                preferredLanguage = language,
                state = state,
                district = district,
                taluka = taluka,
                village = village,
                pinCode = pinCode,
                measurementUnit = areaUnit,
                isOnboardingCompleted = true
            )
            repository.updateUser(updatedUser)
            _currentUser.value = updatedUser

            // 2. Create initial farm
            val farm = FarmProfile(
                userId = user.id,
                farmName = farmName,
                farmerName = farmerFullName,
                email = user.email,
                village = village,
                district = district,
                state = state,
                pinCode = pinCode,
                latitude = lat,
                longitude = lon,
                locationAccuracyMeters = 10f,
                locationSource = "ONBOARDING_GPS",
                totalArea = totalArea,
                areaUnit = areaUnit,
                primarySoilType = soilType,
                irrigationSource = irrigation,
                isDefault = true,
                isOnboardingComplete = true
            )
            repository.saveFarmProfile(farm)
            _selectedFarmId.value = farm.id

            // 3. Create default field
            val defaultField = FieldPlot(
                userId = user.id,
                farmId = farm.id,
                name = "Plot 1 (Main Field)",
                area = totalArea,
                areaUnit = areaUnit,
                soilType = soilType,
                irrigationMethod = irrigation
            )
            repository.insertField(defaultField)

            // 4. Register first crop if specified
            if (!firstCropName.isNullOrBlank()) {
                val crop = CropRecord(
                    userId = user.id,
                    farmId = farm.id,
                    fieldId = defaultField.id,
                    fieldName = defaultField.name,
                    cropName = firstCropName,
                    variety = firstCropVariety.ifBlank { "Certified" },
                    season = "Kharif",
                    year = 2026,
                    sowingDateMillis = System.currentTimeMillis() - (15L * 24 * 60 * 60 * 1000),
                    plantedArea = firstCropArea,
                    areaUnit = areaUnit,
                    status = "Growing",
                    currentGrowthStage = "Vegetative Establishment",
                    notes = "Registered during initial onboarding."
                )
                repository.insertCrop(crop)
            }

            repository.logAudit(user.id, user.email, "ONBOARDING_COMPLETED", "Completed farm setup: $farmName")
            _currentLanguage.value = language
            loadWeather()
            _userMessage.value = "Farm setup completed successfully!"
        }
    }

    fun updateSubscription(newPlan: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val updated = user.copy(subscriptionPlan = newPlan, subscriptionStatus = "ACTIVE")
            repository.updateUser(updated)
            _currentUser.value = updated
            repository.logAudit(user.id, user.email, "PLAN_UPDATE", "Upgraded plan to $newPlan")
            _userMessage.value = "Subscription plan updated to $newPlan."
        }
    }

    fun loadWeather() {
        viewModelScope.launch {
            val farm = currentFarmProfile.value
            val lat = farm?.latitude
            val lon = farm?.longitude
            if (farm != null && lat != null && lon != null && (lat != 0.0 || lon != 0.0)) {
                _isLoadingWeather.value = true
                try {
                    val weather = repository.fetchWeather(lat, lon)
                    _weatherInfo.value = weather
                } catch (e: Exception) {
                    _weatherInfo.value = null
                } finally {
                    _isLoadingWeather.value = false
                }
            } else {
                _weatherInfo.value = null
                _isLoadingWeather.value = false
            }
        }
    }

    fun setSelectedYear(year: Int) { _selectedYear.value = year }
    fun setSelectedSeason(season: String) { _selectedSeason.value = season }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        val user = _currentUser.value ?: return
        if (query.isBlank()) {
            _searchResults.value = null
        } else {
            viewModelScope.launch {
                val results = repository.searchFarmHistory(user.id, query)
                _searchResults.value = results
            }
        }
    }

    fun selectSatellitePass(pass: SatellitePass) {
        _selectedSatellitePass.value = pass
    }

    fun logAudit(action: String, details: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repository.logAudit(user.id, user.email, action, details)
        }
    }

    // CRUD with user & farm scoping
    fun saveFarmProfile(profile: FarmProfile) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val scoped = profile.copy(userId = user.id)
            repository.saveFarmProfile(scoped)
            _userMessage.value = "Farm profile '${scoped.farmName}' saved."
            loadWeather()
        }
    }

    fun addField(name: String, area: Double, soil: String, irrigation: String, colorHex: String) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value ?: return
        viewModelScope.launch {
            val field = FieldPlot(
                userId = user.id,
                farmId = farm.id,
                name = name,
                area = area,
                soilType = soil,
                irrigationMethod = irrigation,
                colorHex = colorHex
            )
            repository.insertField(field)
            _userMessage.value = "Plot '$name' added to ${farm.farmName}."
        }
    }

    fun deleteField(field: FieldPlot) {
        viewModelScope.launch {
            repository.deleteField(field)
            _userMessage.value = "Field deleted."
        }
    }

    fun addCrop(crop: CropRecord) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = crop.copy(userId = user.id, farmId = farm?.id ?: crop.farmId)
            repository.insertCrop(scoped)
            _userMessage.value = "Crop '${scoped.cropName}' registered successfully."
        }
    }

    fun updateCrop(crop: CropRecord) {
        viewModelScope.launch {
            repository.updateCrop(crop)
            _userMessage.value = "Crop updated."
        }
    }

    fun deleteCrop(crop: CropRecord) {
        viewModelScope.launch {
            repository.deleteCrop(crop)
            _userMessage.value = "Crop deleted."
        }
    }

    fun toggleTaskCompleted(task: FarmTask) {
        viewModelScope.launch {
            val updated = task.copy(
                isCompleted = !task.isCompleted,
                completedAtMillis = if (!task.isCompleted) System.currentTimeMillis() else null
            )
            repository.updateTask(updated)
        }
    }

    fun addTask(task: FarmTask) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = task.copy(userId = user.id, farmId = farm?.id ?: task.farmId)
            repository.insertTask(scoped)
            _userMessage.value = "Task scheduled: ${task.title}"
        }
    }

    fun deleteTask(task: FarmTask) {
        viewModelScope.launch {
            repository.deleteTask(task)
            _userMessage.value = "Task removed."
        }
    }

    fun addIrrigationLog(log: IrrigationLog) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = log.copy(userId = user.id, farmId = farm?.id ?: log.farmId)
            repository.insertIrrigationLog(scoped)
            _userMessage.value = "Irrigation event logged."
        }
    }

    fun addFertilizerLog(log: FertilizerLog) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = log.copy(userId = user.id, farmId = farm?.id ?: log.farmId)
            repository.insertFertilizerLog(scoped)
            _userMessage.value = "Fertilizer application recorded."
        }
    }

    fun addTransaction(transaction: FarmTransaction) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = transaction.copy(userId = user.id, farmId = farm?.id ?: transaction.farmId)
            repository.insertTransaction(scoped)
            _userMessage.value = "Transaction recorded."
        }
    }

    fun deleteTransaction(transaction: FarmTransaction) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            _userMessage.value = "Transaction deleted."
        }
    }

    fun addJournalEntry(entry: JournalEntry) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = entry.copy(userId = user.id, farmId = farm?.id ?: entry.farmId)
            repository.insertJournalEntry(scoped)
            _userMessage.value = "Observation saved to farm diary."
        }
    }

    fun addSoilTest(test: SoilTestRecord) {
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            val scoped = test.copy(userId = user.id, farmId = farm?.id ?: test.farmId)
            repository.insertSoilTest(scoped)
            _userMessage.value = "Soil test report saved."
        }
    }

    fun sendAiPrompt(prompt: String, language: String = "English") {
        if (prompt.isBlank()) return
        val user = _currentUser.value ?: return
        val farm = currentFarmProfile.value
        viewModelScope.launch {
            repository.insertAiMessage(AiChatMessage(userId = user.id, role = "user", content = prompt))
            _isAiThinking.value = true

            val result = repository.queryAiAssistant(user.id, farm?.id, prompt, _weatherInfo.value, language)
            repository.insertAiMessage(
                AiChatMessage(
                    userId = user.id,
                    role = "assistant",
                    content = result.text,
                    citedRecords = result.citedRecords
                )
            )
            _isAiThinking.value = false
        }
    }

    fun clearAiChat() {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repository.clearAiChatForUser(user.id)
            _userMessage.value = "Conversation cleared."
        }
    }

    suspend fun diagnoseDisease(
        cropName: String,
        fieldName: String,
        symptoms: String,
        bitmap: Bitmap?,
        language: String
    ): DiseaseScanResult {
        val user = _currentUser.value
        val farm = currentFarmProfile.value
        val result = repository.diagnoseCropDisease(cropName, fieldName, symptoms, bitmap, language)
        if (user != null) {
            val scanRecord = DiseaseScanRecord(
                userId = user.id,
                farmId = farm?.id ?: "default_farm",
                cropName = cropName,
                fieldName = fieldName,
                symptomsInput = symptoms,
                diagnosisTitle = result.diagnosisTitle,
                diagnosisConfidence = result.confidence,
                identifiedIssueType = result.issueType,
                visualSigns = result.visualSigns,
                safeImmediateActions = result.immediateSafeActions,
                preventionGuidance = result.prevention,
                expertConsultationRecommendation = result.expertConsultation
            )
            repository.insertDiseaseScan(scanRecord)
        }
        return result
    }

    fun saveFarmBoundary(
        context: android.content.Context,
        points: List<com.google.android.gms.maps.model.LatLng>,
        areaAcres: Double,
        areaHectares: Double,
        centerLat: Double,
        centerLng: Double,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val user = _currentUser.value ?: run {
            onError("User not authenticated.")
            return
        }
        val farm = currentFarmProfile.value ?: run {
            onError("No active farm profile found.")
            return
        }
        viewModelScope.launch {
            try {
                val jsonArray = org.json.JSONArray()
                points.forEach { pt ->
                    jsonArray.put(org.json.JSONObject().apply {
                        put("lat", pt.latitude)
                        put("lng", pt.longitude)
                    })
                }

                val boundary = FarmBoundaryRecord(
                    id = "boundary_${farm.id}",
                    userId = user.id,
                    farmId = farm.id,
                    farmName = farm.farmName,
                    boundaryPointsJson = jsonArray.toString(),
                    areaAcres = areaAcres,
                    areaHectares = areaHectares,
                    centerLatitude = centerLat,
                    centerLongitude = centerLng,
                    updatedAt = System.currentTimeMillis()
                )

                repository.saveFarmBoundary(context, boundary)
                _userMessage.value = "Farm boundary saved successfully!"
                loadWeather()
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Failed to save boundary.")
            }
        }
    }
}
