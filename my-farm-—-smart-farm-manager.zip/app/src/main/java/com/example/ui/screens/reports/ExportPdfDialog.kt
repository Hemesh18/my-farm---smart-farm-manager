package com.example.ui.screens.reports

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.util.PdfExporter
import com.example.data.util.ReportType
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.viewmodel.FarmViewModel
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportPdfDialog(
    viewModel: FarmViewModel,
    initialReportType: ReportType = ReportType.COMPLETE,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val currentUser by viewModel.currentUser.collectAsState()
    val activeFarm by viewModel.currentFarmProfile.collectAsState()
    val fields by viewModel.allFields.collectAsState()
    val crops by viewModel.allCrops.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val tasks by viewModel.allTasks.collectAsState()
    val irrigations by viewModel.irrigationLogs.collectAsState()
    val fertilizers by viewModel.fertilizerLogs.collectAsState()
    val scans by viewModel.diseaseScans.collectAsState()
    val weather by viewModel.weatherInfo.collectAsState()

    var selectedType by remember { mutableStateOf(initialReportType) }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedFile by remember { mutableStateOf<File?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isGenerating) onDismiss() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = ForestGreenPrimary)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Export & Download PDF Report", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Generate professional multi-page printable PDF reports for banking, Krishi Vigyan Kendra (KVK), or personal farm records.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text("Select Report Type:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)

                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedType.title,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Report Category") },
                        modifier = Modifier.fillMaxWidth().menuAnchor().testTag("report_type_dropdown"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        ReportType.values().forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.title) },
                                onClick = {
                                    selectedType = type
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Report Scope Details:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Text("• Farm: ${activeFarm?.farmName ?: "Main Farm"}", style = MaterialTheme.typography.bodySmall)
                        Text("• Farmer: ${currentUser?.fullName ?: activeFarm?.farmerName ?: "Farmer"}", style = MaterialTheme.typography.bodySmall)
                        Text("• Currency: INR (₹) • Measurements: ${activeFarm?.areaUnit ?: "Acre"}", style = MaterialTheme.typography.bodySmall)
                        Text("• Data: Verified User Database Records", style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (isGenerating) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Rendering vector canvas & generating PDF...")
                    }
                }

                generatedFile?.let { file ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = HealthGoodGreen.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = HealthGoodGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("PDF Generated Successfully!", color = HealthGoodGreen, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = file.name,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Saved in app documents. Tap 'Open / Share PDF' below.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                errorMessage?.let { err ->
                    Text(text = "Error generating PDF: $err", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            if (generatedFile != null) {
                Button(
                    onClick = {
                        val shareIntent = PdfExporter.getSharePdfIntent(context, generatedFile!!)
                        context.startActivity(Intent.createChooser(shareIntent, "Open or Share Farm Report"))
                        viewModel.logAudit("EXPORT_PDF", "Downloaded ${generatedFile?.name}")
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier.testTag("open_share_pdf_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open / Share PDF")
                }
            } else {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isGenerating = true
                            errorMessage = null
                            val res = PdfExporter.generateAndSavePdf(
                                context = context,
                                reportType = selectedType,
                                user = currentUser,
                                farm = activeFarm,
                                fields = fields,
                                crops = crops,
                                transactions = transactions,
                                tasks = tasks,
                                irrigations = irrigations,
                                fertilizers = fertilizers,
                                scans = scans,
                                weather = weather
                            )
                            isGenerating = false
                            res.onSuccess { f ->
                                generatedFile = f
                            }.onFailure { err ->
                                errorMessage = err.message ?: "Unknown error"
                            }
                        }
                    },
                    enabled = !isGenerating,
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                    modifier = Modifier.testTag("confirm_generate_pdf_button")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Generate PDF")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isGenerating) {
                Text("Close")
            }
        }
    )
}
