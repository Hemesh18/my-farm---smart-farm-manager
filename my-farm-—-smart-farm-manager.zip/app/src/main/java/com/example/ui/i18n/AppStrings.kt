package com.example.ui.i18n

enum class SupportedLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    MARATHI("mr", "Marathi", "मराठी"),
    HINDI("hi", "Hindi", "हिंदी");

    companion object {
        fun fromString(value: String?): SupportedLanguage {
            return when (value?.trim()?.lowercase()) {
                "marathi", "mr", "मराठी" -> MARATHI
                "hindi", "hi", "हिंदी" -> HINDI
                else -> ENGLISH
            }
        }
    }
}

object AppStrings {

    fun get(key: String, lang: String): String {
        val language = SupportedLanguage.fromString(lang)
        return when (language) {
            SupportedLanguage.MARATHI -> marathiMap[key] ?: englishMap[key] ?: key
            SupportedLanguage.HINDI -> hindiMap[key] ?: englishMap[key] ?: key
            SupportedLanguage.ENGLISH -> englishMap[key] ?: key
        }
    }

    // Common crop translations for alias searching & display
    val cropAliases = mapOf(
        "Wheat" to listOf("Wheat", "गहू", "गेहूँ", "Gahu", "Gehun"),
        "Soybean" to listOf("Soybean", "सोयाबीन", "Soyabean"),
        "Cotton" to listOf("Cotton", "कापूस", "कपास", "Kapas", "Kapoos"),
        "Sugarcane" to listOf("Sugarcane", "ऊस", "गन्ना", "Oos", "Ganna"),
        "Onion" to listOf("Onion", "कांदा", "प्याज", "Kanda", "Pyaz"),
        "Tomato" to listOf("Tomato", "टोमॅटो", "टमाटर"),
        "Gram" to listOf("Gram", "Chickpea", "हरभरा", "चना", "Harbhara", "Chana"),
        "Tur" to listOf("Pigeon Pea", "तूर", "अरहर", "Toor", "Arhar"),
        "Maize" to listOf("Maize", "Corn", "मका", "मक्का", "Maka", "Makka"),
        "Rice" to listOf("Rice", "Paddy", "भात", "धान", "चावल", "Bhat", "Dhan")
    )

    fun matchesCropSearch(cropName: String, query: String): Boolean {
        if (cropName.contains(query, ignoreCase = true)) return true
        val q = query.trim().lowercase()
        for ((_, aliases) in cropAliases) {
            val matchesAlias = aliases.any { it.contains(q, ignoreCase = true) }
            val cropMatches = aliases.any { it.equals(cropName, ignoreCase = true) }
            if (matchesAlias && cropMatches) return true
        }
        return false
    }

    private val englishMap = mapOf(
        // Tabs & Navigation
        "tab_home" to "Home",
        "tab_crops" to "My Crops",
        "tab_map" to "Farm Map",
        "tab_assistant" to "AI Assistant",
        "tab_more" to "More",

        // Auth
        "auth_app_title" to "My Farm SaaS",
        "auth_app_subtitle" to "Secure Multi-Tenant Farm Management & Agronomic AI",
        "auth_sign_in" to "Farmer Sign In",
        "auth_registration" to "Farmer Registration",
        "auth_desc_login" to "Access your private farm records, weather, and AI advisor.",
        "auth_desc_signup" to "Create your private tenant account. You will be guided through setting up your farm.",
        "auth_name_label" to "Farmer Full Name *",
        "auth_phone_label" to "Mobile Phone Number *",
        "auth_email_label" to "Email Address *",
        "auth_password_label" to "Password (min 6 characters) *",
        "auth_confirm_password" to "Confirm Password *",
        "auth_terms" to "I accept the Terms of Service & Agricultural Data Privacy Policy",
        "auth_btn_login" to "Sign In to Farm",
        "auth_btn_register" to "Create Farmer Account",
        "auth_switch_to_signup" to "New farmer? Create free account",
        "auth_switch_to_login" to "Already have an account? Sign In",
        "auth_guest_mode" to "Explore in Offline / Guest Mode",
        "auth_language_select" to "Select Language / भाषा निवडा",
        "auth_forgot_password" to "Forgot Password?",
        "auth_forgot_title" to "Reset Your Password",
        "auth_forgot_desc" to "Enter your registered email address below. We will issue password reset instructions and a token.",
        "auth_btn_send_reset" to "Send Reset Link / Code",
        "auth_reset_title" to "Set New Password",
        "auth_reset_desc" to "Enter your reset token and set your new account password below.",
        "auth_token_label" to "Reset Token / Code *",
        "auth_new_password_label" to "New Password *",
        "auth_confirm_new_password_label" to "Confirm New Password *",
        "auth_btn_reset_password" to "Save New Password",
        "auth_back_to_login" to "Back to Sign In",
        "auth_proceed_to_reset" to "I Have a Reset Token",
        "auth_reset_success" to "Your password has been reset successfully! You can now sign in with your new password.",

        // Onboarding
        "onboarding_title" to "Farmer Onboarding Wizard",
        "onboarding_step1" to "Farmer Profile",
        "onboarding_step2" to "Farm Location",
        "onboarding_step3" to "Soil & Water Details",
        "onboarding_step4" to "First Crop Setup",
        "onboarding_next" to "Next",
        "onboarding_back" to "Back",
        "onboarding_finish" to "Finish Setup & Open Farm",

        // Dashboard & Home
        "home_greeting" to "Welcome, Kisan Mitra!",
        "home_weather_card_title" to "Live Weather Intelligence",
        "home_crops_summary" to "Active Crops in Cultivation",
        "home_quick_actions" to "Quick Farm Operations",
        "home_add_crop" to "Add Crop",
        "home_disease_scan" to "Disease Scanner",
        "home_soil_fertilizer" to "Soil & Nutrients",
        "home_irrigation" to "Irrigation",
        "home_finances" to "Income & Expense",
        "home_calendar" to "Task Calendar",
        "home_reports" to "PDF Dossier",
        "home_no_crops" to "No active crops registered yet.",
        "home_no_crops_action" to "Register your first crop now",

        // Weather
        "weather_title" to "Agronomic Weather Intelligence",
        "weather_temp" to "Temperature",
        "weather_humidity" to "Humidity",
        "weather_wind" to "Wind Speed",
        "weather_rainfall" to "Rainfall Probability",
        "weather_soil_temp" to "Soil Temp",
        "weather_soil_moisture" to "Soil Moisture",
        "weather_spraying_advisory" to "Spraying Window",
        "weather_irrigation_advisory" to "Irrigation Advice",
        "weather_advisory_good" to "Favorable conditions for foliar spray and intercultural operations.",
        "weather_advisory_caution" to "High wind/rain risk: avoid pesticide spraying today.",

        // Crops
        "crops_title" to "Crop Management",
        "crops_search_placeholder" to "Search crops by name, variety or plot...",
        "crops_filter_all" to "All",
        "crops_filter_growing" to "Growing",
        "crops_filter_harvested" to "Harvested",
        "crops_empty_title" to "No Crops Recorded",
        "crops_empty_subtitle" to "Start tracking your crop lifecycle, sowing dates, and harvest projections.",
        "crops_sowing_date" to "Sown On",
        "crops_expected_harvest" to "Harvest Date",
        "crops_area" to "Area",
        "crops_variety" to "Variety",
        "crops_growth_stage" to "Growth Stage",

        // Finance
        "finance_title" to "Farm Income & Expense Ledger",
        "finance_total_income" to "Total Revenue",
        "finance_total_expense" to "Total Expenses",
        "finance_net_profit" to "Net Farm Profit",
        "finance_add_transaction" to "Record Transaction",
        "finance_empty" to "No financial records found. Record your first sale or expense.",

        // AI Assistant
        "ai_title" to "AI Farm Agronomist",
        "ai_subtitle" to "Personalized guidance based on your soil, crops, and local weather",
        "ai_input_placeholder" to "Ask in English, मराठी, or हिंदी...",
        "ai_send" to "Ask",
        "ai_listening" to "Listening for your voice...",
        "ai_suggested_questions" to "Suggested Questions",

        // Settings
        "settings_title" to "Farm Profile & Settings",
        "settings_save" to "Save Settings",
        "settings_lang_label" to "Preferred Language / भाषा",
        "settings_farm_identity" to "Farm Identity",
        "settings_farm_name" to "Farm Name",
        "settings_farmer_name" to "Farmer Display Name",
        "settings_location_gps" to "Geographic Location & GPS",
        "settings_village" to "Village / Town",
        "settings_district" to "District",
        "settings_state" to "State",
        "settings_pincode" to "PIN Code",
        "settings_soil_type" to "Primary Soil Type",
        "settings_water_source" to "Irrigation Water Source"
    )

    private val marathiMap = mapOf(
        // Tabs & Navigation
        "tab_home" to "मुख्यपृष्ठ",
        "tab_crops" to "माझी पिके",
        "tab_map" to "शेत नकाशा",
        "tab_assistant" to "कृषी सहाय्यक",
        "tab_more" to "अधिक",

        // Auth
        "auth_app_title" to "माझे शेत (My Farm)",
        "auth_app_subtitle" to "सुरक्षित शेतकरी व्यवस्थापन आणि कृषी बुद्धिमत्ता प्रणाली",
        "auth_sign_in" to "शेतकरी प्रवेश",
        "auth_registration" to "शेतकरी नवीन नोंदणी",
        "auth_desc_login" to "आपल्या शेताची माहिती, हवामान अंदाज आणि कृषी सल्लागाराकडे जा.",
        "auth_desc_signup" to "आपले वैयक्तिक खाते तयार करा. शेताची माहिती भरण्यास मदत मिळेल.",
        "auth_name_label" to "शेतकऱ्याचे संपूर्ण नाव *",
        "auth_phone_label" to "मोबाईल फोन नंबर *",
        "auth_email_label" to "ईमेल पत्ता *",
        "auth_password_label" to "पासवर्ड (किमान ६ अक्षरे) *",
        "auth_confirm_password" to "पासवर्डची पुष्टी करा *",
        "auth_terms" to "मी सेवा अटी आणि कृषी डेटा गोपनीयता धोरण मान्य करतो",
        "auth_btn_login" to "शेतात प्रवेश करा",
        "auth_btn_register" to "नवीन शेतकरी खाते उघडा",
        "auth_switch_to_signup" to "नवीन शेतकरी? मोफत खाते उघडा",
        "auth_switch_to_login" to "आधीच खाते आहे? लॉगिन करा",
        "auth_guest_mode" to "ऑफलाइन / डेमो मोडमध्ये पहा",
        "auth_language_select" to "भाषा निवडा / Select Language",
        "auth_forgot_password" to "पासवर्ड विसरलात?",
        "auth_forgot_title" to "पासवर्ड रीसेट करा",
        "auth_forgot_desc" to "तुमचा नोंदणीकृत ईमेल पत्ता प्रविष्ट करा. आम्ही पासवर्ड रीसेट करण्यासाठी कोड पाठवू.",
        "auth_btn_send_reset" to "रीसेट लिंक / कोड पाठवा",
        "auth_reset_title" to "नवीन पासवर्ड सेट करा",
        "auth_reset_desc" to "तुमचा रीसेट कोड आणि नवीन पासवर्ड प्रविष्ट करा.",
        "auth_token_label" to "रीसेट कोड / टोकन *",
        "auth_new_password_label" to "नवीन पासवर्ड *",
        "auth_confirm_new_password_label" to "नवीन पासवर्डची पुष्टी करा *",
        "auth_btn_reset_password" to "नवीन पासवर्ड जतन करा",
        "auth_back_to_login" to "लॉगिनवर परत जा",
        "auth_proceed_to_reset" to "माझ्याकडे रीसेट कोड आहे",
        "auth_reset_success" to "तुमचा पासवर्ड यशस्वीरित्या रीसेट झाला आहे! तुम्ही आता नवीन पासवर्डने लॉगिन करू शकता.",

        // Onboarding
        "onboarding_title" to "शेतकरी स्वागत व माहिती नोंदणी",
        "onboarding_step1" to "शेतकरी माहिती",
        "onboarding_step2" to "शेताचे स्थान (GPS)",
        "onboarding_step3" to "माती व पाणी तपशील",
        "onboarding_step4" to "पहिले पीक नोंदणी",
        "onboarding_next" to "पुढे चला →",
        "onboarding_back" to "← मागे",
        "onboarding_finish" to "नोंदणी पूर्ण करा व शेत उघडा",

        // Dashboard & Home
        "home_greeting" to "नमस्कार शेतकरी मित्र!",
        "home_weather_card_title" to "थेट हवामान माहिती व अंदाज",
        "home_crops_summary" to "शेतातील सध्याची पिके",
        "home_quick_actions" to "जलद कृती व नोंदी",
        "home_add_crop" to "पीक जोडा",
        "home_disease_scan" to "रोग स्कॅनर",
        "home_soil_fertilizer" to "माती व खते",
        "home_irrigation" to "सिंचन व्यवस्था",
        "home_finances" to "जमा-खर्च हिशोब",
        "home_calendar" to "शेती दिनदर्शिका",
        "home_reports" to "पीडीएफ अहवाल",
        "home_no_crops" to "अद्याप कोणतीही पिके नोंदवलेली नाहीत.",
        "home_no_crops_action" to "आपले पहिले पीक आताच नोंदवा",

        // Weather
        "weather_title" to "शेती हवामान व सल्लागार",
        "weather_temp" to "तापमान",
        "weather_humidity" to "हवेतील आर्द्रता",
        "weather_wind" to "वाऱ्याचा वेग",
        "weather_rainfall" to "पावसाची शक्यता",
        "weather_soil_temp" to "मातीचे तापमान",
        "weather_soil_moisture" to "मातीतील ओलावा",
        "weather_spraying_advisory" to "फवारणी सल्ला",
        "weather_irrigation_advisory" to "सिंचन सल्ला",
        "weather_advisory_good" to "आज हवामान अनुकूल आहे. फवारणी आणि मशागत करता येईल.",
        "weather_advisory_caution" to "वाऱ्याचा वेग किंवा पावसाची शक्यता जास्त आहे; आज फवारणी टाळा.",

        // Crops
        "crops_title" to "पीक व्यवस्थापन",
        "crops_search_placeholder" to "पीक नाव, वाण किंवा शेतानुसार शोधा...",
        "crops_filter_all" to "सर्व",
        "crops_filter_growing" to "उभी पिके",
        "crops_filter_harvested" to "काढणी झालेली",
        "crops_empty_title" to "कोणतेही पीक सापडले नाही",
        "crops_empty_subtitle" to "पेरणी, फवारणी आणि उत्पादनाचा हिशोब ठेवण्यासाठी पीक नोंदवा.",
        "crops_sowing_date" to "पेरणी दिनांक",
        "crops_expected_harvest" to "अपेक्षित काढणी",
        "crops_area" to "क्षेत्र",
        "crops_variety" to "वाण",
        "crops_growth_stage" to "वाढीची अवस्था",

        // Finance
        "finance_title" to "शेती जमा-खर्च वही (हिशोब)",
        "finance_total_income" to "एकूण उत्पन्न / विक्री",
        "finance_total_expense" to "एकूण शेती खर्च",
        "finance_net_profit" to "निव्वळ शेती नफा",
        "finance_add_transaction" to "नवीन नोंद करा",
        "finance_empty" to "अद्याप कोणतीही नोंद नाही. खते, बियाणे किंवा उत्पन्नाची नोंद करा.",

        // AI Assistant
        "ai_title" to "कृषी डिजिटल सहाय्यक",
        "ai_subtitle" to "तुमची माती, पिके आणि स्थानिक हवामानावर आधारित अचूक मार्गदर्शन",
        "ai_input_placeholder" to "मराठी, हिंदी किंवा इंग्रजीत प्रश्न विचारा...",
        "ai_send" to "विचारा",
        "ai_listening" to "आवाज ऐकत आहे...",
        "ai_suggested_questions" to "सुचवलेले प्रश्न",

        // Settings
        "settings_title" to "शेत तपशील व सेटिंग्ज",
        "settings_save" to "माहिती जतन करा",
        "settings_lang_label" to "पसंतीची भाषा / Language",
        "settings_farm_identity" to "शेताची ओळख",
        "settings_farm_name" to "शेताचे नाव",
        "settings_farmer_name" to "शेतकऱ्याचे नाव",
        "settings_location_gps" to "भौगोलिक स्थान व जीपीएस",
        "settings_village" to "गाव",
        "settings_district" to "जिल्हा",
        "settings_state" to "राज्य",
        "settings_pincode" to "पिन कोड",
        "settings_soil_type" to "मुख्य मातीचा प्रकार",
        "settings_water_source" to "पाण्याचा मुख्य स्त्रोत"
    )

    private val hindiMap = mapOf(
        // Tabs & Navigation
        "tab_home" to "होम",
        "tab_crops" to "मेरी फसलें",
        "tab_map" to "खेत का नक्शा",
        "tab_assistant" to "कृषि सहायक",
        "tab_more" to "अधिक",

        // Auth
        "auth_app_title" to "मेरा खेत (My Farm)",
        "auth_app_subtitle" to "सुरक्षित बहु-किरायेदार फार्म प्रबंधन और कृषि एआई",
        "auth_sign_in" to "किसान लॉगिन",
        "auth_registration" to "किसान नया पंजीकरण",
        "auth_desc_login" to "अपने निजी खेत रिकॉर्ड, मौसम और एआई सलाहकार तक पहुंचें।",
        "auth_desc_signup" to "अपना खाता बनाएं। खेत स्थापित करने में आपका मार्गदर्शन किया जाएगा।",
        "auth_name_label" to "किसान का पूरा नाम *",
        "auth_phone_label" to "मोबाइल फोन नंबर *",
        "auth_email_label" to "ईमेल पता *",
        "auth_password_label" to "पासवर्ड (न्यूनतम 6 अक्षर) *",
        "auth_confirm_password" to "पासवर्ड की पुष्टि करें *",
        "auth_terms" to "मैं सेवा की शर्तों और कृषि डेटा गोपनीयता नीति से सहमत हूँ",
        "auth_btn_login" to "खेत में प्रवेश करें",
        "auth_btn_register" to "नया किसान खाता बनाएं",
        "auth_switch_to_signup" to "नए किसान? निःशुल्क खाता बनाएं",
        "auth_switch_to_login" to "पहले से खाता है? लॉगिन करें",
        "auth_guest_mode" to "ऑफ़लाइन / डेमो मोड में देखें",
        "auth_language_select" to "भाषा चुनें / Select Language",
        "auth_forgot_password" to "पासवर्ड भूल गए?",
        "auth_forgot_title" to "पासवर्ड रीसेट करें",
        "auth_forgot_desc" to "अपना पंजीकृत ईमेल दर्ज करें। हम पासवर्ड रीसेट करने के लिए कोड भेजेंगे।",
        "auth_btn_send_reset" to "रीसेट लिंक / कोड भेजें",
        "auth_reset_title" to "नया पासवर्ड सेट करें",
        "auth_reset_desc" to "अपना रीसेट कोड और नया पासवर्ड दर्ज करें।",
        "auth_token_label" to "रीसेट कोड / टोकन *",
        "auth_new_password_label" to "नया पासवर्ड *",
        "auth_confirm_new_password_label" to "नए पासवर्ड की पुष्टि करें *",
        "auth_btn_reset_password" to "नया पासवर्ड सहेजें",
        "auth_back_to_login" to "लॉगिन पर वापस जाएं",
        "auth_proceed_to_reset" to "मेरे पास रीसेट कोड है",
        "auth_reset_success" to "आपका पासवर्ड सफलतापूर्वक रीसेट कर दिया गया है! अब आप नए पासवर्ड के साथ लॉगिन कर सकते हैं।",

        // Onboarding
        "onboarding_title" to "किसान ऑनबोर्डिंग और विवरण",
        "onboarding_step1" to "किसान प्रोफाइल",
        "onboarding_step2" to "खेत का स्थान (GPS)",
        "onboarding_step3" to "मिट्टी और पानी का विवरण",
        "onboarding_step4" to "पहली फसल पंजीकरण",
        "onboarding_next" to "आगे बढ़ें →",
        "onboarding_back" to "← वापस",
        "onboarding_finish" to "सेटअप पूरा करें और खेत खोलें",

        // Dashboard & Home
        "home_greeting" to "नमस्ते किसान मित्र!",
        "home_weather_card_title" to "सटीक मौसम पूर्वानुमान",
        "home_crops_summary" to "खेत में सक्रिय फसलें",
        "home_quick_actions" to "त्वरित कृषि कार्य",
        "home_add_crop" to "फसल जोड़ें",
        "home_disease_scan" to "रोग स्कैनर",
        "home_soil_fertilizer" to "मिट्टी और उर्वरक",
        "home_irrigation" to "सिंचाई प्रबंधन",
        "home_finances" to "आय और व्यय खाता",
        "home_calendar" to "कृषि कैलेंडर",
        "home_reports" to "पीडीएफ रिपोर्ट",
        "home_no_crops" to "अभी तक कोई फसल दर्ज नहीं की गई है।",
        "home_no_crops_action" to "अपनी पहली फसल अभी पंजीकृत करें",

        // Weather
        "weather_title" to "कृषि मौसम बुद्धिमत्ता",
        "weather_temp" to "तापमान",
        "weather_humidity" to "नमी (आर्द्रता)",
        "weather_wind" to "हवा की गति",
        "weather_rainfall" to "बारिश की संभावना",
        "weather_soil_temp" to "मिट्टी का तापमान",
        "weather_soil_moisture" to "मिट्टी की नमी",
        "weather_spraying_advisory" to "छिड़काव सलाह",
        "weather_irrigation_advisory" to "सिंचाई सलाह",
        "weather_advisory_good" to "आज मौसम अनुकूल है। छिड़काव और जुताई का कार्य कर सकते हैं।",
        "weather_advisory_caution" to "हवा की गति या बारिश की संभावना अधिक है; आज कीटनाशक छिड़काव से बचें।",

        // Crops
        "crops_title" to "फसल प्रबंधन",
        "crops_search_placeholder" to "फसल के नाम, किस्म या खेत से खोजें...",
        "crops_filter_all" to "सभी",
        "crops_filter_growing" to "उगती फसलें",
        "crops_filter_harvested" to "कटाई हो चुकी",
        "crops_empty_title" to "कोई फसल नहीं मिली",
        "crops_empty_subtitle" to "बुआई, कटाई और उत्पादन रिकॉर्ड रखने के लिए फसल दर्ज करें।",
        "crops_sowing_date" to "बुआई की तारीख",
        "crops_expected_harvest" to "कटाई की तारीख",
        "crops_area" to "क्षेत्रफल",
        "crops_variety" to "किस्म",
        "crops_growth_stage" to "वृद्धि अवस्था",

        // Finance
        "finance_title" to "कृषि आय-व्यय बहीखाता",
        "finance_total_income" to "कुल आमदनी",
        "finance_total_expense" to "कुल कृषि खर्च",
        "finance_net_profit" to "शुद्ध कृषि लाभ",
        "finance_add_transaction" to "नया लेनदेन जोड़ें",
        "finance_empty" to "अभी तक कोई लेनदेन नहीं है। बीज, खाद या बिक्री का विवरण जोड़ें।",

        // AI Assistant
        "ai_title" to "कृषि एआई सलाहकार",
        "ai_subtitle" to "आपकी मिट्टी, फसलों और स्थानीय मौसम पर आधारित सटीक मार्गदर्शन",
        "ai_input_placeholder" to "हिंदी, मराठी या अंग्रेजी में पूछें...",
        "ai_send" to "पूछें",
        "ai_listening" to "आवाज सुन रहे हैं...",
        "ai_suggested_questions" to "सुझाए गए प्रश्न",

        // Settings
        "settings_title" to "खेत प्रोफाइल और सेटिंग्स",
        "settings_save" to "सेव करें",
        "settings_lang_label" to "पसंदीदा भाषा / Language",
        "settings_farm_identity" to "खेत की पहचान",
        "settings_farm_name" to "खेत का नाम",
        "settings_farmer_name" to "किसान का नाम",
        "settings_location_gps" to "भौगोलिक स्थिति व जीपीएस",
        "settings_village" to "गाँव",
        "settings_district" to "जिला",
        "settings_state" to "राज्य",
        "settings_pincode" to "पिन कोड",
        "settings_soil_type" to "मुख्य मिट्टी का प्रकार",
        "settings_water_source" to "सिंचाई का पानी स्रोत"
    )
}
