package com.example.ui.screens.crops

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CropRecord
import com.example.ui.screens.home.ActiveCropCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.viewmodel.FarmViewModel

import com.example.ui.i18n.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CropsScreen(
    viewModel: FarmViewModel,
    onOpenDrawer: (() -> Unit)? = null,
    onNavigateToCropDetail: (String) -> Unit,
    onNavigateToAddCrop: () -> Unit
) {
    val allCrops by viewModel.allCrops.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    var selectedFilter by remember { mutableStateOf("Active") } // Active, All, Harvested, Kharif, Rabi
    var searchQuery by remember { mutableStateOf("") }

    val filteredCrops = remember(allCrops, selectedFilter, searchQuery) {
        val byFilter = when (selectedFilter) {
            "Active" -> allCrops.filter { !it.isArchived && it.status != "Harvested" }
            "Harvested" -> allCrops.filter { it.status == "Harvested" || it.isArchived }
            "Kharif" -> allCrops.filter { it.season == "Kharif" }
            "Rabi" -> allCrops.filter { it.season == "Rabi" }
            else -> allCrops
        }
        if (searchQuery.isBlank()) {
            byFilter
        } else {
            byFilter.filter { crop ->
                AppStrings.matchesCropSearch(crop.cropName, searchQuery) ||
                        crop.variety.contains(searchQuery, ignoreCase = true) ||
                        crop.fieldName.contains(searchQuery, ignoreCase = true) ||
                        crop.notes.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (onOpenDrawer != null) {
                        IconButton(
                            onClick = { onOpenDrawer() },
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Navigation Drawer"
                            )
                        }
                    }
                },
                title = {
                    Column {
                        Text(
                            text = "Crop Management",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${allCrops.size} total crops in farm database",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddCrop,
                containerColor = ForestGreenPrimary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_crop_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Crop")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar with Multilingual Alias support
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        when (currentLanguage) {
                            "Marathi" -> "पीक, वाण किंवा शेतानुसार शोधा (उदा. गहू, कापूस...)"
                            "Hindi" -> "फसल, किस्म या खेत से खोजें (उदा. गेहूं, सोयाबीन...)"
                            else -> "Search crops (e.g. Wheat, Soybean, कापूस, गेहूँ)..."
                        }
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("crop_search_input"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            // Filter Chips
            LazyRow(
                modifier = Modifier.padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf(
                    "Active" to when (currentLanguage) {
                        "Marathi" -> "उभी पिके"
                        "Hindi" -> "सक्रिय फसलें"
                        else -> "Active"
                    },
                    "All" to when (currentLanguage) {
                        "Marathi" -> "सर्व"
                        "Hindi" -> "सभी"
                        else -> "All"
                    },
                    "Harvested" to when (currentLanguage) {
                        "Marathi" -> "काढणी झालेली"
                        "Hindi" -> "कटाई हो चुकी"
                        else -> "Harvested"
                    },
                    "Kharif" to when (currentLanguage) {
                        "Marathi" -> "खरीप"
                        "Hindi" -> "खरीफ"
                        else -> "Kharif"
                    },
                    "Rabi" to when (currentLanguage) {
                        "Marathi" -> "रब्बी"
                        "Hindi" -> "रबी"
                        else -> "Rabi"
                    }
                )
                items(filters) { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label) },
                        modifier = Modifier.testTag("filter_chip_$key")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredCrops.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No crops match '$selectedFilter'",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap the + button to register a new crop planting record.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onNavigateToAddCrop) {
                            Text("Plant a New Crop")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredCrops) { crop ->
                        ActiveCropCard(
                            crop = crop,
                            onClick = { onNavigateToCropDetail(crop.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}
