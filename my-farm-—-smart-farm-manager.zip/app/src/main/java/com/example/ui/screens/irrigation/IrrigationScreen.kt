package com.example.ui.screens.irrigation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.IrrigationLog
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.WaterBlue
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IrrigationScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val logs by viewModel.irrigationLogs.collectAsState()
    val fields by viewModel.allFields.collectAsState()
    val activeCrops by viewModel.activeCrops.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Irrigation & Water Management", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("irrigation_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = WaterBlue,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_irrigation_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log Irrigation")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = WaterBlue.copy(alpha = 0.12f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row {
                            Icon(Icons.Default.Opacity, contentDescription = null, tint = WaterBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Water Usage Summary", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        val totalWater = logs.sumOf { it.waterQuantityLiters }
                        val totalHours = logs.sumOf { it.durationHours }
                        Text("• Total Water Delivered: ${String.format("%,.0f", totalWater)} Liters")
                        Text("• Total Pump Run Time: $totalHours Hours")
                        Text("• Active System: Borewell Solar Drip with automated line filtration")
                    }
                }
            }

            item {
                Text("Irrigation History (${logs.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }

            items(logs) { log ->
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${log.fieldName} • ${log.method}", fontWeight = FontWeight.Bold)
                            Text("${log.durationHours} hrs", color = WaterBlue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Volume: ${String.format("%,.0f", log.waterQuantityLiters)} L • Pump Cost: ₹${log.electricityFuelCost}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (log.soilMoistureBeforePct != null && log.soilMoistureAfterPct != null) {
                            Text(
                                text = "Soil Moisture: ${log.soilMoistureBeforePct}% → ${log.soilMoistureAfterPct}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        if (log.notes.isNotBlank()) {
                            Text(log.notes, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }

    if (showAddDialog) {
        var fieldName by remember { mutableStateOf(fields.firstOrNull()?.name ?: "Plot A (North Valley)") }
        var fieldId by remember { mutableStateOf(fields.firstOrNull()?.id ?: "field_1") }
        var method by remember { mutableStateOf("Drip") }
        var duration by remember { mutableStateOf("2.5") }
        var volume by remember { mutableStateOf("15000") }
        var cost by remember { mutableStateOf("150") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Log Irrigation Event", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = fieldName, onValueChange = { fieldName = it }, label = { Text("Field / Plot") })
                    OutlinedTextField(value = method, onValueChange = { method = it }, label = { Text("Method (Drip / Sprinkler / Flood)") })
                    OutlinedTextField(value = duration, onValueChange = { duration = it }, label = { Text("Duration (Hours)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = volume, onValueChange = { volume = it }, label = { Text("Water Volume (Liters)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Electricity / Fuel Cost (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes / Soil observation") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addIrrigationLog(
                            IrrigationLog(
                                fieldId = fieldId,
                                fieldName = fieldName,
                                method = method,
                                durationHours = duration.toDoubleOrNull() ?: 2.0,
                                waterQuantityLiters = volume.toDoubleOrNull() ?: 10000.0,
                                pumpRunHours = duration.toDoubleOrNull() ?: 2.0,
                                electricityFuelCost = cost.toDoubleOrNull() ?: 100.0,
                                notes = notes
                            )
                        )
                        showAddDialog = false
                    }
                ) {
                    Text("Save Log")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
