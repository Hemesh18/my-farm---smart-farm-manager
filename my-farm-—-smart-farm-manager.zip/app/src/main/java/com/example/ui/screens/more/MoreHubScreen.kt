package com.example.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreHubScreen(
    viewModel: FarmViewModel,
    onNavigateToHistory: () -> Unit,
    onNavigateToScanner: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    onNavigateToFinances: () -> Unit,
    onNavigateToIrrigation: () -> Unit,
    onNavigateToSoil: () -> Unit,
    onNavigateToJournal: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToSubscription: () -> Unit = {},
    onNavigateToAdmin: () -> Unit = {},
    onLogout: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val farmProfile by viewModel.farmProfile.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("More Modules & Tools", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Farmer Account Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary.copy(alpha = 0.1f))
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(ForestGreenPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentUser?.fullName ?: farmProfile?.farmerName ?: "Registered Farmer",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "${farmProfile?.farmName ?: "My Farm"} • $userEmail",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Agricultural Intelligence & Records", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            item {
                MoreMenuTile(
                    title = "Permanent Farm History",
                    subtitle = "Browse 2024-2026 crop seasons, compare years, and global search",
                    icon = Icons.Default.HistoryEdu,
                    tint = ForestGreenPrimary,
                    onClick = onNavigateToHistory
                )
            }

            item {
                MoreMenuTile(
                    title = "Crop Disease & Health Scanner",
                    subtitle = "AI image & symptom pathology analysis with IPM guidance",
                    icon = Icons.Default.CenterFocusStrong,
                    tint = HealthWarningRed,
                    onClick = onNavigateToScanner
                )
            }

            item {
                MoreMenuTile(
                    title = "Farm Calendar & Task Manager",
                    subtitle = "Plan sowing, weeding, spraying, and harvest operations",
                    icon = Icons.Default.CalendarMonth,
                    tint = LeafGreenSecondary,
                    onClick = onNavigateToCalendar
                )
            }

            item {
                MoreMenuTile(
                    title = "Farm Finances, Income & Profit",
                    subtitle = "Income ledger, expense breakdown, and net profit in ₹",
                    icon = Icons.Default.CurrencyRupee,
                    tint = HarvestAmberTertiary,
                    onClick = onNavigateToFinances
                )
            }

            item {
                MoreMenuTile(
                    title = "Irrigation & Water Management",
                    subtitle = "Drip/sprinkler logs, water volume delivered, and pump hours",
                    icon = Icons.Default.Opacity,
                    tint = WaterBlue,
                    onClick = onNavigateToIrrigation
                )
            }

            item {
                MoreMenuTile(
                    title = "Soil Health & Nutrient Management",
                    subtitle = "Laboratory soil test reports (pH, NPK) and fertilizer logs",
                    icon = Icons.Default.Science,
                    tint = SoilBrown,
                    onClick = onNavigateToSoil
                )
            }

            item {
                MoreMenuTile(
                    title = "Farm Activity Diary",
                    subtitle = "Chronological farmer observations and field photos",
                    icon = Icons.Default.Book,
                    tint = ForestGreenPrimary,
                    onClick = onNavigateToJournal
                )
            }

            item {
                MoreMenuTile(
                    title = "Reports, Analytics & CSV Export",
                    subtitle = "Acreage distribution, multi-year yield, and spreadsheet export",
                    icon = Icons.Default.BarChart,
                    tint = LeafGreenSecondary,
                    onClick = onNavigateToAnalytics
                )
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text("System & Configuration", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            item {
                MoreMenuTile(
                    title = "Farm Profile & Settings",
                    subtitle = "GPS coordinates, area units, soil type, and languages",
                    icon = Icons.Default.Settings,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    onClick = onNavigateToSettings
                )
            }

            item {
                MoreMenuTile(
                    title = "SaaS Subscription & Pricing Plans",
                    subtitle = "Manage plan, unlock multi-plot satellite, AI, and exports",
                    icon = Icons.Default.WorkspacePremium,
                    tint = HarvestAmberTertiary,
                    onClick = onNavigateToSubscription
                )
            }

            if (currentUser?.role == "ADMIN") {
                item {
                    MoreMenuTile(
                        title = "Platform Super Admin & Audit",
                        subtitle = "Tenant management, system telemetry & security audit trail",
                        icon = Icons.Default.AdminPanelSettings,
                        tint = ForestGreenPrimary,
                        onClick = onNavigateToAdmin
                    )
                }
            }

            item {
                MoreMenuTile(
                    title = "Sign Out",
                    subtitle = "Safely exit current farmer session",
                    icon = Icons.Default.Logout,
                    tint = HealthWarningRed,
                    onClick = {
                        viewModel.logout()
                        onLogout()
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}

@Composable
private fun MoreMenuTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("more_tile_${title.lowercase().replace(" ", "_").take(20)}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        }
    }
}
