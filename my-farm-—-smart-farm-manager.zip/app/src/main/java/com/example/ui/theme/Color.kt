package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Agricultural Palette
val ForestGreenPrimary = Color(0xFF1B4D3E)
val ForestGreenOnPrimary = Color(0xFFFFFFFF)
val ForestGreenPrimaryContainer = Color(0xFFA5F0CD)
val ForestGreenOnPrimaryContainer = Color(0xFF002116)

val LeafGreenSecondary = Color(0xFF386A20)
val LeafGreenOnSecondary = Color(0xFFFFFFFF)
val LeafGreenSecondaryContainer = Color(0xFFB8F397)
val LeafGreenOnSecondaryContainer = Color(0xFF042100)

val HarvestAmberTertiary = Color(0xFF7D5700)
val HarvestAmberOnTertiary = Color(0xFFFFFFFF)
val HarvestAmberTertiaryContainer = Color(0xFFFFDEA3)
val HarvestAmberOnTertiaryContainer = Color(0xFF261900)

val NeutralBackgroundLight = Color(0xFFF7F9F6)
val NeutralOnBackgroundLight = Color(0xFF191C1A)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE2E7E1)
val OnSurfaceLight = Color(0xFF191C1A)
val OnSurfaceVariantLight = Color(0xFF424940)
val OutlineLight = Color(0xFF72796F)

// Dark Theme Agricultural Palette
val ForestGreenDarkPrimary = Color(0xFF8AD3B2)
val ForestGreenDarkOnPrimary = Color(0xFF003825)
val ForestGreenDarkPrimaryContainer = Color(0xFF005137)
val ForestGreenDarkOnPrimaryContainer = Color(0xFFA5F0CD)

val LeafGreenDarkSecondary = Color(0xFF9DD67D)
val LeafGreenDarkOnSecondary = Color(0xFF133800)
val LeafGreenDarkSecondaryContainer = Color(0xFF235109)
val LeafGreenDarkOnSecondaryContainer = Color(0xFFB8F397)

val HarvestAmberDarkTertiary = Color(0xFFFABD00)
val HarvestAmberDarkOnTertiary = Color(0xFF422C00)
val HarvestAmberDarkTertiaryContainer = Color(0xFF5F4100)
val HarvestAmberDarkOnTertiaryContainer = Color(0xFFFFDEA3)

val DarkBackground = Color(0xFF101512)
val DarkOnBackground = Color(0xFFE1E4DE)
val DarkSurface = Color(0xFF151C17)
val DarkSurfaceVariant = Color(0xFF222B24)
val DarkOnSurface = Color(0xFFE1E4DE)
val DarkOnSurfaceVariant = Color(0xFFC2C8BF)
val DarkOutline = Color(0xFF8C9388)

// Status & Indicator Colors
val HealthGoodGreen = Color(0xFF2E7D32)
val HealthModerateYellow = Color(0xFFF9A825)
val HealthWarningRed = Color(0xFFC62828)
val WaterBlue = Color(0xFF1565C0)
val SoilBrown = Color(0xFF6D4C41)
