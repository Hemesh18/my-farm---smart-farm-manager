package com.example.ui.screens.map

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import com.example.data.model.FarmBoundaryRecord
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.viewmodel.FarmViewModel
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmMapScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToCropDetail: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val farmProfile by viewModel.currentFarmProfile.collectAsState()
    val fields by viewModel.allFields.collectAsState()
    val activeCrops by viewModel.activeCrops.collectAsState()
    val savedBoundaryRecord by viewModel.currentFarmBoundary.collectAsState()

    // Location & Initial Camera Target
    val initialLat = farmProfile?.latitude ?: 20.5841
    val initialLng = farmProfile?.longitude ?: 77.0620
    val initialLatLng = remember(initialLat, initialLng) { LatLng(initialLat, initialLng) }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(initialLatLng, 16.5f)
    }

    // Map Settings
    var mapType by remember { mutableStateOf(MapType.SATELLITE) }
    var isMapLoaded by remember { mutableStateOf(false) }

    // Drawing Boundary State
    var isDrawingBoundary by remember { mutableStateOf(false) }
    var boundaryPoints by remember { mutableStateOf<List<LatLng>>(emptyList()) }

    // Parse saved boundary from DB if available
    val savedBoundaryPoints = remember(savedBoundaryRecord) {
        parseLatLngPoints(savedBoundaryRecord?.boundaryPointsJson ?: "")
    }

    // Search query state
    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    // Location Permission
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasLocationPermission = isGranted
        if (isGranted) {
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) {
                        val current = LatLng(loc.latitude, loc.longitude)
                        coroutineScope.launch {
                            cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(current, 17f))
                        }
                        Toast.makeText(context, "Centered on current GPS position.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Location fix unavailable. Move map manually.", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (_: SecurityException) {}
        } else {
            Toast.makeText(context, "Location permission denied. Map manually.", Toast.LENGTH_SHORT).show()
        }
    }

    // Area calculations
    val activePoints = if (isDrawingBoundary) boundaryPoints else savedBoundaryPoints
    val areaSqMeters = remember(activePoints) { calculateGeodesicAreaMeters(activePoints) }
    val areaAcres = areaSqMeters / 4046.8564224
    val areaHectares = areaSqMeters / 10000.0

    // Check API Key
    val apiKey = try { BuildConfig.MAPS_API_KEY } catch (_: Throwable) { "" }
    val isKeyMissing = apiKey.isBlank() || apiKey.contains("YOUR_")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = farmProfile?.farmName ?: "Farm Map & Satellite",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "${farmProfile?.village ?: "Barshitakli"}, ${farmProfile?.district ?: "Akola"} • ${String.format("%.4f", cameraPositionState.position.target.latitude)}°N, ${String.format("%.4f", cameraPositionState.position.target.longitude)}°E",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("map_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (!hasLocationPermission) {
                                locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                            } else {
                                try {
                                    fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                                        if (loc != null) {
                                            val current = LatLng(loc.latitude, loc.longitude)
                                            coroutineScope.launch {
                                                cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(current, 17f))
                                            }
                                        } else {
                                            Toast.makeText(context, "Location fix unavailable.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } catch (_: SecurityException) {}
                            }
                        },
                        modifier = Modifier.testTag("use_my_location_button")
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = "Use My Location", tint = ForestGreenPrimary)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // API Key Configuration Warning Banner if needed
            if (isKeyMissing) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Google Maps API Key not set. Add MAPS_API_KEY=AIzaSy... in .env secrets to enable high-resolution satellite imagery.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // Location Search Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search village, district, or land mark...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("location_search_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp)
                )

                Button(
                    onClick = {
                        if (searchQuery.isNotBlank()) {
                            isSearching = true
                            performGeocodingSearch(
                                context = context,
                                query = searchQuery,
                                onResult = { targetLatLng, addressLabel ->
                                    isSearching = false
                                    coroutineScope.launch {
                                        cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(targetLatLng, 16.5f))
                                    }
                                    Toast.makeText(context, "Moved map to $addressLabel", Toast.LENGTH_SHORT).show()
                                },
                                onError = { errorMsg ->
                                    isSearching = false
                                    Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    },
                    enabled = !isSearching && searchQuery.isNotBlank(),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("location_search_button")
                ) {
                    if (isSearching) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Text("Search")
                    }
                }
            }

            // Layer Toggle Chips (Satellite, Hybrid, Map)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = mapType == MapType.SATELLITE,
                    onClick = { mapType = MapType.SATELLITE },
                    label = { Text("Satellite") },
                    leadingIcon = { Icon(Icons.Default.Satellite, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("satellite_mode_chip")
                )
                FilterChip(
                    selected = mapType == MapType.HYBRID,
                    onClick = { mapType = MapType.HYBRID },
                    label = { Text("Hybrid (Labels)") },
                    leadingIcon = { Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("hybrid_mode_chip")
                )
                FilterChip(
                    selected = mapType == MapType.NORMAL,
                    onClick = { mapType = MapType.NORMAL },
                    label = { Text("Terrain / Road") },
                    leadingIcon = { Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("normal_mode_chip")
                )
            }

            // Interactive Google Maps Canvas Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                GoogleMap(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("google_map_container"),
                    cameraPositionState = cameraPositionState,
                    properties = MapProperties(
                        mapType = mapType,
                        isMyLocationEnabled = hasLocationPermission
                    ),
                    uiSettings = MapUiSettings(
                        zoomControlsEnabled = true,
                        compassEnabled = true,
                        myLocationButtonEnabled = false,
                        mapToolbarEnabled = true
                    ),
                    onMapLoaded = { isMapLoaded = true },
                    onMapClick = { clickedLatLng ->
                        if (isDrawingBoundary) {
                            boundaryPoints = boundaryPoints + clickedLatLng
                        }
                    }
                ) {
                    // 1. Polygon for current drawing boundary
                    if (boundaryPoints.size >= 2) {
                        Polygon(
                            points = boundaryPoints,
                            strokeColor = Color(0xFF00FFCC),
                            fillColor = Color(0x3300FFCC),
                            strokeWidth = 6f
                        )
                    }

                    // 2. Vertex markers for current drawing points
                    if (isDrawingBoundary) {
                        boundaryPoints.forEachIndexed { idx, pt ->
                            Marker(
                                state = MarkerState(position = pt),
                                title = "Point ${idx + 1}",
                                snippet = "Tap to remove vertex",
                                onClick = {
                                    boundaryPoints = boundaryPoints.toMutableList().apply { removeAt(idx) }
                                    true
                                }
                            )
                        }
                    }

                    // 3. Saved farm boundary polygon (if not drawing)
                    if (!isDrawingBoundary && savedBoundaryPoints.size >= 3) {
                        Polygon(
                            points = savedBoundaryPoints,
                            strokeColor = Color(0xFFFFC107),
                            fillColor = Color(0x38FFC107),
                            strokeWidth = 5f
                        )
                        Marker(
                            state = MarkerState(position = calculateCentroid(savedBoundaryPoints)),
                            title = farmProfile?.farmName ?: "Saved Farm Boundary",
                            snippet = "Area: ${String.format("%.2f", savedBoundaryRecord?.areaAcres ?: 0.0)} Acres"
                        )
                    }

                    // 4. Center Marker for farm profile coordinate
                    if (!isDrawingBoundary && savedBoundaryPoints.isEmpty() && farmProfile?.latitude != null && farmProfile?.longitude != null) {
                        Marker(
                            state = MarkerState(position = LatLng(farmProfile!!.latitude!!, farmProfile!!.longitude!!)),
                            title = farmProfile?.farmName ?: "Farm Location",
                            snippet = "Tap 'Draw Boundary' to trace field"
                        )
                    }
                }

                // Loading overlay while map is initializing
                if (!isMapLoaded) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.35f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color.White)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Initializing Satellite Map...", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                // Top Instruction Bar on Map
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isDrawingBoundary) Icons.Default.EditLocation else Icons.Default.Info,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isDrawingBoundary) {
                                "Tap satellite map to place boundary points around field."
                            } else if (savedBoundaryPoints.size >= 3) {
                                "Saved Farm Boundary • ${String.format("%.2f", savedBoundaryRecord?.areaAcres ?: 0.0)} Acres"
                            } else {
                                "Move map to field & tap 'Draw Boundary' to measure land."
                            },
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                // Area Display Badge (Floating at bottom of map)
                if (activePoints.size >= 3) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        tonalElevation = 6.dp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .testTag("area_badge")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = "Enclosed Area",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "${String.format("%.2f", areaAcres)} Acres",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "(${String.format("%.2f", areaHectares)} Hectares)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }

            // Bottom Boundary Control Panel
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!isDrawingBoundary) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    isDrawingBoundary = true
                                    boundaryPoints = emptyList()
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("draw_boundary_button")
                            ) {
                                Icon(Icons.Default.Polyline, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Draw Boundary")
                            }

                            if (savedBoundaryPoints.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        isDrawingBoundary = true
                                        boundaryPoints = savedBoundaryPoints
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("edit_boundary_button")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit")
                                }
                            }
                        }
                    } else {
                        // Action Bar during drawing
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Undo Point
                            OutlinedButton(
                                onClick = {
                                    if (boundaryPoints.isNotEmpty()) {
                                        boundaryPoints = boundaryPoints.dropLast(1)
                                    }
                                },
                                enabled = boundaryPoints.isNotEmpty(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("undo_point_button")
                            ) {
                                Icon(Icons.Default.Undo, contentDescription = "Undo Point")
                            }

                            // Clear Boundary
                            OutlinedButton(
                                onClick = { boundaryPoints = emptyList() },
                                enabled = boundaryPoints.isNotEmpty(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("clear_boundary_button")
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Boundary")
                            }

                            // Cancel
                            TextButton(
                                onClick = {
                                    isDrawingBoundary = false
                                    boundaryPoints = emptyList()
                                },
                                modifier = Modifier.testTag("cancel_boundary_button")
                            ) {
                                Text("Cancel")
                            }

                            // Save Farm Boundary
                            Button(
                                onClick = {
                                    if (boundaryPoints.size >= 3) {
                                        val center = calculateCentroid(boundaryPoints)
                                        viewModel.saveFarmBoundary(
                                            context = context,
                                            points = boundaryPoints,
                                            areaAcres = areaAcres,
                                            areaHectares = areaHectares,
                                            centerLat = center.latitude,
                                            centerLng = center.longitude,
                                            onSuccess = {
                                                isDrawingBoundary = false
                                                Toast.makeText(context, "Farm boundary saved to Cloud & local storage!", Toast.LENGTH_SHORT).show()
                                            },
                                            onError = { err ->
                                                Toast.makeText(context, "Failed to save boundary: $err", Toast.LENGTH_LONG).show()
                                            }
                                        )
                                    } else {
                                        Toast.makeText(context, "Place at least 3 points around field boundary.", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                enabled = boundaryPoints.size >= 3,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("save_boundary_button")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save")
                            }
                        }
                    }

                    // Field Plots & Crop Summary Below Map
                    if (!isDrawingBoundary && fields.isNotEmpty()) {
                        Divider()
                        Text(
                            text = "Registered Fields & Active Crops (${fields.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(fields) { fld ->
                                val crp = activeCrops.find { it.fieldId == fld.id }
                                Card(
                                    modifier = Modifier
                                        .width(200.dp)
                                        .clickable { crp?.let { onNavigateToCropDetail(it.id) } },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(fld.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${fld.area} ${fld.areaUnit} • ${fld.soilType}", style = MaterialTheme.typography.bodySmall)
                                        if (crp != null) {
                                            Text("Crop: ${crp.cropName}", style = MaterialTheme.typography.labelSmall, color = ForestGreenPrimary, fontWeight = FontWeight.Bold)
                                        } else {
                                            Text("No crop assigned", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Geodesic Polygon Area Calculation (in Square Meters)
fun calculateGeodesicAreaMeters(points: List<LatLng>): Double {
    if (points.size < 3) return 0.0
    val earthRadius = 6378137.0 // Earth radius in meters
    var area = 0.0
    val size = points.size
    for (i in 0 until size) {
        val p1 = points[i]
        val p2 = points[(i + 1) % size]
        val lat1Rad = Math.toRadians(p1.latitude)
        val lat2Rad = Math.toRadians(p2.latitude)
        val lng1Rad = Math.toRadians(p1.longitude)
        val lng2Rad = Math.toRadians(p2.longitude)
        area += (lng2Rad - lng1Rad) * (2.0 + Math.sin(lat1Rad) + Math.sin(lat2Rad))
    }
    area = Math.abs(area * earthRadius * earthRadius / 2.0)
    return area
}

// Calculate Centroid of Polygon
fun calculateCentroid(points: List<LatLng>): LatLng {
    if (points.isEmpty()) return LatLng(20.5841, 77.0620)
    var sumLat = 0.0
    var sumLng = 0.0
    points.forEach {
        sumLat += it.latitude
        sumLng += it.longitude
    }
    return LatLng(sumLat / points.size, sumLng / points.size)
}

// Parse LatLng points from JSON string
fun parseLatLngPoints(json: String): List<LatLng> {
    if (json.isBlank()) return emptyList()
    return try {
        val list = mutableListOf<LatLng>()
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(LatLng(obj.getDouble("lat"), obj.getDouble("lng")))
        }
        list
    } catch (_: Exception) {
        emptyList()
    }
}

// Perform Geocoding Search for village, address, or farm landmark
fun performGeocodingSearch(
    context: Context,
    query: String,
    onResult: (LatLng, String) -> Unit,
    onError: (String) -> Unit
) {
    if (query.isBlank()) return
    try {
        val geocoder = Geocoder(context, Locale.getDefault())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            geocoder.getFromLocationName(query, 1) { addresses ->
                val addr = addresses.firstOrNull()
                if (addr != null) {
                    onResult(LatLng(addr.latitude, addr.longitude), addr.getAddressLine(0) ?: query)
                } else {
                    onError("No location found matching '$query'. Try entering district or village name.")
                }
            }
        } else {
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocationName(query, 1)
            val addr = addresses?.firstOrNull()
            if (addr != null) {
                onResult(LatLng(addr.latitude, addr.longitude), addr.getAddressLine(0) ?: query)
            } else {
                onError("No location found matching '$query'. Try entering district or village name.")
            }
        }
    } catch (e: Exception) {
        onError("Location search error: ${e.localizedMessage ?: e.message}")
    }
}
