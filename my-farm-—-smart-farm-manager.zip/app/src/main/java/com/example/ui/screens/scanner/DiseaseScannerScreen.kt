package com.example.ui.screens.scanner

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DiseaseScanRecord
import com.example.data.remote.DiseaseScanResult
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.theme.HealthWarningRed
import com.example.ui.viewmodel.FarmViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiseaseScannerScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val activeCrops by viewModel.activeCrops.collectAsState()
    val scans by viewModel.diseaseScans.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var selectedCrop by remember { mutableStateOf(activeCrops.firstOrNull()?.cropName ?: "Cotton (Kapas)") }
    var selectedField by remember { mutableStateOf(activeCrops.firstOrNull()?.fieldName ?: "Plot A (North Valley)") }
    var symptomsInput by remember { mutableStateOf("Yellowing along leaf margins with dark brown circular spots. Affected ~5% plants.") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var diagnosticResult by remember { mutableStateOf<DiseaseScanResult?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Crop Health & Pest Scanner", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("scanner_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Photo Picker Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .testTag("upload_photo_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(ForestGreenPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (selectedImageUri != null) Icons.Default.CheckCircle else Icons.Default.AddAPhoto,
                                contentDescription = null,
                                tint = ForestGreenPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (selectedImageUri != null) "Crop Photograph Attached" else "Take Photo or Upload Plant Image",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Supports zero-permission Android photo picker",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Input Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Symptom Observation Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                        OutlinedTextField(
                            value = selectedCrop,
                            onValueChange = { selectedCrop = it },
                            label = { Text("Affected Crop") },
                            modifier = Modifier.fillMaxWidth().testTag("crop_select_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = selectedField,
                            onValueChange = { selectedField = it },
                            label = { Text("Field / Plot Location") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = symptomsInput,
                            onValueChange = { symptomsInput = it },
                            label = { Text("Describe Symptoms & Pattern") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth().testTag("symptoms_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isAnalyzing = true
                                    val result = viewModel.diagnoseDisease(
                                        cropName = selectedCrop,
                                        fieldName = selectedField,
                                        symptoms = symptomsInput,
                                        bitmap = null,
                                        language = "English"
                                    )
                                    diagnosticResult = result
                                    isAnalyzing = false
                                }
                            },
                            enabled = !isAnalyzing,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("run_diagnosis_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary)
                        ) {
                            if (isAnalyzing) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Analyzing Plant Pathology...")
                            } else {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Analyze Health & Generate Diagnosis")
                            }
                        }
                    }
                }
            }

            // Diagnosis Result Card
            diagnosticResult?.let { res ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("diagnosis_result_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = res.diagnosisTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = HealthGoodGreen.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "Confidence: ${res.confidence}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = HealthGoodGreen,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Category: ${res.issueType}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            Text("Visual Manifestation:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(res.visualSigns, style = MaterialTheme.typography.bodySmall)

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Safe Immediate Actions (IPM):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(res.immediateSafeActions, style = MaterialTheme.typography.bodySmall)

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Prevention in Next 14 Days:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(res.prevention, style = MaterialTheme.typography.bodySmall)

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Expert Consultation Trigger:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(res.expertConsultation, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            // Legal Agronomic Disclaimer
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Disclaimer: AI image analysis is preliminary. Never apply unverified chemical insecticides based on automated scans alone. Always consult your local Krishi Vigyan Kendra (KVK) or certified agricultural officer.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Previous Scans History
            if (scans.isNotEmpty()) {
                item {
                    Text("Previous Scan History (${scans.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                items(scans) { scan ->
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(scan.diagnosisTitle, fontWeight = FontWeight.Bold)
                                Text(scan.status, style = MaterialTheme.typography.labelSmall, color = ForestGreenPrimary)
                            }
                            Text("${scan.cropName} • ${scan.fieldName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(scan.safeImmediateActions, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
