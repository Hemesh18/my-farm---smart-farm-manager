package com.example.ui.screens.crops

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CropRecord
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCropScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val fields by viewModel.allFields.collectAsState()

    var cropName by remember { mutableStateOf("Cotton (Kapas)") }
    var variety by remember { mutableStateOf("Ajit-155 BG II") }
    var selectedField by remember { mutableStateOf(fields.firstOrNull()?.name ?: "Plot A (North Valley)") }
    var selectedFieldId by remember { mutableStateOf(fields.firstOrNull()?.id ?: "field_1") }
    var season by remember { mutableStateOf("Kharif") }
    var plantedArea by remember { mutableStateOf("5.0") }
    var seedQuantity by remember { mutableStateOf("6.0") }
    var seedCost by remember { mutableStateOf("3900") }
    var seedSupplier by remember { mutableStateOf("Mahyco Seed Corp") }
    var expectedDuration by remember { mutableStateOf("155") }
    var expectedYield by remember { mutableStateOf("18.0") }
    var yieldUnit by remember { mutableStateOf("Quintal") }
    var notes by remember { mutableStateOf("Deep black cotton soil. Drip fertigation line active.") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Register New Crop", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            val duration = expectedDuration.toIntOrNull() ?: 120
                            val crop = CropRecord(
                                fieldId = selectedFieldId,
                                fieldName = selectedField,
                                cropName = cropName,
                                variety = variety,
                                season = season,
                                year = 2026,
                                plantedArea = plantedArea.toDoubleOrNull() ?: 4.0,
                                seedQuantity = seedQuantity.toDoubleOrNull() ?: 5.0,
                                seedCost = seedCost.toDoubleOrNull() ?: 3000.0,
                                seedSupplier = seedSupplier,
                                expectedDurationDays = duration,
                                expectedHarvestDateMillis = System.currentTimeMillis() + (duration.toLong() * 24 * 60 * 60 * 1000),
                                expectedYield = expectedYield.toDoubleOrNull() ?: 15.0,
                                yieldUnit = yieldUnit,
                                status = "Planted",
                                healthCondition = "Good",
                                currentGrowthStage = "Vegetative Stand",
                                notes = notes
                            )
                            viewModel.addCrop(crop)
                            onNavigateBack()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreenPrimary),
                        modifier = Modifier.testTag("save_crop_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Crop")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Crop & Seed Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            // Crop Name Suggestions
            val commonCrops = listOf("Cotton (Kapas)", "Soybean", "Wheat (Gehun)", "Maize (Makka)", "Green Chilli", "Onion (Pyaz)", "Sugarcane", "Chickpea (Chana)")
            var cropExpanded by remember { mutableStateOf(false) }

            ExposedDropdownMenuBox(
                expanded = cropExpanded,
                onExpandedChange = { cropExpanded = !cropExpanded }
            ) {
                OutlinedTextField(
                    value = cropName,
                    onValueChange = { cropName = it },
                    label = { Text("Crop Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("crop_name_field"),
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenu(
                    expanded = cropExpanded,
                    onDismissRequest = { cropExpanded = false }
                ) {
                    commonCrops.forEach { crop ->
                        DropdownMenuItem(
                            text = { Text(crop) },
                            onClick = {
                                cropName = crop
                                cropExpanded = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = variety,
                onValueChange = { variety = it },
                label = { Text("Variety or Hybrid Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("variety_field"),
                shape = RoundedCornerShape(12.dp)
            )

            // Field Selection
            var fieldExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = fieldExpanded,
                onExpandedChange = { fieldExpanded = !fieldExpanded }
            ) {
                OutlinedTextField(
                    value = selectedField,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Field / Plot") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("field_dropdown"),
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenu(
                    expanded = fieldExpanded,
                    onDismissRequest = { fieldExpanded = false }
                ) {
                    fields.forEach { field ->
                        DropdownMenuItem(
                            text = { Text("${field.name} (${field.area} ${field.areaUnit})") },
                            onClick = {
                                selectedField = field.name
                                selectedFieldId = field.id
                                fieldExpanded = false
                            }
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = plantedArea,
                    onValueChange = { plantedArea = it },
                    label = { Text("Planted Area (Acre)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("area_field"),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = season,
                    onValueChange = { season = it },
                    label = { Text("Season (Kharif/Rabi)") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("season_field"),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = seedQuantity,
                    onValueChange = { seedQuantity = it },
                    label = { Text("Seed Qty (Kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = seedCost,
                    onValueChange = { seedCost = it },
                    label = { Text("Seed Cost (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            OutlinedTextField(
                value = seedSupplier,
                onValueChange = { seedSupplier = it },
                label = { Text("Seed Supplier / Retailer") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
            Text("Harvest & Yield Targets", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = expectedDuration,
                    onValueChange = { expectedDuration = it },
                    label = { Text("Duration (Days)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = expectedYield,
                    onValueChange = { expectedYield = it },
                    label = { Text("Expected Yield") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Agronomic Notes & Field Condition") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
