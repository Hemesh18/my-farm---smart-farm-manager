package com.example.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CropRecord
import com.example.ui.screens.home.ActiveCropCard
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.theme.HealthWarningRed
import com.example.ui.viewmodel.FarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmHistoryScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToCropDetail: (String) -> Unit
) {
    val allCrops by viewModel.allCrops.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    var selectedYear by remember { mutableIntStateOf(2025) }
    var selectedSeason by remember { mutableStateOf("All") }
    var showComparisonMode by remember { mutableStateOf(false) }

    val years = listOf(2026, 2025, 2024)
    val seasons = listOf("All", "Kharif", "Rabi", "Zaid")

    val yearCrops = remember(allCrops, selectedYear, selectedSeason) {
        allCrops.filter {
            it.year == selectedYear && (selectedSeason == "All" || it.season.equals(selectedSeason, ignoreCase = true))
        }
    }

    val yearExpenses = remember(allTransactions, selectedYear) {
        allTransactions.filter { it.year == selectedYear && it.type == "EXPENSE" }.sumOf { it.amount }
    }
    val yearIncome = remember(allTransactions, selectedYear) {
        allTransactions.filter { it.year == selectedYear && it.type == "INCOME" }.sumOf { it.amount }
    }
    val yearProfit = yearIncome - yearExpenses

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Permanent Farm History", fontWeight = FontWeight.Bold)
                        Text(
                            "Multi-Year Archives & Search",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("history_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showComparisonMode = !showComparisonMode },
                        modifier = Modifier.testTag("history_compare_button")
                    ) {
                        Icon(
                            imageVector = if (showComparisonMode) Icons.Default.ViewAgenda else Icons.Default.Compare,
                            contentDescription = "Compare Years"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Global Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search records: '2024 Cotton', 'DAP', 'Receipt'...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("global_history_search_field"),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )
            }

            // If user is searching, display immediate search results
            if (searchQuery.isNotBlank()) {
                val results = searchResults
                if (results != null) {
                    item {
                        Text(
                            text = "Search Results for '$searchQuery'",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    if (results.matchedCrops.isEmpty() && results.matchedTransactions.isEmpty() && results.matchedJournals.isEmpty()) {
                        item {
                            Text("No historical records matched your query.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        items(results.matchedCrops) { crop ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToCropDetail(crop.id) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Crop: ${crop.cropName} (${crop.year} ${crop.season})", fontWeight = FontWeight.Bold)
                                    Text("${crop.fieldName} • Yield: ${crop.actualYield ?: "Growing"} ${crop.yieldUnit}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        items(results.matchedTransactions) { tx ->
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("${tx.category} (Year ${tx.year})", fontWeight = FontWeight.SemiBold)
                                        Text(tx.receiptNote, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text("₹${String.format("%,.0f", tx.amount)}", fontWeight = FontWeight.Bold, color = if (tx.type == "EXPENSE") HealthWarningRed else HealthGoodGreen)
                                }
                            }
                        }
                    }
                }
            } else if (showComparisonMode) {
                // Side-by-Side Year Comparison Mode
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Multi-Year Performance Comparison", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Comparison Table Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Metric", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                                Text("2024", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text("2025", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text("2026", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))

                            ComparisonRow("Main Crop", "Cotton", "Soybean", "Cotton/Chilli")
                            ComparisonRow("Area (Ac)", "5.0 Ac", "4.5 Ac", "8.5 Ac")
                            ComparisonRow("Yield", "15.2 Qtl", "36.5 Qtl", "In Growth")
                            ComparisonRow("Revenue", "₹1,06,400", "₹1,75,200", "Pending")
                            ComparisonRow("Expense", "₹22,100", "₹16,600", "₹18,950")
                            ComparisonRow("Net Profit", "+₹84,300", "+₹1,58,600", "Ongoing")
                        }
                    }
                }
            } else {
                // Year & Season Selector
                item {
                    Text("Select Agricultural Year:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(years) { y ->
                            FilterChip(
                                selected = selectedYear == y,
                                onClick = { selectedYear = y },
                                label = { Text("$y Season") },
                                modifier = Modifier.testTag("year_chip_$y")
                            )
                        }
                    }
                }

                item {
                    Text("Select Season:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(seasons) { s ->
                            FilterChip(
                                selected = selectedSeason == s,
                                onClick = { selectedSeason = s },
                                label = { Text(s) },
                                modifier = Modifier.testTag("season_chip_$s")
                            )
                        }
                    }
                }

                // Season Financial Summary Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = ForestGreenPrimary),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "$selectedYear Season Financial Summary",
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Net Return: ₹${String.format("%,.0f", yearProfit)}",
                                color = Color.White,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Total Revenue", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
                                    Text("₹${String.format("%,.0f", yearIncome)}", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("Total Expenses", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
                                    Text("₹${String.format("%,.0f", yearExpenses)}", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("Crops Logged", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
                                    Text("${yearCrops.size} Batches", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Crop Records for Selected Year
                item {
                    Text(
                        text = "Historical Crops in $selectedYear (${yearCrops.size})",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                if (yearCrops.isEmpty()) {
                    item {
                        Text(
                            text = "No crop records saved for $selectedYear under season '$selectedSeason'.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(yearCrops) { crop ->
                        ActiveCropCard(
                            crop = crop,
                            onClick = { onNavigateToCropDetail(crop.id) }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun ComparisonRow(label: String, v2024: String, v2025: String, v2026: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, modifier = Modifier.weight(1.2f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v2024, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
        Text(v2025, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
        Text(v2026, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
    }
}
