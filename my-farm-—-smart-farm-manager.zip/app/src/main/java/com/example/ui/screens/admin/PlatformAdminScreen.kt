package com.example.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HealthGoodGreen
import com.example.ui.theme.LeafGreenSecondary
import com.example.ui.viewmodel.FarmViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlatformAdminScreen(
    viewModel: FarmViewModel,
    onNavigateBack: () -> Unit
) {
    val users by viewModel.allRegisteredUsers.collectAsState()
    val auditLogs by viewModel.allAuditLogs.collectAsState()
    val weather by viewModel.weatherInfo.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Tenant Users, 1: Audit Log, 2: Service Health

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Platform Admin & SaaS Health", fontWeight = FontWeight.Bold)
                        Text("Multi-tenant monitoring & audit events", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Farmers (${users.size})") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Audit Trail") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Service Health") })
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        item {
                            Text("Registered Farmer Tenants", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        items(users) { user ->
                            Card(
                                modifier = Modifier.fillMaxWidth().testTag("admin_user_card_${user.id}"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(user.fullName, fontWeight = FontWeight.Bold)
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (user.role == "ADMIN") ForestGreenPrimary.copy(alpha = 0.15f) else LeafGreenSecondary.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = "${user.role} • ${user.subscriptionPlan}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (user.role == "ADMIN") ForestGreenPrimary else LeafGreenSecondary,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${user.email} • ${user.phone.ifBlank { "No phone" }}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${user.village}, ${user.district}, ${user.state} (PIN ${user.pinCode})",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        item {
                            Text("Security & Activity Audit Log", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        if (auditLogs.isEmpty()) {
                            item { Text("No audit records available.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(auditLogs) { log ->
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(log.action, fontWeight = FontWeight.Bold, color = ForestGreenPrimary)
                                            Text(
                                                text = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp)),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(log.details, style = MaterialTheme.typography.bodySmall)
                                        Text("User: ${log.userEmail}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        item {
                            Text("Subsystem Health & API Integrations", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        item {
                            ServiceHealthCard(
                                serviceName = "Open-Meteo Real Weather API",
                                status = if (weather != null && weather?.isLiveApi == true) "OPERATIONAL (LIVE)" else "HEALTHY (CACHED)",
                                details = "Global satellite numerical weather forecast with zero authentication keys required. Rate limits unthrottled.",
                                isHealthy = true
                            )
                        }

                        item {
                            ServiceHealthCard(
                                serviceName = "Google Gemini 3.5 Flash Model",
                                status = "OPERATIONAL",
                                details = "Multimodal agronomic reasoning and disease pathology diagnosis. Connected via secure AI Studio server-side injection.",
                                isHealthy = true
                            )
                        }

                        item {
                            ServiceHealthCard(
                                serviceName = "Room SQLite Database & Multi-tenant Storage",
                                status = "OPTIMAL",
                                details = "Version 2 with tenant isolation, foreign-key relationships, and instant offline durability.",
                                isHealthy = true
                            )
                        }

                        item {
                            ServiceHealthCard(
                                serviceName = "Android Native PDF Vector Rendering Engine",
                                status = "READY",
                                details = "A4 multi-page document compilation with standard Android graphics pipeline and FileProvider integration.",
                                isHealthy = true
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}

@Composable
private fun ServiceHealthCard(
    serviceName: String,
    status: String,
    details: String,
    isHealthy: Boolean
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(serviceName, fontWeight = FontWeight.Bold)
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = (if (isHealthy) HealthGoodGreen else Color.Red).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isHealthy) HealthGoodGreen else Color.Red,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
