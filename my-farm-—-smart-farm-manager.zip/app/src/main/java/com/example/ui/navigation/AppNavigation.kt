package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.AppStrings
import com.example.ui.screens.analytics.AnalyticsReportsScreen
import com.example.ui.screens.assistant.AIAssistantScreen
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.ResetPasswordScreen
import com.example.ui.screens.calendar.FarmCalendarScreen
import com.example.ui.screens.crops.AddEditCropScreen
import com.example.ui.screens.crops.CropDetailScreen
import com.example.ui.screens.crops.CropsScreen
import com.example.ui.screens.finances.FinancesScreen
import com.example.ui.screens.history.FarmHistoryScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.irrigation.IrrigationScreen
import com.example.ui.screens.map.FarmMapScreen
import com.example.ui.screens.more.MoreHubScreen
import com.example.ui.screens.scanner.DiseaseScannerScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.soil.SoilFertilizerScreen
import com.example.ui.screens.weather.WeatherScreen
import com.example.ui.theme.ForestGreenDarkPrimaryContainer
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.HarvestAmberDarkTertiary
import com.example.ui.viewmodel.FarmViewModel
import kotlinx.coroutines.launch

enum class MainTab(val route: String, val title: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Default.Home),
    CROPS("crops", "My Crops", Icons.Default.Agriculture),
    MAP("map", "Farm Map", Icons.Default.Map),
    ASSISTANT("assistant", "AI Assistant", Icons.Default.AutoAwesome),
    MORE("more", "More", Icons.Default.Menu)
}

private data class DrawerItemData(
    val route: String,
    val labelKey: String,
    val defaultLabel: String,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(viewModel: FarmViewModel) {
    val isAuthInitializing by viewModel.isAuthInitializing.collectAsState()
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val farmProfile by viewModel.farmProfile.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()

    var currentScreen by remember { mutableStateOf("home") }
    var selectedCropId by remember { mutableStateOf<String?>(null) }
    val screenStack = remember { mutableStateListOf("home") }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    fun navigateTo(destination: String) {
        if (currentScreen != destination) {
            screenStack.add(destination)
            currentScreen = destination
        }
    }

    fun navigateBack() {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.size - 1)
            currentScreen = screenStack.last()
        } else if (currentScreen != "home") {
            currentScreen = "home"
        }
    }

    BackHandler(enabled = screenStack.size > 1 || currentScreen != "home") {
        navigateBack()
    }

    if (isAuthInitializing) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(color = ForestGreenPrimary)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Restoring Session...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    var authSubScreen by remember { mutableStateOf("login") }
    var resetEmailPrefill by remember { mutableStateOf("") }
    var resetTokenPrefill by remember { mutableStateOf("") }

    if (!isLoggedIn) {
        when (authSubScreen) {
            "forgot_password" -> ForgotPasswordScreen(
                viewModel = viewModel,
                onNavigateToReset = { email, token ->
                    resetEmailPrefill = email
                    resetTokenPrefill = token
                    authSubScreen = "reset_password"
                },
                onBackToLogin = { authSubScreen = "login" }
            )
            "reset_password" -> ResetPasswordScreen(
                initialEmail = resetEmailPrefill,
                initialToken = resetTokenPrefill,
                viewModel = viewModel,
                onResetSuccess = { authSubScreen = "login" },
                onBackToLogin = { authSubScreen = "login" }
            )
            else -> LoginScreen(
                viewModel = viewModel,
                onLoginSuccess = {
                    currentScreen = "home"
                    screenStack.clear()
                    screenStack.add("home")
                },
                onForgotPasswordClick = { authSubScreen = "forgot_password" }
            )
        }
        return
    }

    if (currentUser != null && !currentUser!!.isOnboardingCompleted) {
        com.example.ui.screens.onboarding.OnboardingWizardScreen(
            viewModel = viewModel,
            onOnboardingFinished = {
                currentScreen = "home"
                screenStack.clear()
                screenStack.add("home")
            }
        )
        return
    }

    val isMainTab = MainTab.values().any { it.route == currentScreen }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(310.dp)
                    .testTag("nav_drawer")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(ForestGreenPrimary, ForestGreenDarkPrimaryContainer)
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Agriculture,
                                            contentDescription = "My Farm",
                                            tint = ForestGreenPrimary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = farmProfile?.farmName?.takeIf { it.isNotBlank() } ?: "My Farm",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        text = farmProfile?.farmerName?.takeIf { it.isNotBlank() }
                                            ?: (currentUser?.fullName ?: "Farmer"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }
                            if (!farmProfile?.village.isNullOrBlank() || !farmProfile?.district.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Location",
                                        tint = HarvestAmberDarkTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    val loc = listOfNotNull(farmProfile?.village, farmProfile?.district)
                                        .filter { it.isNotBlank() }
                                        .joinToString(", ")
                                    Text(
                                        text = loc,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Section 1: Main Modules
                    Text(
                        text = when (currentLanguage) {
                            "Marathi" -> "मुख्य विभाग (Main Modules)"
                            "Hindi" -> "मुख्य अनुभाग (Main Modules)"
                            else -> "FARM MODULES"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )

                    val mainModules = listOf(
                        DrawerItemData("home", "tab_home", "Home Dashboard", Icons.Default.Home),
                        DrawerItemData("crops", "tab_crops", "My Crops", Icons.Default.Agriculture),
                        DrawerItemData("weather", "weather", "Weather Forecast", Icons.Default.WbSunny),
                        DrawerItemData("finances", "finances", "Finances & P&L", Icons.Default.AccountBalanceWallet),
                        DrawerItemData("map", "tab_map", "Farm Map & Fields", Icons.Default.Map)
                    )

                    mainModules.forEach { item ->
                        val isSelected = currentScreen == item.route
                        val rawLabel = AppStrings.get(item.labelKey, currentLanguage)
                        val label = if (rawLabel.startsWith("tab_") || rawLabel == item.labelKey) item.defaultLabel else rawLabel
                        NavigationDrawerItem(
                            icon = { Icon(item.icon, contentDescription = label) },
                            label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            selected = isSelected,
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                if (currentScreen != item.route) {
                                    currentScreen = item.route
                                    screenStack.clear()
                                    screenStack.add(item.route)
                                }
                            },
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .testTag("drawer_item_${item.route}")
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Section 2: Farm Tools & Operations
                    Text(
                        text = when (currentLanguage) {
                            "Marathi" -> "शेती साधने (Farm Tools)"
                            "Hindi" -> "कृषि उपकरण (Farm Tools)"
                            else -> "FARM TOOLS & OPERATIONS"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )

                    val toolModules = listOf(
                        DrawerItemData("soil", "soil", "Soil & Fertilizer", Icons.Default.Science),
                        DrawerItemData("irrigation", "irrigation", "Irrigation & Water", Icons.Default.WaterDrop),
                        DrawerItemData("scanner", "scanner", "Crop Disease Scanner", Icons.Default.QrCodeScanner),
                        DrawerItemData("assistant", "assistant", "AI Farm Assistant", Icons.Default.AutoAwesome),
                        DrawerItemData("calendar", "calendar", "Farm Calendar & Tasks", Icons.Default.CalendarToday),
                        DrawerItemData("journal", "journal", "Farm Activity Journal", Icons.Default.EditNote)
                    )

                    toolModules.forEach { item ->
                        val isSelected = currentScreen == item.route
                        val rawLabel = AppStrings.get(item.labelKey, currentLanguage)
                        val label = if (rawLabel == item.labelKey) item.defaultLabel else rawLabel
                        NavigationDrawerItem(
                            icon = { Icon(item.icon, contentDescription = label) },
                            label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            selected = isSelected,
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                navigateTo(item.route)
                            },
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .testTag("drawer_item_${item.route}")
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Section 3: Reports & Settings
                    Text(
                        text = when (currentLanguage) {
                            "Marathi" -> "अहवाल व सेटिंग्ज (Reports & Settings)"
                            "Hindi" -> "रिपोर्ट और सेटिंग्स (Reports & Settings)"
                            else -> "INSIGHTS & SETTINGS"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )

                    val managementModules = listOf(
                        DrawerItemData("analytics", "analytics", "Analytics & PDF Reports", Icons.Default.BarChart),
                        DrawerItemData("history", "history", "Farm History", Icons.Default.History),
                        DrawerItemData("settings", "settings", "Settings & Profile", Icons.Default.Settings)
                    )

                    managementModules.forEach { item ->
                        val isSelected = currentScreen == item.route
                        val rawLabel = AppStrings.get(item.labelKey, currentLanguage)
                        val label = if (rawLabel == item.labelKey) item.defaultLabel else rawLabel
                        NavigationDrawerItem(
                            icon = { Icon(item.icon, contentDescription = label) },
                            label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            selected = isSelected,
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                navigateTo(item.route)
                            },
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .testTag("drawer_item_${item.route}")
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Footer with Logout button
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "My Farm v2.0",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Smart Agricultural System",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    coroutineScope.launch { drawerState.close() }
                                    viewModel.logout()
                                },
                                modifier = Modifier.testTag("drawer_logout_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Logout,
                                    contentDescription = "Logout",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                if (isMainTab) {
                    NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                        MainTab.values().forEach { tab ->
                            val isSelected = currentScreen == tab.route
                            val localizedLabel = when (tab) {
                                MainTab.HOME -> AppStrings.get("tab_home", currentLanguage)
                                MainTab.CROPS -> AppStrings.get("tab_crops", currentLanguage)
                                MainTab.MAP -> AppStrings.get("tab_map", currentLanguage)
                                MainTab.ASSISTANT -> AppStrings.get("tab_assistant", currentLanguage)
                                MainTab.MORE -> AppStrings.get("tab_more", currentLanguage)
                            }
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    if (currentScreen != tab.route) {
                                        currentScreen = tab.route
                                        screenStack.clear()
                                        screenStack.add(tab.route)
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = localizedLabel) },
                                label = { Text(localizedLabel) },
                                modifier = Modifier.testTag("nav_item_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Surface(modifier = Modifier.padding(innerPadding)) {
                when (currentScreen) {
                    MainTab.HOME.route -> HomeScreen(
                        viewModel = viewModel,
                        onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
                        onNavigateToCropDetail = { id ->
                            selectedCropId = id
                            navigateTo("crop_detail")
                        },
                        onNavigateToAddCrop = { navigateTo("add_crop") },
                        onNavigateToWeather = { navigateTo("weather") },
                        onNavigateToAiAssistant = { navigateTo(MainTab.ASSISTANT.route) },
                        onNavigateToScanner = { navigateTo("scanner") },
                        onNavigateToCalendar = { navigateTo("calendar") },
                        onNavigateToFinances = { navigateTo("finances") },
                        onNavigateToIrrigation = { navigateTo("irrigation") },
                        onNavigateToFertilizer = { navigateTo("soil") },
                        onNavigateToHistory = { navigateTo("history") }
                    )

                    MainTab.CROPS.route -> CropsScreen(
                        viewModel = viewModel,
                        onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
                        onNavigateToCropDetail = { id ->
                            selectedCropId = id
                            navigateTo("crop_detail")
                        },
                        onNavigateToAddCrop = { navigateTo("add_crop") }
                    )

                    MainTab.MAP.route -> FarmMapScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() },
                        onNavigateToCropDetail = { id ->
                            selectedCropId = id
                            navigateTo("crop_detail")
                        }
                    )

                    MainTab.ASSISTANT.route -> AIAssistantScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    MainTab.MORE.route -> MoreHubScreen(
                        viewModel = viewModel,
                        onNavigateToHistory = { navigateTo("history") },
                        onNavigateToScanner = { navigateTo("scanner") },
                        onNavigateToCalendar = { navigateTo("calendar") },
                        onNavigateToFinances = { navigateTo("finances") },
                        onNavigateToIrrigation = { navigateTo("irrigation") },
                        onNavigateToSoil = { navigateTo("soil") },
                        onNavigateToJournal = { navigateTo("journal") },
                        onNavigateToAnalytics = { navigateTo("analytics") },
                        onNavigateToSettings = { navigateTo("settings") },
                        onNavigateToSubscription = { navigateTo("subscription") },
                        onNavigateToAdmin = { navigateTo("admin") },
                        onLogout = { currentScreen = "login" }
                    )

                    "crop_detail" -> CropDetailScreen(
                        cropId = selectedCropId ?: "",
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "add_crop" -> AddEditCropScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "weather" -> WeatherScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "scanner" -> DiseaseScannerScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "history" -> FarmHistoryScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() },
                        onNavigateToCropDetail = { id ->
                            selectedCropId = id
                            navigateTo("crop_detail")
                        }
                    )

                    "calendar" -> FarmCalendarScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "finances" -> FinancesScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "irrigation" -> IrrigationScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "soil" -> SoilFertilizerScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "journal" -> com.example.ui.screens.journal.FarmJournalScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "analytics" -> AnalyticsReportsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "settings" -> SettingsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "subscription" -> com.example.ui.screens.saas.SubscriptionPlansScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    "admin" -> com.example.ui.screens.admin.PlatformAdminScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navigateBack() }
                    )

                    else -> HomeScreen(
                        viewModel = viewModel,
                        onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
                        onNavigateToCropDetail = { id ->
                            selectedCropId = id
                            navigateTo("crop_detail")
                        },
                        onNavigateToAddCrop = { navigateTo("add_crop") },
                        onNavigateToWeather = { navigateTo("weather") },
                        onNavigateToAiAssistant = { navigateTo(MainTab.ASSISTANT.route) },
                        onNavigateToScanner = { navigateTo("scanner") },
                        onNavigateToCalendar = { navigateTo("calendar") },
                        onNavigateToFinances = { navigateTo("finances") },
                        onNavigateToIrrigation = { navigateTo("irrigation") },
                        onNavigateToFertilizer = { navigateTo("soil") },
                        onNavigateToHistory = { navigateTo("history") }
                    )
                }
            }
        }
    }
}
